"""
WaveForge Desktop Application Entry Point
ISRO Bharatiya Antariksh Hackathon 2026 - Problem Statement 9

Launches the PySide6 application runtime and displays the Main Window.
"""

import sys
from app import WaveForgeApp
from ui.main_window import MainWindow


def main():
    """Initializes Qt Application and enters event loop."""
    app = WaveForgeApp(sys.argv)
    
    main_window = MainWindow()
    main_window.resize(1600, 1000)
    main_window.show()
    
    app.logger.info("WaveForge Main Window displayed successfully.")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
