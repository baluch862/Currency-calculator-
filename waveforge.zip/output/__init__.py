"""Output Module Initialization"""
