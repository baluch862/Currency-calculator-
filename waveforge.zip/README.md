# WaveForge | Adaptive Optics & Wavefront Reconstruction Software

**ISRO Bharatiya Antariksh Hackathon 2026 - Problem Statement 9**  
*High-Resolution Shack-Hartmann Wavefront Sensor (SH-WFS) Analysis & Deformable Mirror Control*

---

## 🌌 Overview

**WaveForge** is a production-grade, highly modular scientific desktop application engineered with Python and **PySide6 (Qt)**. It bridges high-frequency optical frame acquisition with real-time adaptive optics phase reconstruction, tailored specifically for astronomical research and space instrumentation.

The application adheres strictly to the **Stitch Premium Industrial Dark Design System**, offering a clinical mission-control environment optimized for low visual fatigue during high-density data telemetry monitoring.

---

## 📐 Key Scientific Capabilities

1. **High-Speed SH-WFS Frame Processing**:
   - Ingestion of raw optical sensor arrays (`.FITS`, `.TIFF`, `.RAW`).
   - CUDA/Multi-threaded noise filtering (Gaussian blur, median filtering, histogram equalization).
2. **Precision Sub-Pixel Centroid Detection**:
   - Center of Gravity (CoG) and Weighted Centroid calculation.
   - Real-time optical slope deviation mapping and vector overlays.
3. **Modal Phase Reconstruction**:
   - Zonal geometry solvers: **Southwell**, **Hudgin**, and **Fried**.
   - **Zernike Polynomial Expansion** up to 64 expansion orders.
4. **Atmospheric Turbulence Characterization**:
   - Real-time estimation of **Fried Parameter ($r_0$)** and **Coherence Time ($\tau_0$)**.
   - Live Wavefront Root-Mean-Square (RMS) error tracking ($\lambda$).
5. **Closed-Loop Deformable Mirror (DM) Telemetry**:
   - Interactive 8x8 circular actuator voltage mapping and thermal variance diagnostics.

---

## 🏗️ Architecture & Tech Stack

- **GUI Framework**: PySide6 (Qt for Python), PyQtGraph
- **Core Numerics**: NumPy, SciPy, OpenCV, scikit-image, Pandas
- **Visualization**: Matplotlib, PyQtGraph 3D Surface Canvases
- **Packaging & Deployment**: PyInstaller

```text
WaveForge/
├── app.py                 # Core QApplication lifecycle & QSS Glassmorphic Styling
├── main.py                # Standalone application launch entry point
├── requirements.txt       # Version-locked research dependencies
├── ui/                    # PySide6 UI components (MainWindow, Sidebar, Dashboard)
├── algorithms/            # Optical numerics & Zernike reconstruction solvers
├── dataset/               # FITS/TIFF batch loading & metadata management
├── utils/                 # Clinical logging & hardware progress notifications
├── reports/               # AI PDF report generation & export engines
├── settings/              # CUDA worker thread & DM hardware configuration
└── logs/                  # Runtime event execution logs
```

---

## 🚀 Getting Started

### Prerequisites

Ensure Python 3.10+ is installed on your workstation.

```bash
# Clone repository
git clone https://github.com/ISRO-Hackathon-2026/WaveForge.git
cd WaveForge

# Install scientific and UI dependencies
pip install -r requirements.txt
```

### Running the Application

Launch the standalone desktop interface:

```bash
python main.py
```

---

## 🛡️ Hackathon Compliance Note

Developed specifically for **Problem Statement 9** of the ISRO Bharatiya Antariksh Hackathon 2026. All modules follow strict Object-Oriented Programming (OOP) paradigms, signal/slot decoupled communication architectures, and comprehensive runtime logging.
