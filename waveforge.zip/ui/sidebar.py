"""
WaveForge Navigation Sidebar Module
ISRO Bharatiya Antariksh Hackathon 2026 - Problem Statement 9

Provides mission control navigation, active module switching signals, and simulation triggers.
"""

import logging
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QWidget
from PySide6.QtCore import Signal, Qt, Slot
from PySide6.QtGui import QIcon, QFont


class NavigationButton(QPushButton):
    """Custom styled navigation button with active state indicator."""
    def __init__(self, icon_name: str, text: str, module_id: str, parent=None):
        super().__init__(text, parent)
        self.module_id = module_id
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(48)
        
        # Left-aligned text with padding
        self.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                border-left: 3px solid transparent;
                text-align: left;
                padding-left: 20px;
                color: #c7c4d7;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: 0.5px;
            }
            QPushButton:hover {
                background-color: rgba(50, 53, 60, 0.4);
                color: #ffffff;
            }
            QPushButton:checked {
                background-color: rgba(0, 203, 230, 0.12);
                border-left: 3px solid #00cbe6;
                color: #5de6ff;
            }
        """)


class Sidebar(QFrame):
    """
    Main Navigation Sidebar widget.
    Emits `module_selected(str)` signal when user navigates between scientific modules.
    Emits `run_simulation_triggered()` when the primary action button is clicked.
    """
    module_selected = Signal(str)
    run_simulation_triggered = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self.setFixedWidth(280)
        self.logger = logging.getLogger("WaveForge.Sidebar")

        self.setStyleSheet("""
            QFrame#Sidebar {
                background-color: #12151d;
                border-right: 1px solid rgba(70, 69, 84, 0.2);
            }
        """)

        self.nav_buttons = {}
        self.init_ui()

    def init_ui(self):
        """Initializes branding header, navigation stack, and bottom mission controls."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 24, 0, 24)
        layout.setSpacing(8)

        # 1. Branding Header
        header_widget = QWidget()
        header_layout = QHBoxLayout(header_widget)
        header_layout.setContentsMargins(20, 0, 20, 16)
        
        logo_box = QFrame()
        logo_box.setFixedSize(36, 36)
        logo_box.setStyleSheet("background-color: #8083ff; border-radius: 8px;")
        logo_label = QLabel("WF", logo_box)
        logo_label.setAlignment(Qt.AlignCenter)
        logo_label.setStyleSheet("color: #1000a9; font-weight: 800; font-size: 16px;")

        title_box = QWidget()
        title_layout = QVBoxLayout(title_box)
        title_layout.setContentsMargins(8, 0, 0, 0)
        title_layout.setSpacing(2)
        
        app_title = QLabel("WAVEFORGE")
        app_title.setStyleSheet("color: #c0c1ff; font-weight: 700; font-size: 14px; letter-spacing: 1px;")
        sub_title = QLabel("ISRO HACKATHON '26")
        sub_title.setStyleSheet("color: #908fa0; font-size: 10px; font-weight: 600;")
        
        title_layout.addWidget(app_title)
        title_layout.addWidget(sub_title)

        header_layout.addWidget(logo_box)
        header_layout.addWidget(title_box)
        header_layout.addStretch()
        layout.addWidget(header_widget)

        # Divider
        divider = QFrame()
        divider.setFixedHeight(1)
        divider.setStyleSheet("background-color: rgba(70, 69, 84, 0.2); margin-left: 20px; margin-right: 20px;")
        layout.addWidget(divider)

        # 2. Navigation Modules List
        modules = [
            ("dashboard", "Dashboard", "MISSION CONTROL"),
            ("dataset", "Dataset Manager", "SH-WFS FRAMES"),
            ("processing", "Image Processing", "NOISE & FILTERING"),
            ("spot_detection", "Spot & Centroids", "SUB-PIXEL SLOPE"),
            ("reconstruction", "Wavefront Recon", "ZERNIKE MODES"),
            ("turbulence", "Atmospheric r₀", "TURBULENCE EST"),
            ("actuators", "Actuator Map", "8x8 DEFORMABLE"),
            ("reports", "AI Reports & Export", "PDF & CSV ANALYTICS"),
            ("settings", "Settings", "HARDWARE & CUDA")
        ]

        layout.addSpacing(12)
        for mod_id, title, subtitle in modules:
            btn = NavigationButton("", title, mod_id)
            btn.clicked.connect(lambda checked, mid=mod_id: self.handle_nav_click(mid))
            self.nav_buttons[mod_id] = btn
            layout.addWidget(btn)

        layout.addStretch()

        # 3. Bottom Action Controls
        bottom_container = QWidget()
        bottom_layout = QVBoxLayout(bottom_container)
        bottom_layout.setContentsMargins(20, 16, 20, 0)
        bottom_layout.setSpacing(12)

        # Primary Simulation Button
        self.sim_btn = QPushButton("▶  Run Simulation")
        self.sim_btn.setObjectName("PrimaryButton")
        self.sim_btn.setFixedHeight(44)
        self.sim_btn.setCursor(Qt.PointingHandCursor)
        self.sim_btn.clicked.connect(self.trigger_simulation)
        bottom_layout.addWidget(self.sim_btn)

        # Quick Links
        links_layout = QHBoxLayout()
        help_btn = QPushButton("Help")
        help_btn.setStyleSheet("background: transparent; border: none; color: #908fa0; font-size: 11px;")
        about_btn = QPushButton("About")
        about_btn.setStyleSheet("background: transparent; border: none; color: #908fa0; font-size: 11px;")
        exit_btn = QPushButton("Exit")
        exit_btn.setStyleSheet("background: transparent; border: none; color: #ffb4ab; font-size: 11px;")
        
        links_layout.addWidget(help_btn)
        links_layout.addWidget(about_btn)
        links_layout.addStretch()
        links_layout.addWidget(exit_btn)
        bottom_layout.addLayout(links_layout)

        layout.addWidget(bottom_container)

        # Default select Dashboard
        self.set_active_module("dashboard")

    @Slot(str)
    def handle_nav_click(self, module_id: str):
        """Handles navigation selection and emits signal."""
        self.set_active_module(module_id)
        self.module_selected.emit(module_id)
        self.logger.debug(f"User navigated to module: {module_id}")

    def set_active_module(self, module_id: str):
        """Updates button checked states visually."""
        for mid, btn in self.nav_buttons.items():
            btn.setChecked(mid == module_id)

    @Slot()
    def trigger_simulation(self):
        """Emits simulation trigger signal."""
        self.logger.info("Simulation run requested from sidebar control.")
        self.run_simulation_triggered.emit()
