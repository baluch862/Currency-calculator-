"""
WaveForge Dashboard & Mission Control Module
ISRO Bharatiya Antariksh Hackathon 2026 - Problem Statement 9

Implements real-time Shack-Hartmann spot grid visualization, zonal wavefront phase maps,
engineering metric telemetry rails, 8x8 Deformable Mirror actuator grids, and clinical log console.
"""

import logging
import random
from datetime import datetime
import numpy as np

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QFrame,
    QLabel, QPushButton, QScrollArea, QSplitter, QFileDialog
)
from PySide6.QtCore import Qt, QTimer, Slot, Signal
from PySide6.QtGui import QImage, QPixmap, QColor, QFont, QPainter, QPen


class MetricCard(QFrame):
    """
    Glassmorphic Telemetry Metric Card.
    Features left border color accents matching the Stitch aerospace design system.
    """
    def __init__(self, title: str, unit: str, accent_color: str, initial_val: str = "0.0", parent=None):
        super().__init__(parent)
        self.setObjectName("GlassCard")
        self.unit = unit
        self.setFixedHeight(100)
        
        # Apply specific left accent border
        self.setStyleSheet(f"""
            QFrame#GlassCard {{
                background-color: rgba(22, 27, 34, 0.75);
                border: 1px solid rgba(70, 69, 84, 0.25);
                border-left: 4px solid {accent_color};
                border-radius: 10px;
            }}
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(6)

        title_label = QLabel(title.upper())
        title_label.setStyleSheet("color: #c7c4d7; font-size: 10px; font-weight: 700; letter-spacing: 1px;")
        
        val_layout = QHBoxLayout()
        val_layout.setSpacing(6)
        
        self.val_label = QLabel(initial_val)
        self.val_label.setStyleSheet(f"color: {accent_color}; font-family: 'Geist', monospace; font-size: 26px; font-weight: 700;")
        
        unit_label = QLabel(unit)
        unit_label.setStyleSheet("color: #908fa0; font-size: 13px; font-weight: 600;")
        unit_label.setAlignment(Qt.AlignBottom)

        val_layout.addWidget(self.val_label)
        val_layout.addWidget(unit_label)
        val_layout.addStretch()

        layout.addWidget(title_label)
        layout.addLayout(val_layout)

    def update_value(self, value: float):
        """Formats and updates metric display with scientific precision."""
        if self.unit == "active":
            self.val_label.setText(f"{int(value):,}")
        else:
            self.val_label.setText(f"{value:.3f}")


class LiveSpotGridWidget(QLabel):
    """
    Renders real-time Shack-Hartmann Wavefront Sensor spot grid.
    Generates dynamic multi-spot optical arrays with simulated atmospheric jitter.
    """
    def __init__(self, title: str, accent_color: str, show_centroids: bool = False, parent=None):
        super().__init__(parent)
        self.title = title
        self.show_centroids = show_centroids
        self.accent_color = accent_color
        self.setMinimumSize(380, 280)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("""
            QLabel {
                background-color: #05070a;
                border: 1px solid rgba(70, 69, 84, 0.3);
                border-radius: 8px;
            }
        """)

    def render_optical_frame(self, jitter_x: float, jitter_y: float):
        """Generates a synthetic 400x300 wavefront sensor spot array."""
        w, h = 400, 300
        grid_cols, grid_rows = 10, 8
        
        # Create dark canvas
        img = QPixmap(w, h)
        img.fill(QColor("#080b10"))
        
        painter = QPainter(img)
        painter.setRenderHint(QPainter.Antialiasing)

        dx = w / (grid_cols + 1)
        dy = h / (grid_rows + 1)

        for col in range(1, grid_cols + 1):
            for row in range(1, grid_rows + 1):
                cx = col * dx + (random.uniform(-1, 1) + jitter_x) * 3.0
                cy = row * dy + (random.uniform(-1, 1) + jitter_y) * 3.0
                
                # Draw diffuse light spot
                spot_gradient = QColor("#5de6ff")
                spot_gradient.setAlpha(160)
                painter.setBrush(spot_gradient)
                painter.setPen(Qt.NoPen)
                painter.drawEllipse(int(cx - 4), int(cy - 4), 8, 8)

                # Draw centroid vector overlays if active
                if self.show_centroids:
                    pen = QPen(QColor("#ffb4ab"), 1.5)
                    painter.setPen(pen)
                    painter.drawLine(int(cx - 7), int(cy), int(cx + 7), int(cy))
                    painter.drawLine(int(cx), int(cy - 7), int(cx), int(cy + 7))

        painter.end()
        self.setPixmap(img.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))


class ActuatorStatusWidget(QFrame):
    """
    Deformable Mirror (DM) Actuator Map.
    Represents an 8x8 circular mirror array with live high-voltage state feedback.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("GlassCard")
        self.setMinimumHeight(240)
        self.actuator_nodes = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 16)
        layout.setSpacing(12)

        # Header
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        title = QLabel("ACTUATOR STATUS (8x8 DM)")
        title.setStyleSheet("color: #c7c4d7; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
        status = QLabel("MIRROR ACTIVE")
        status.setStyleSheet("color: #00cbe6; font-family: 'Geist', monospace; font-size: 11px; font-weight: 700;")
        
        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addWidget(status)
        layout.addWidget(header)

        # Circular DM Grid Container
        grid_container = QWidget()
        grid_layout = QGridLayout(grid_container)
        grid_layout.setSpacing(8)
        grid_layout.setAlignment(Qt.AlignCenter)

        for i in range(64):
            col, row = i % 8, i // 8
            # Euclidean distance from center (3.5, 3.5) to clip into circular aperture
            dist = np.sqrt((col - 3.5)**2 + (row - 3.5)**2)
            
            node = QFrame()
            node.setFixedSize(16, 16)
            if dist > 4.2:
                node.setStyleSheet("background-color: transparent;")
            else:
                node.setStyleSheet("background-color: rgba(50, 53, 60, 0.5); border-radius: 8px;")
                self.actuator_nodes.append(node)
                
            grid_layout.addWidget(node, row, col)

        layout.addWidget(grid_container)

    def pulse_actuators(self):
        """Simulates high-frequency mirror shape corrections."""
        for node in self.actuator_nodes:
            if random.random() > 0.65:
                node.setStyleSheet("background-color: #00cbe6; border-radius: 8px; border: 1px solid #5de6ff;")
            else:
                node.setStyleSheet("background-color: rgba(50, 53, 60, 0.5); border-radius: 8px;")


class SystemConsoleWidget(QFrame):
    """
    Clinical Mission Control Logging Console.
    Streams optical detection pipeline events with timestamped telemetry.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("GlassCard")
        self.setMinimumHeight(240)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(8)

        # Header Controls
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 4)
        
        title = QLabel("SYSTEM CONSOLE")
        title.setStyleSheet("color: #c7c4d7; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
        
        clear_btn = QPushButton("🗑  Clear")
        clear_btn.setStyleSheet("background: transparent; border: 1px solid #464554; padding: 4px 8px; font-size: 11px;")
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.clicked.connect(self.clear_logs)
        
        export_btn = QPushButton("📥  Export")
        export_btn.setStyleSheet("background: transparent; border: 1px solid #464554; padding: 4px 8px; font-size: 11px;")
        export_btn.setCursor(Qt.PointingHandCursor)
        export_btn.clicked.connect(self.export_logs)

        header_layout.addWidget(title)
        header_layout.addStretch()
        header_layout.addWidget(clear_btn)
        header_layout.addWidget(export_btn)
        layout.addWidget(header)

        # Scrollable Log Display
        self.log_area = QLabel()
        self.log_area.setStyleSheet("font-family: 'Geist', monospace; font-size: 12px; color: #e1e2eb; line-height: 1.5;")
        self.log_area.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.log_area.setWordWrap(True)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.log_area)
        scroll.setStyleSheet("background-color: #0b0e14; border: none; border-radius: 6px; padding: 8px;")
        layout.addWidget(scroll)

        self.logs_history = []
        self.append_log("READY", "Optical pipeline initialized.", "#4edea3")
        self.append_log("INFO", "SH-WFS-74-ALPHA sensor matrix linked.", "#00cbe6")

    def append_log(self, tag: str, message: str, color: str):
        """Adds timestamped entry to clinical event display."""
        ts = datetime.now().strftime("%H:%M:%S")
        formatted = f'<span style="color:#908fa0;">[{ts}]</span> <span style="color:{color}; font-weight:700;">{tag}</span> {message}'
        self.logs_history.append(formatted)
        if len(self.logs_history) > 40:
            self.logs_history.pop(0)
        self.log_area.setText("<br>".join(self.logs_history))

    @Slot()
    def clear_logs(self):
        self.logs_history.clear()
        self.append_log("INFO", "Console event buffer cleared.", "#c0c1ff")

    @Slot()
    def export_logs(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Export Telemetry Logs", "waveforge_console.log", "Text Files (*.log)")
        if file_path:
            with open(file_path, "w", encoding="utf-8") as f:
                for line in self.logs_history:
                    # Strip basic HTML tags for raw export
                    clean = line.replace('<span style="color:#908fa0;">', '').replace('</span>', '').replace('<span style="color:#4edea3; font-weight:700;">', '').replace('<span style="color:#00cbe6; font-weight:700;">', '').replace('<span style="color:#ffb4ab; font-weight:700;">', '')
                    f.write(clean + "\n")
            self.append_log("INFO", f"Saved console dump to {file_path}", "#4edea3")


class Dashboard(QWidget):
    """
    Master Dashboard & Mission Control View.
    Aggregates real-time optical streams, telemetry metric rails, DM status, and console logs.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.logger = logging.getLogger("WaveForge.Dashboard")
        self.is_processing = True
        self.init_ui()
        self.start_pipeline_simulation()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(20)

        # 1. Action Controls Header
        action_bar = QWidget()
        action_layout = QHBoxLayout(action_bar)
        action_layout.setContentsMargins(0, 0, 0, 0)
        action_layout.setSpacing(12)

        title = QLabel("LIVE ADAPTIVE OPTICS TELEMETRY")
        title.setStyleSheet("color: #ffffff; font-size: 16px; font-weight: 800; letter-spacing: 0.5px;")

        self.pause_btn = QPushButton("⏸  Pause Streams")
        self.pause_btn.setCursor(Qt.PointingHandCursor)
        self.pause_btn.clicked.connect(self.toggle_processing)

        reset_btn = QPushButton("🔄  Reset Pipeline")
        reset_btn.setCursor(Qt.PointingHandCursor)
        reset_btn.clicked.connect(self.reset_telemetry)

        action_layout.addWidget(title)
        action_layout.addStretch()
        action_layout.addWidget(self.pause_btn)
        action_layout.addWidget(reset_btn)
        layout.addWidget(action_bar)

        # 2. Main Bento Grid Content
        main_splitter = QSplitter(Qt.Horizontal)
        main_splitter.setHandleWidth(16)

        # Center Column: Dual Real-time Visualizations
        viz_container = QWidget()
        viz_layout = QVBoxLayout(viz_container)
        viz_layout.setContentsMargins(0, 0, 0, 0)
        viz_layout.setSpacing(16)

        dual_box = QFrame()
        dual_box.setObjectName("GlassCard")
        dual_layout = QVBoxLayout(dual_box)
        dual_layout.setContentsMargins(16, 16, 16, 16)
        dual_layout.setSpacing(12)

        viz_header = QHBoxLayout()
        viz_title = QLabel("REAL-TIME SHACK-HARTMANN VISUALIZATION")
        viz_title.setStyleSheet("color: #c7c4d7; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
        viz_header.addWidget(viz_title)
        viz_header.addStretch()
        dual_layout.addLayout(viz_header)

        images_layout = QHBoxLayout()
        images_layout.setSpacing(16)
        
        self.orig_frame = LiveSpotGridWidget("Original SH-WFS Frame", "#c0c1ff", show_centroids=False)
        self.processed_frame = LiveSpotGridWidget("Processed Centroid Slope", "#ffb4ab", show_centroids=True)
        
        images_layout.addWidget(self.orig_frame)
        images_layout.addWidget(self.processed_frame)
        dual_layout.addLayout(images_layout)
        viz_layout.addWidget(dual_box)

        # Bottom Row: Actuators + System Console
        bottom_row = QWidget()
        bottom_layout = QHBoxLayout(bottom_row)
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        bottom_layout.setSpacing(16)

        self.actuator_map = ActuatorStatusWidget()
        self.console = SystemConsoleWidget()

        bottom_layout.addWidget(self.actuator_map, stretch=4)
        bottom_layout.addWidget(self.console, stretch=8)
        viz_layout.addWidget(bottom_row)

        main_splitter.addWidget(viz_container)

        # Right Column: Engineering Statistics Rail
        stats_container = QWidget()
        stats_layout = QVBoxLayout(stats_container)
        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.setSpacing(14)

        stats_header = QLabel("ENGINEERING METRICS")
        stats_header.setStyleSheet("color: #908fa0; font-size: 11px; font-weight: 700; letter-spacing: 1px;")
        stats_layout.addWidget(stats_header)

        self.card_fried = MetricCard("Fried Parameter (r₀)", "cm", "#c0c1ff", "12.4")
        self.card_coherence = MetricCard("Coherence Time (τ₀)", "ms", "#5de6ff", "3.8")
        self.card_count = MetricCard("Centroid Count", "active", "#e1e2eb", "1,024")
        self.card_fps = MetricCard("Processing FPS", "Hz", "#4edea3", "120.4")
        self.card_rms = MetricCard("Wavefront RMS Error", "λ", "#ffb4ab", "0.084")

        stats_layout.addWidget(self.card_fried)
        stats_layout.addWidget(self.card_coherence)
        stats_layout.addWidget(self.card_count)
        stats_layout.addWidget(self.card_fps)
        stats_layout.addWidget(self.card_rms)
        stats_layout.addStretch()

        main_splitter.addWidget(stats_container)
        main_splitter.setStretchFactor(0, 8)
        main_splitter.setStretchFactor(1, 3)

        layout.addWidget(main_splitter)

    def start_pipeline_simulation(self):
        """Initializes high-frequency telemetry update loops."""
        self.sim_timer = QTimer(self)
        self.sim_timer.timeout.connect(self.process_simulated_frame)
        self.sim_timer.start(80) # ~12.5 FPS UI redraw rate

    @Slot()
    def process_simulated_frame(self):
        """Calculates live jitter and updates gauges."""
        if not self.is_processing:
            return

        jitter_x = np.sin(datetime.now().timestamp() * 2.0) * 0.4
        jitter_y = np.cos(datetime.now().timestamp() * 1.5) * 0.4

        # Redraw optical canvases
        self.orig_frame.render_optical_frame(jitter_x, jitter_y)
        self.processed_frame.render_optical_frame(jitter_x * 0.2, jitter_y * 0.2) # Jitter corrected

        # Pulse DM actuators
        self.actuator_map.pulse_actuators()

        # Update telemetry cards
        r0 = 12.4 + random.uniform(-0.15, 0.15)
        t0 = 3.8 + random.uniform(-0.05, 0.05)
        fps = 120.4 + random.uniform(-1.2, 1.2)
        rms = 0.084 + random.uniform(-0.003, 0.003)

        self.card_fried.update_value(r0)
        self.card_coherence.update_value(t0)
        self.card_fps.update_value(fps)
        self.card_rms.update_value(rms)

        # Sporadic warning events
        if random.random() > 0.98:
            act_num = random.randint(1, 64)
            self.console.append_log("WARN", f"Mirror actuator #{act_num} thermal variance spike.", "#ffb4ab")

    @Slot()
    def toggle_processing(self):
        """Pauses or resumes live analysis loops."""
        self.is_processing = not self.is_processing
        if self.is_processing:
            self.pause_btn.setText("⏸  Pause Streams")
            self.console.append_log("PROC", "Resumed real-time wavefront processing.", "#4edea3")
        else:
            self.pause_btn.setText("▶  Resume Streams")
            self.console.append_log("WARN", "Wavefront acquisition paused by user.", "#ffb4ab")

    @Slot()
    def reset_telemetry(self):
        """Resets gauges to baseline parameters."""
        self.card_fried.update_value(12.4)
        self.card_coherence.update_value(3.8)
        self.card_rms.update_value(0.040)
        self.console.append_log("INFO", "Optical calibration baseline restored.", "#00cbe6")
