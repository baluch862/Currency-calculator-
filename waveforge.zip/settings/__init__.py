"""Settings Module Initialization"""
