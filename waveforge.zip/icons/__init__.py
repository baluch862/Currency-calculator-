"""Icons Module Initialization"""
