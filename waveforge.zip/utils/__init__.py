"""
WaveForge Package Initialization
"""
