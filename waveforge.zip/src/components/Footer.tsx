import React from 'react';
import { Activity, Clock, ShieldCheck, Cpu } from 'lucide-react';

interface FooterProps {
  progress: number;
  fps: number;
  currentTimeUtc: string;
}

export const Footer: React.FC<FooterProps> = ({
  progress,
  fps,
  currentTimeUtc
}) => {
  return (
    <footer className="fixed bottom-0 left-0 right-0 z-50 h-8 bg-[#272a31] border-t border-[#464554]/30 flex items-center justify-between px-4 text-[11px] font-mono select-none text-[#c7c4d7]">
      {/* Left Hardware Link */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#4edea3] shadow-[0_0_6px_#4edea3]" />
          <span className="font-semibold text-white tracking-wide uppercase text-[10px]">
            SH-WFS-74 Hardware Link Active
          </span>
        </div>
        <div className="h-3 w-px bg-[#464554]" />
        <div className="flex items-center gap-3 text-[#908fa0]">
          <span>CPU: <strong className="text-[#5de6ff]">24.2%</strong></span>
          <span>GPU: <strong className="text-[#c0c1ff]">68.4%</strong> (CUDA)</span>
          <span>MEM: <strong className="text-white">4.2GB</strong></span>
        </div>
      </div>

      {/* Center Simulation Progress */}
      <div className="hidden sm:flex items-center gap-3 w-72">
        <span className="text-[10px] text-[#908fa0] uppercase shrink-0">Pipeline Progress</span>
        <div className="flex-1 h-1.5 bg-[#10131a] rounded-full overflow-hidden p-[1px]">
          <div 
            className="h-full bg-gradient-to-r from-[#494bd6] via-[#c0c1ff] to-[#00cbe6] rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-[#00cbe6] font-bold w-8 text-right shrink-0">{Math.round(progress)}%</span>
      </div>

      {/* Right UTC Clock & Frame Rate */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-[#4edea3]">
          <Activity className="w-3 h-3" />
          <span>{fps.toFixed(1)} FPS</span>
        </div>
        <div className="h-3 w-px bg-[#464554]" />
        <div className="flex items-center gap-1.5 text-[#00cbe6] font-semibold">
          <Clock className="w-3 h-3" />
          <span>{currentTimeUtc}</span>
        </div>
      </div>
    </footer>
  );
};
