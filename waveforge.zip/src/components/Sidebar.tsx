import React from 'react';
import { 
  LayoutDashboard, Database, Cpu, Target, Crosshair, 
  Waves, Activity, Wind, Grid, LineChart, FileOutput, 
  Settings, Info, Play, Pause, RotateCcw, LifeBuoy, Terminal, Wand2, Bot
} from 'lucide-react';
import { ModuleId } from '../types';

interface SidebarProps {
  activeModule: ModuleId;
  setActiveModule: (id: ModuleId) => void;
  isSimulating: boolean;
  onToggleSimulation: () => void;
  onResetPipeline: () => void;
}

interface NavGroup {
  category: string;
  items: { id: ModuleId; label: string; sub: string; icon: React.FC<{ className?: string }> }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  setActiveModule,
  isSimulating,
  onToggleSimulation,
  onResetPipeline
}) => {
  const groups: NavGroup[] = [
    {
      category: 'Mission Control',
      items: [
        { id: 'dashboard', label: 'Dashboard', sub: 'Telemetry Overview', icon: LayoutDashboard },
        { id: 'dataset', label: 'Dataset Manager', sub: 'SH-WFS Frames', icon: Database },
        { id: 'ai_assistant', label: 'AI Copilot', sub: 'Neural Advisor', icon: Bot },
      ]
    },
    {
      category: 'Optical Pipeline',
      items: [
        { id: 'sh_analysis', label: 'SH Analysis Suite', sub: '9-Stage Metrology', icon: Crosshair },
        { id: 'processing', label: 'Image Processing', sub: 'Noise & Filtering', icon: Cpu },
        { id: 'enhancement', label: 'Image Toolkit', sub: 'Advanced Enhance', icon: Wand2 },
        { id: 'spot_detection', label: 'Spot Detection', sub: 'Grid Localization', icon: Target },
        { id: 'centroid', label: 'Centroid Engine', sub: 'Sub-Pixel Slope', icon: Crosshair },
      ]
    },
    {
      category: 'Adaptive Optics',
      items: [
        { id: 'reconstruction', label: 'Reconstruction', sub: 'Modal Canvases', icon: Waves },
        { id: 'zernike', label: 'Zernike Analysis', sub: 'Coefficients Map', icon: Activity },
        { id: 'turbulence', label: 'Atmospheric r₀', sub: 'Turbulence Est', icon: Wind },
        { id: 'actuators', label: 'Actuator Map', sub: '8x8 Mirror Matrix', icon: Grid },
      ]
    },
    {
      category: 'Analytics & Export',
      items: [
        { id: 'visualization', label: '3D Surface Plots', sub: 'Phase Contours', icon: LineChart },
        { id: 'export', label: 'Data Export', sub: 'PDF & CSV Reports', icon: FileOutput },
        { id: 'settings', label: 'CUDA Settings', sub: 'Hardware Setup', icon: Settings },
        { id: 'about', label: 'About Project', sub: 'ISRO Hackathon', icon: Info },
      ]
    }
  ];

  return (
    <aside className="fixed left-0 top-16 bottom-8 w-[280px] bg-[#12151d] border-r border-[#464554]/20 flex flex-col justify-between z-40 select-none overflow-hidden">
      {/* Top Project Banner */}
      <div className="p-4 border-b border-[#464554]/20 bg-[#161b22]/50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-md bg-[#c0c1ff]/10 border border-[#c0c1ff]/30 flex items-center justify-center font-mono font-bold text-[#5de6ff] text-xs">
            PS9
          </div>
          <div className="overflow-hidden">
            <h2 className="text-xs font-bold text-[#c0c1ff] tracking-wider uppercase truncate">
              ISRO Hackathon 2026
            </h2>
            <p className="text-[10px] text-[#908fa0] truncate">
              Shack-Hartmann Wavefront
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Stack */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6 scrollbar-thin">
        {groups.map((grp) => (
          <div key={grp.category} className="space-y-1">
            <p className="px-3 text-[10px] font-bold text-[#908fa0] uppercase tracking-widest mb-2">
              {grp.category}
            </p>
            {grp.items.map((item) => {
              const Icon = item.icon;
              const isActive = activeModule === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveModule(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all relative ${
                    isActive
                      ? 'bg-[#00cbe6]/10 text-[#5de6ff] font-semibold'
                      : 'text-[#c7c4d7] hover:bg-[#32353c]/40 hover:text-white'
                  }`}
                >
                  {isActive && (
                    <span className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-[#00cbe6] rounded-r-full shadow-[0_0_8px_#00cbe6]" />
                  )}
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00cbe6]' : 'text-[#908fa0]'}`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs leading-tight truncate">{item.label}</p>
                    <p className="text-[9px] text-[#908fa0] truncate font-normal">{item.sub}</p>
                  </div>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Bottom Simulation Controls */}
      <div className="p-4 bg-[#161b22] border-t border-[#464554]/20 space-y-3">
        <button
          onClick={onToggleSimulation}
          className={`w-full h-11 rounded-lg font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 ${
            isSimulating
              ? 'bg-[#ffb4ab] text-[#690005] hover:bg-[#ffdad6]'
              : 'bg-gradient-to-r from-[#494bd6] to-[#00cbe6] text-white hover:brightness-110 shadow-[0_4px_20px_rgba(0,203,230,0.25)]'
          }`}
        >
          {isSimulating ? (
            <>
              <Pause className="w-4 h-4 fill-current" /> Pause Simulation
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" /> Run Simulation
            </>
          )}
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={onResetPipeline}
            title="Reset Optical Pipeline"
            className="flex-1 py-2 rounded-md border border-[#464554]/40 hover:border-[#5de6ff] bg-[#10131a] text-[#c7c4d7] hover:text-[#5de6ff] text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Reset Canvases
          </button>
          <button
            onClick={() => setActiveModule('settings')}
            title="Console & Diagnostic Logs"
            className="p-2 rounded-md border border-[#464554]/40 hover:border-[#c0c1ff] bg-[#10131a] text-[#c7c4d7] hover:text-white transition-colors"
          >
            <Terminal className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
