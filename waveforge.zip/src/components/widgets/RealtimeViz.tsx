import React, { useEffect, useRef, useState } from 'react';
import { Eye, Layers, Maximize2, RotateCcw } from 'lucide-react';

interface RealtimeVizProps {
  isSimulating: boolean;
}

export const RealtimeViz: React.FC<RealtimeVizProps> = ({ isSimulating }) => {
  const [viewMode, setViewMode] = useState<'dual' | 'overlay'>('dual');
  const canvasRef1 = useRef<HTMLCanvasElement>(null);
  const canvasRef2 = useRef<HTMLCanvasElement>(null);

  // Render simulated Shack Hartmann spot grid on canvas
  useEffect(() => {
    let animationId: number;
    let angle = 0;

    const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number, isCentroid: boolean) => {
      ctx.fillStyle = '#080b10';
      ctx.fillRect(0, 0, width, height);

      const cols = 12;
      const rows = 9;
      const cellW = width / (cols + 1);
      const cellH = height / (rows + 1);

      for (let c = 1; c <= cols; c++) {
        for (let r = 1; r <= rows; r++) {
          const baseX = c * cellW;
          const baseY = r * cellH;

          // Add simulated turbulence aberration
          const jitterX = isSimulating ? Math.sin(angle + c * 0.5) * 3.5 : 0;
          const jitterY = isSimulating ? Math.cos(angle + r * 0.4) * 3.5 : 0;

          const spotX = baseX + jitterX;
          const spotY = baseY + jitterY;

          // Draw Glowing Spot
          const grad = ctx.createRadialGradient(spotX, spotY, 1, spotX, spotY, 9);
          if (isCentroid) {
            grad.addColorStop(0, 'rgba(0, 203, 230, 0.95)');
            grad.addColorStop(0.5, 'rgba(73, 75, 214, 0.4)');
            grad.addColorStop(1, 'rgba(16, 19, 26, 0)');
          } else {
            grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
            grad.addColorStop(0.4, 'rgba(192, 193, 255, 0.6)');
            grad.addColorStop(1, 'rgba(16, 19, 26, 0)');
          }

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(spotX, spotY, 9, 0, Math.PI * 2);
          ctx.fill();

          // If processed view, draw red crosshair centroid markers & slope vectors
          if (isCentroid) {
            ctx.strokeStyle = '#ffb4ab';
            ctx.lineWidth = 1.2;

            // Crosshair
            ctx.beginPath();
            ctx.moveTo(spotX - 5, spotY);
            ctx.lineTo(spotX + 5, spotY);
            ctx.moveTo(spotX, spotY - 5);
            ctx.lineTo(spotX, spotY + 5);
            ctx.stroke();

            // Slope deviation line
            ctx.strokeStyle = 'rgba(255, 180, 171, 0.4)';
            ctx.beginPath();
            ctx.moveTo(baseX, baseY);
            ctx.lineTo(spotX, spotY);
            ctx.stroke();
          }
        }
      }
    };

    const render = () => {
      angle += 0.08;
      if (canvasRef1.current) {
        const c1 = canvasRef1.current;
        drawGrid(c1.getContext('2d')!, c1.width, c1.height, false);
      }
      if (canvasRef2.current) {
        const c2 = canvasRef2.current;
        drawGrid(c2.getContext('2d')!, c2.width, c2.height, true);
      }
      animationId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationId);
  }, [isSimulating]);

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-xl overflow-hidden flex flex-col shadow-lg">
      {/* Header */}
      <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb]">
          Real-time Shack-Hartmann Visualization
        </h3>
        <div className="flex items-center gap-1.5 bg-[#10131a] p-1 rounded-lg border border-[#464554]/20">
          <button
            onClick={() => setViewMode('dual')}
            className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all ${
              viewMode === 'dual'
                ? 'bg-[#00cbe6]/20 text-[#00cbe6] border border-[#00cbe6]/40 shadow-sm'
                : 'text-[#908fa0] hover:text-white'
            }`}
          >
            Dual View
          </button>
          <button
            onClick={() => setViewMode('overlay')}
            className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all ${
              viewMode === 'overlay'
                ? 'bg-[#00cbe6]/20 text-[#00cbe6] border border-[#00cbe6]/40 shadow-sm'
                : 'text-[#908fa0] hover:text-white'
            }`}
          >
            Overlay
          </button>
        </div>
      </div>

      {/* Canvases View */}
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4 h-[260px]">
        {/* Original Frame Canvas */}
        <div className="relative rounded-lg overflow-hidden border border-[#464554]/40 bg-black group flex flex-col">
          <canvas ref={canvasRef1} width={450} height={260} className="w-full h-full object-cover" />
          <div className="absolute top-2.5 left-2.5 px-2.5 py-1 bg-black/70 backdrop-blur rounded border border-white/10 font-mono text-[10px] text-[#c0c1ff] uppercase">
            Raw SH-WFS Frame
          </div>
        </div>

        {/* Centroid Detected Canvas */}
        <div className="relative rounded-lg overflow-hidden border border-[#464554]/40 bg-black group flex flex-col">
          <canvas ref={canvasRef2} width={450} height={260} className="w-full h-full object-cover" />
          <div className="absolute top-2.5 left-2.5 px-2.5 py-1 bg-black/70 backdrop-blur rounded border border-white/10 font-mono text-[10px] text-[#ffb4ab] uppercase flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#ffb4ab] animate-ping" /> Processed Centroids & Slopes
          </div>
        </div>
      </div>
    </div>
  );
};
