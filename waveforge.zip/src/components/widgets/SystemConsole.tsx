import React, { useEffect, useRef } from 'react';
import { Terminal, Trash2, Download } from 'lucide-react';
import { LogEntry } from '../../types';

interface SystemConsoleProps {
  logs: LogEntry[];
  onClear: () => void;
}

export const SystemConsole: React.FC<SystemConsoleProps> = ({ logs, onClear }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleExport = () => {
    const text = logs.map((l) => `[${l.timestamp}] [${l.level}] ${l.message}`).join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `waveforge_console_${new Date().toISOString().slice(0, 10)}.log`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getBadgeColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'READY':
        return 'text-[#4edea3] font-bold';
      case 'INFO':
        return 'text-[#00cbe6] font-bold';
      case 'PROC':
        return 'text-[#c0c1ff] font-bold';
      case 'WARN':
        return 'text-[#ffb4ab] font-bold animate-pulse';
      case 'ERROR':
        return 'text-[#ffb4ab] bg-[#93000a] px-1 rounded font-bold';
    }
  };

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-xl overflow-hidden flex flex-col h-64 shadow-lg select-none">
      {/* Header */}
      <div className="p-3 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
          <Terminal className="w-4 h-4 text-[#c0c1ff]" /> Clinical System Console
        </h3>
        <div className="flex items-center gap-2">
          <button
            onClick={onClear}
            title="Clear Console Event Buffer"
            className="px-2.5 py-1 rounded border border-[#464554] hover:border-[#ffb4ab] text-[#c7c4d7] hover:text-[#ffb4ab] text-[10px] font-semibold flex items-center gap-1 transition-colors bg-[#10131a]"
          >
            <Trash2 className="w-3 h-3" /> Clear
          </button>
          <button
            onClick={handleExport}
            title="Download Telemetry Log Dump"
            className="px-2.5 py-1 rounded border border-[#464554] hover:border-[#00cbe6] text-[#c7c4d7] hover:text-[#00cbe6] text-[10px] font-semibold flex items-center gap-1 transition-colors bg-[#10131a]"
          >
            <Download className="w-3 h-3" /> Export Dump
          </button>
        </div>
      </div>

      {/* Log Stream Area */}
      <div className="flex-1 bg-[#0b0e14] p-3.5 overflow-y-auto font-mono text-xs space-y-1.5 scrollbar-thin scrollbar-thumb-[#32353c]">
        {logs.map((log) => (
          <div key={log.id} className="flex items-start gap-2.5 leading-relaxed hover:bg-[#161b22]/50 px-1 rounded transition-colors">
            <span className="text-[#908fa0] shrink-0 font-medium">[{log.timestamp}]</span>
            <span className={`shrink-0 w-11 text-center ${getBadgeColor(log.level)}`}>
              {log.level}
            </span>
            <span className="text-[#e1e2eb] break-words">{log.message}</span>
          </div>
        ))}
        <div ref={bottomRef} className="flex items-center gap-1 text-[#00cbe6] font-bold pt-1">
          <span>&gt;</span>
          <span className="w-2 h-4 bg-[#00cbe6] animate-pulse rounded-sm" />
        </div>
      </div>
    </div>
  );
};
