import React, { useRef } from 'react';
import { Database, Upload, Folder, Image as ImageIcon, CheckCircle2 } from 'lucide-react';
import { FrameMetadata } from '../../types';

interface DatasetInputProps {
  metadata: FrameMetadata;
  selectedFile: string;
  onSelectFile: (file: string) => void;
  onUploadFiles: (files: FileList | null) => void;
}

export const DatasetInput: React.FC<DatasetInputProps> = ({
  metadata,
  selectedFile,
  onSelectFile,
  onUploadFiles
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  const mockFiles = [
    'frame_0001_calib.fits',
    'frame_0002_turb.fits',
    'frame_0003_recon.fits',
    'frame_0004_zernike.fits',
    'frame_0005_nominal.fits',
  ];

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) {
      onUploadFiles(e.dataTransfer.files);
    }
  };

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-xl overflow-hidden flex flex-col h-full shadow-lg">
      {/* Card Header */}
      <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
          <Database className="w-4 h-4 text-[#c0c1ff]" /> Dataset Input
        </h3>
        <span className="text-[10px] font-mono text-[#4edea3] bg-[#00885d]/20 px-2 py-0.5 rounded border border-[#4edea3]/30">
          SH-WFS Active
        </span>
      </div>

      <div className="p-4 flex-1 overflow-y-auto space-y-5 scrollbar-thin flex flex-col">
        {/* Drop Zone */}
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => inputRef.current?.click()}
          className="border-2 border-dashed border-[#464554] hover:border-[#00cbe6] rounded-xl p-6 flex flex-col items-center justify-center text-center gap-2.5 transition-all cursor-pointer bg-[#10131a]/40 group"
        >
          <input
            ref={inputRef}
            type="file"
            multiple
            accept=".fits,.tiff,.raw,.png"
            onChange={(e) => onUploadFiles(e.target.files)}
            className="hidden"
          />
          <div className="w-12 h-12 rounded-full bg-[#32353c] group-hover:bg-[#00cbe6]/10 flex items-center justify-center transition-colors">
            <Upload className="w-6 h-6 text-[#c7c4d7] group-hover:text-[#00cbe6] transition-colors" />
          </div>
          <div>
            <p className="text-sm font-semibold text-[#e1e2eb] group-hover:text-[#5de6ff] transition-colors">
              Drop SH-WFS frames
            </p>
            <p className="text-[11px] text-[#908fa0]">Supports .FITS, .TIFF, .RAW arrays</p>
          </div>
        </div>

        {/* Metadata Configuration */}
        <div className="space-y-2">
          <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">
            Metadata Configuration
          </p>
          <div className="space-y-1.5 font-mono text-xs">
            <div className="flex items-center justify-between p-2 bg-[#32353c]/60 rounded-lg border border-[#464554]/20">
              <span className="text-[#c7c4d7]">Resolution</span>
              <span className="text-[#5de6ff] font-bold">{metadata.resolution}</span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#32353c]/60 rounded-lg border border-[#464554]/20">
              <span className="text-[#c7c4d7]">Bit Depth</span>
              <span className="text-[#c0c1ff] font-bold">{metadata.bitDepth}</span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#32353c]/60 rounded-lg border border-[#464554]/20">
              <span className="text-[#c7c4d7]">Exposure</span>
              <span className="text-[#4edea3] font-bold">{metadata.exposure}</span>
            </div>
          </div>
        </div>

        {/* File Explorer Tree */}
        <div className="space-y-2 flex-1 flex flex-col min-h-[140px]">
          <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">
            Active Run Explorer
          </p>
          <div className="bg-[#10131a] rounded-lg border border-[#464554]/30 p-2 space-y-1 overflow-y-auto flex-1 font-mono text-xs">
            <div className="flex items-center gap-2 p-1.5 text-[#c0c1ff] font-semibold bg-[#32353c]/40 rounded">
              <Folder className="w-3.5 h-3.5 text-[#8083ff]" />
              <span>run_2026_10_24_isro</span>
            </div>
            <div className="pl-4 space-y-1 mt-1">
              {mockFiles.map((f) => {
                const isSelected = selectedFile === f;
                return (
                  <button
                    key={f}
                    onClick={() => onSelectFile(f)}
                    className={`w-full flex items-center justify-between p-1.5 rounded transition-colors text-left ${
                      isSelected
                        ? 'bg-[#00cbe6]/15 text-[#5de6ff] font-medium'
                        : 'text-[#c7c4d7] hover:bg-[#32353c]/50 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <ImageIcon className="w-3.5 h-3.5 shrink-0 opacity-70" />
                      <span className="truncate">{f}</span>
                    </div>
                    {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-[#00cbe6] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
