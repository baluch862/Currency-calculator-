import React, { useEffect, useRef, useState } from 'react';
import { Waves, Maximize2, Sliders } from 'lucide-react';

interface WavefrontMapProps {
  isSimulating: boolean;
}

export const WavefrontMap: React.FC<WavefrontMapProps> = ({ isSimulating }) => {
  const [zernikeModes, setZernikeModes] = useState<number>(32);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Render 2D/3D Zernike Wavefront Surface Simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let animId: number;
    let t = 0;

    const render = () => {
      t += isSimulating ? 0.05 : 0;
      const w = canvas.width;
      const h = canvas.height;

      const imgData = ctx.createImageData(w, h);
      const data = imgData.data;

      for (let x = 0; x < w; x++) {
        for (let y = 0; y < h; y++) {
          const nx = (x / w - 0.5) * 4;
          const ny = (y / h - 0.5) * 4;
          const r = Math.sqrt(nx * nx + ny * ny);

          // Simulated Zernike Phase Wavefront formula
          if (r > 1.8) {
            const idx = (y * w + x) * 4;
            data[idx] = 16;
            data[idx + 1] = 19;
            data[idx + 2] = 26;
            data[idx + 3] = 255;
            continue;
          }

          const phase = Math.sin(nx * 2 + t) * Math.cos(ny * 2 - t * 0.5) + Math.sin(r * 4 - t);
          const norm = (phase + 2) / 4; // 0 to 1

          const idx = (y * w + x) * 4;

          // Color Palette: Electric Indigo (#c0c1ff) -> Cyan (#00cbe6) -> Rose Alert (#ffb4ab)
          if (norm < 0.4) {
            // Indigo
            data[idx] = Math.floor(73 + norm * 100);
            data[idx + 1] = Math.floor(75 + norm * 100);
            data[idx + 2] = 214;
          } else if (norm < 0.75) {
            // Cyan
            data[idx] = 0;
            data[idx + 1] = Math.floor(203 * norm);
            data[idx + 2] = Math.floor(230);
          } else {
            // Rose Alert
            data[idx] = 255;
            data[idx + 1] = Math.floor(180 - (norm - 0.75) * 200);
            data[idx + 2] = Math.floor(171 - (norm - 0.75) * 200);
          }
          data[idx + 3] = 255;
        }
      }

      ctx.putImageData(imgData, 0, 0);

      // Add circular aperture outline
      ctx.strokeStyle = '#00cbe6';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, (w / 2) * 0.88, 0, Math.PI * 2);
      ctx.stroke();

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [isSimulating, zernikeModes]);

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-xl overflow-hidden flex flex-col flex-1 min-h-[340px] shadow-lg">
      {/* Header */}
      <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
          <Waves className="w-4 h-4 text-[#00cbe6]" /> Wavefront Phase Reconstruction Map
        </h3>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-[#10131a] px-3 py-1 rounded-lg border border-[#464554]/30 font-mono text-xs">
            <span className="text-[#908fa0]">Zernike Expansion:</span>
            <span className="text-[#5de6ff] font-bold">{zernikeModes} Modes</span>
            <input
              type="range"
              min="4"
              max="64"
              step="4"
              value={zernikeModes}
              onChange={(e) => setZernikeModes(Number(e.target.value))}
              className="w-20 accent-[#00cbe6] ml-2 cursor-pointer h-1"
            />
          </div>
          <button title="Full Screen View" className="text-[#c7c4d7] hover:text-[#5de6ff]">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Surface Render */}
      <div className="flex-1 relative bg-[#0b0e14] flex items-center justify-center p-4">
        <canvas ref={canvasRef} width={400} height={280} className="w-full max-w-[420px] h-full object-contain rounded-full shadow-[0_0_40px_rgba(0,203,230,0.15)]" />

        {/* Right Scale Rail (+2.4λ to -2.4λ) */}
        <div className="absolute bottom-6 right-6 flex items-center gap-2 pointer-events-none select-none bg-[#10131a]/80 p-2 rounded-lg border border-[#464554]/30">
          <div className="w-3 h-28 bg-gradient-to-t from-[#ffb4ab] via-[#00cbe6] to-[#494bd6] rounded-full border border-white/20" />
          <div className="flex flex-col justify-between h-28 text-[10px] font-mono text-[#c7c4d7] font-semibold">
            <span>+2.4 λ</span>
            <span>0.0 λ</span>
            <span>-2.4 λ</span>
          </div>
        </div>
      </div>
    </div>
  );
};
