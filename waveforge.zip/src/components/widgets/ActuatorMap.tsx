import React, { useEffect, useState } from 'react';
import { Grid, ShieldAlert, Cpu } from 'lucide-react';

interface ActuatorMapProps {
  isSimulating: boolean;
}

export const ActuatorMap: React.FC<ActuatorMapProps> = ({ isSimulating }) => {
  const [activeVoltages, setActiveVoltages] = useState<number[]>(() => Array(64).fill(0));

  // Simulate closed-loop high voltage actuator corrections
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setActiveVoltages((prev) =>
        prev.map((_, i) => {
          // Circular mask calculation
          const c = i % 8;
          const r = Math.floor(i / 8);
          const dist = Math.sqrt(Math.pow(c - 3.5, 2) + Math.pow(r - 3.5, 2));
          if (dist > 4.2) return 0;
          return Math.random() > 0.65 ? Math.random() : 0.15;
        })
      );
    }, 200);

    return () => clearInterval(interval);
  }, [isSimulating]);

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-xl overflow-hidden flex flex-col h-64 shadow-lg select-none">
      {/* Header */}
      <div className="p-3.5 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
          <Grid className="w-4 h-4 text-[#5de6ff]" /> Actuator Map (8x8 Deformable Mirror)
        </h3>
        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="text-[#908fa0]">HV STATUS:</span>
          <span className="text-[#00cbe6] font-bold bg-[#00cbe6]/10 px-2 py-0.5 rounded border border-[#00cbe6]/30">
            MIRROR NOMINAL
          </span>
        </div>
      </div>

      {/* Grid Canvas Area */}
      <div className="flex-1 bg-[#0b0e14] flex items-center justify-center p-4">
        <div className="grid grid-cols-8 gap-2 bg-[#10131a] p-3 rounded-full border border-[#464554]/30 shadow-inner">
          {activeVoltages.map((v, i) => {
            const c = i % 8;
            const r = Math.floor(i / 8);
            const dist = Math.sqrt(Math.pow(c - 3.5, 2) + Math.pow(r - 3.5, 2));

            if (dist > 4.2) {
              return <div key={i} className="w-4 h-4 opacity-0 pointer-events-none" />;
            }

            const isSpike = v > 0.8;
            return (
              <div
                key={i}
                title={`Actuator #${i + 1} | ${(v * 120).toFixed(1)}V`}
                className={`w-4 h-4 rounded-full transition-all duration-150 cursor-pointer ${
                  isSpike
                    ? 'bg-[#00cbe6] shadow-[0_0_12px_#00cbe6] scale-110'
                    : v > 0.3
                    ? 'bg-[#494bd6]'
                    : 'bg-[#32353c]/60 hover:bg-[#c0c1ff]'
                }`}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
};
