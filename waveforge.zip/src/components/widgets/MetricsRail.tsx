import React from 'react';
import { Eye, Clock, Hash, Activity, AlertTriangle } from 'lucide-react';
import { MetricData } from '../../types';

interface MetricsRailProps {
  metrics: MetricData;
}

export const MetricsRail: React.FC<MetricsRailProps> = ({ metrics }) => {
  const cards = [
    {
      title: 'Fried Parameter (r₀)',
      val: metrics.friedParameter.toFixed(2),
      unit: 'cm',
      color: '#c0c1ff', // Indigo
      border: 'border-l-[#c0c1ff]',
      icon: Eye
    },
    {
      title: 'Coherence Time (τ₀)',
      val: metrics.coherenceTime.toFixed(2),
      unit: 'ms',
      color: '#5de6ff', // Cyan
      border: 'border-l-[#00cbe6]',
      icon: Clock
    },
    {
      title: 'Centroid Count',
      val: metrics.centroidCount.toLocaleString(),
      unit: 'active',
      color: '#e1e2eb',
      border: 'border-l-[#908fa0]',
      icon: Hash
    },
    {
      title: 'Processing FPS',
      val: metrics.fps.toFixed(1),
      unit: 'Hz',
      color: '#4edea3', // Emerald
      border: 'border-l-[#4edea3]',
      icon: Activity
    },
    {
      title: 'Wavefront RMS Error',
      val: metrics.rmsError.toFixed(3),
      unit: 'λ',
      color: '#ffb4ab', // Rose Alert
      border: 'border-l-[#ffb4ab]',
      icon: AlertTriangle
    }
  ];

  return (
    <div className="flex flex-col gap-4 justify-between h-full select-none">
      <div className="flex items-center justify-between pb-1 border-b border-[#464554]/30">
        <span className="text-[11px] font-bold tracking-widest text-[#908fa0] uppercase">
          Engineering Telemetry
        </span>
        <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-pulse" />
      </div>

      <div className="space-y-4 flex-1 flex flex-col justify-between">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div
              key={c.title}
              className={`bg-[#161b22]/80 backdrop-blur-md border border-[#464554]/30 border-l-4 ${c.border} rounded-xl p-4 flex flex-col justify-between transition-all hover:bg-[#272a31]/60 shadow-md group`}
            >
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold tracking-wider text-[#c7c4d7] uppercase group-hover:text-white transition-colors">
                  {c.title}
                </span>
                <Icon className="w-3.5 h-3.5 text-[#908fa0] group-hover:text-[#5de6ff] transition-colors" />
              </div>

              <div className="flex items-baseline gap-2 mt-2">
                <span 
                  className="font-mono text-3xl font-extrabold tracking-tight"
                  style={{ color: c.color }}
                >
                  {c.val}
                </span>
                <span className="text-xs font-semibold text-[#908fa0]">{c.unit}</span>
              </div>

              {/* Decorative Mini Meter Rail */}
              <div className="mt-2.5 h-1 w-full bg-[#10131a] rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-300"
                  style={{ 
                    backgroundColor: c.color,
                    width: `${Math.min(100, Math.max(15, Number(c.val) * 6))}%`,
                    boxShadow: `0 0 8px ${c.color}`
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
