import React from 'react';
import { Activity, Settings, User, Radio, Waves, ShieldAlert } from 'lucide-react';

interface HeaderProps {
  activeWorkspace: 'workspace' | 'analysis' | 'hardware';
  setActiveWorkspace: (ws: 'workspace' | 'analysis' | 'hardware') => void;
  onOpenSettings: () => void;
  isSimulating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeWorkspace,
  setActiveWorkspace,
  onOpenSettings,
  isSimulating
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-16 bg-[#1d2026]/90 backdrop-blur-md border-b border-[#464554]/30 flex items-center justify-between px-6 select-none">
      {/* Left Branding */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-[#8083ff] flex items-center justify-center shadow-[0_0_15px_rgba(128,131,255,0.4)]">
            <Waves className="w-5 h-5 text-[#1000a9] stroke-[2.5]" />
          </div>
          <span className="text-2xl font-bold tracking-tight text-[#c0c1ff]">WaveForge</span>
        </div>

        {/* Workspace Switcher Tabs */}
        <nav className="hidden md:flex items-center gap-1 ml-6 bg-[#10131a]/60 p-1 rounded-lg border border-[#464554]/20">
          {(['workspace', 'analysis', 'hardware'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveWorkspace(tab)}
              className={`px-4 py-1.5 rounded-md text-xs font-semibold capitalize transition-all ${
                activeWorkspace === tab
                  ? 'bg-[#494bd6] text-white shadow-sm'
                  : 'text-[#c7c4d7] hover:text-white hover:bg-[#32353c]/50'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Right Controls & Telemetry */}
      <div className="flex items-center gap-4">
        {/* Live Telemetry Indicator Pill */}
        <div className="flex items-center gap-2.5 px-3.5 py-1.5 bg-[#32353c] rounded-full border border-[#464554]/50 shadow-inner">
          <Radio className="w-3.5 h-3.5 text-[#00cbe6] animate-pulse" />
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#e1e2eb]">
            {isSimulating ? 'Acquisition Live' : 'System Standby'}
          </span>
          <span className={`w-2 h-2 rounded-full ${isSimulating ? 'bg-[#4edea3] shadow-[0_0_8px_#4edea3] animate-ping' : 'bg-[#ffb4ab]'}`} />
        </div>

        {/* Quick Tools */}
        <div className="flex items-center gap-1 border-l border-[#464554]/30 pl-3">
          <button
            onClick={onOpenSettings}
            title="Hardware & CUDA Settings"
            className="p-2 text-[#c7c4d7] hover:text-[#5de6ff] hover:bg-[#32353c] rounded-lg transition-colors"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            title="Lead Researcher Profile"
            className="p-2 text-[#c7c4d7] hover:text-[#c0c1ff] hover:bg-[#32353c] rounded-lg transition-colors"
          >
            <User className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
