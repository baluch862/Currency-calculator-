import React from 'react';
import { ModuleId } from '../types';
import { 
  Database, Cpu, Target, Crosshair, Waves, Activity, 
  Wind, Grid, LineChart, FileOutput, Settings, Info, Zap, CheckCircle2, Sliders 
} from 'lucide-react';

interface ModuleViewProps {
  moduleId: ModuleId;
  onTriggerSimulation: () => void;
  onOpenSettings: () => void;
}

export const ModuleView: React.FC<ModuleViewProps> = ({
  moduleId,
  onTriggerSimulation,
  onOpenSettings
}) => {
  const getModuleInfo = (id: ModuleId) => {
    switch (id) {
      case 'dataset':
        return {
          title: 'Dataset Manager & SH-WFS Frame Pipeline',
          desc: 'Ingest raw astronomical wavefront arrays (.FITS, .TIFF, .RAW), calibrate bias frames, and configure lenslet pitch parameters.',
          icon: Database,
          badge: 'BATCH INGEST ACTIVE'
        };
      case 'processing':
        return {
          title: 'CUDA Image Preprocessing & Filtering',
          desc: 'Apply multi-threaded 2D Gaussian blurs, adaptive background subtraction, and high-speed median filters to suppress CCD read noise.',
          icon: Cpu,
          badge: 'CUDA CORES ONLINE'
        };
      case 'spot_detection':
        return {
          title: 'Lenslet Spot Grid Localization',
          desc: 'Automated search algorithms detecting high-intensity Shack-Hartmann spot arrays across 74 active lenslet sub-apertures.',
          icon: Target,
          badge: '74 LENSLETS LOCKED'
        };
      case 'centroid':
        return {
          title: 'Sub-Pixel Centroid & Slope Calculator',
          desc: 'Calculate precise Center of Gravity (CoG) and Weighted Centroids to derive real-time local wavefront vector gradient deviations.',
          icon: Crosshair,
          badge: 'SUB-PIXEL SLOPE'
        };
      case 'reconstruction':
        return {
          title: 'Modal Wavefront Reconstruction Solvers',
          desc: 'Execute Southwell, Hudgin, and Fried zonal phase reconstruction geometries converting vector slopes into continuous 3D phase maps.',
          icon: Waves,
          badge: 'SOUTHWELL GEOMETRY'
        };
      case 'zernike':
        return {
          title: 'Zernike Polynomial Expansion Analysis',
          desc: 'Decompose optical phase aberrations into orthogonal Zernike polynomials up to 64 radial degrees (Tip, Tilt, Defocus, Astigmatism, Coma).',
          icon: Activity,
          badge: '64 POLYNOMIAL MODES'
        };
      case 'turbulence':
        return {
          title: 'Atmospheric Turbulence Characterization',
          desc: 'Derive astronomical Fried parameter (r₀) and atmospheric coherence time (τ₀) from wavefront variance statistics.',
          icon: Wind,
          badge: 'FRIED r₀ ESTIMATION'
        };
      case 'actuators':
        return {
          title: 'Deformable Mirror Modal Matrix',
          desc: 'Map reconstructed phase error inverses directly onto 64 high-voltage electrostatic mirror actuators.',
          icon: Grid,
          badge: 'CLOSED LOOP ACTIVE'
        };
      case 'visualization':
        return {
          title: 'High-Resolution 3D Surface Plots',
          desc: 'Render interactive WebGL optical phase contours, interferograms, and Point Spread Function (PSF) intensity profiles.',
          icon: LineChart,
          badge: 'WEBGL 3D CANVAS'
        };
      case 'export':
        return {
          title: 'ISRO Research Report Generator',
          desc: 'Export formal scientific PDF telemetry dossiers, CSV raw slope vectors, and Python NumPy arrays for downstream publishing.',
          icon: FileOutput,
          badge: 'RESEARCH DOSSIER READY'
        };
      case 'settings':
        return {
          title: 'Hardware Link & CUDA Preferences',
          desc: 'Configure Shack-Hartmann camera USB3/GigE interfaces, NVIDIA CUDA thread allocations, and dark theme legibility contrast.',
          icon: Settings,
          badge: 'SYSTEM CONFIG'
        };
      case 'about':
      default:
        return {
          title: 'About WaveForge & ISRO Hackathon 2026',
          desc: 'Engineered for Problem Statement 9: Shack-Hartmann Wavefront Sensor Analysis & Adaptive Optics Reconstruction.',
          icon: Info,
          badge: 'BHARATIYA ANTARIKSH 2026'
        };
    }
  };

  const info = getModuleInfo(moduleId);
  const Icon = info.icon;

  return (
    <div className="bg-[#161b22]/75 backdrop-blur-md border border-[#464554]/30 rounded-2xl p-8 md:p-12 shadow-2xl min-h-[600px] flex flex-col justify-between select-none">
      <div className="space-y-6 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00cbe6]/10 border border-[#00cbe6]/30 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-wider">
          <CheckCircle2 className="w-3.5 h-3.5" /> {info.badge}
        </div>

        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#494bd6]/20 border border-[#c0c1ff]/30 flex items-center justify-center shadow-lg">
            <Icon className="w-8 h-8 text-[#5de6ff]" />
          </div>
          <h2 className="text-2xl md:text-4xl font-extrabold text-white tracking-tight">
            {info.title}
          </h2>
        </div>

        <p className="text-[#c7c4d7] text-base md:text-lg leading-relaxed">
          {info.desc}
        </p>

        {/* Mock Parameter Configuration Box */}
        <div className="p-6 rounded-xl bg-[#10131a] border border-[#464554]/30 space-y-4 font-mono text-xs text-[#e1e2eb]">
          <p className="text-[#908fa0] uppercase tracking-widest font-bold text-[10px]">
            Module Pipeline Status
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-3 bg-[#1d2026] rounded border border-white/5">
              <span className="text-[#908fa0]">EXECUTION:</span> <strong className="text-[#4edea3]">READY</strong>
            </div>
            <div className="p-3 bg-[#1d2026] rounded border border-white/5">
              <span className="text-[#908fa0]">LATENCY:</span> <strong className="text-[#00cbe6]">1.24 ms</strong>
            </div>
            <div className="p-3 bg-[#1d2026] rounded border border-white/5">
              <span className="text-[#908fa0]">PRECISION:</span> <strong className="text-[#c0c1ff]">64-BIT FLOAT</strong>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-8 border-t border-[#464554]/20 flex flex-wrap items-center gap-4">
        <button
          onClick={onTriggerSimulation}
          className="px-6 py-3 rounded-lg bg-[#494bd6] hover:bg-[#5b5de6] text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-[0_0_20px_rgba(73,75,214,0.4)] transition-all"
        >
          <Zap className="w-4 h-4 fill-current text-[#5de6ff]" /> Launch Module Analysis Loop
        </button>
        <button
          onClick={onOpenSettings}
          className="px-6 py-3 rounded-lg bg-[#272a31] hover:bg-[#32353c] border border-[#464554] text-[#c7c4d7] hover:text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all"
        >
          <Sliders className="w-4 h-4" /> Configure Sensor Diagnostics
        </button>
      </div>
    </div>
  );
};
