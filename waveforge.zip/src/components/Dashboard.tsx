import React from 'react';
import { FrameMetadata, LogEntry, MetricData } from '../types';
import { DatasetInput } from './widgets/DatasetInput';
import { RealtimeViz } from './widgets/RealtimeViz';
import { WavefrontMap } from './widgets/WavefrontMap';
import { MetricsRail } from './widgets/MetricsRail';
import { ActuatorMap } from './widgets/ActuatorMap';
import { SystemConsole } from './widgets/SystemConsole';

interface DashboardProps {
  metadata: FrameMetadata;
  selectedFile: string;
  onSelectFile: (file: string) => void;
  onUploadFiles: (files: FileList | null) => void;
  isSimulating: boolean;
  metrics: MetricData;
  logs: LogEntry[];
  onClearLogs: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  metadata,
  selectedFile,
  onSelectFile,
  onUploadFiles,
  isSimulating,
  metrics,
  logs,
  onClearLogs
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-5 min-h-[calc(100vh-10rem)] pb-6">
      {/* Top Section Bento: Left Input (col-3) | Center Canvases (col-6) | Right Telemetry (col-3) */}
      <div className="md:col-span-3 h-[620px]">
        <DatasetInput
          metadata={metadata}
          selectedFile={selectedFile}
          onSelectFile={onSelectFile}
          onUploadFiles={onUploadFiles}
        />
      </div>

      <div className="md:col-span-6 flex flex-col gap-5 h-[620px]">
        <RealtimeViz isSimulating={isSimulating} />
        <WavefrontMap isSimulating={isSimulating} />
      </div>

      <div className="md:col-span-3 h-[620px]">
        <MetricsRail metrics={metrics} />
      </div>

      {/* Bottom Section: Actuators Grid (col-4) + System Console (col-8) */}
      <div className="md:col-span-4">
        <ActuatorMap isSimulating={isSimulating} />
      </div>

      <div className="md:col-span-8">
        <SystemConsole logs={logs} onClear={onClearLogs} />
      </div>
    </div>
  );
};
