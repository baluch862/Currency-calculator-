import React, { useEffect, useRef, useState } from 'react';
import { 
  Wand2, Sun, Contrast, Sliders, Sparkles, RotateCcw, ZoomIn, ZoomOut, Move, 
  RotateCw, FlipHorizontal, FlipVertical, Crop, Eye, Split, Layers, Filter, 
  ShieldCheck, CheckCircle2, Zap, ArrowRightLeft, Image as ImageIcon, BarChart2,
  RefreshCw, Scissors
} from 'lucide-react';
import { EnhancementParams } from '../../types';

interface EnhancementPanelProps {
  params: EnhancementParams;
  onChangeParams: (params: EnhancementParams | ((prev: EnhancementParams) => EnhancementParams)) => void;
  onResetToNominal: () => void;
}

export const EnhancementPanel: React.FC<EnhancementPanelProps> = ({
  params,
  onChangeParams,
  onResetToNominal
}) => {
  const [activeTab, setActiveTab] = useState<'tone' | 'filters' | 'edges' | 'geometry'>('tone');
  const [compareMode, setCompareMode] = useState<'split' | 'side' | 'hold'>('split');
  const [splitPosition, setSplitPosition] = useState<number>(50); // %
  const [isHoldingCompare, setIsHoldingCompare] = useState<boolean>(false);
  const [isAutoEnhancing, setIsAutoEnhancing] = useState<boolean>(false);
  const [activePreset, setActivePreset] = useState<string>('Raw');

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sideRawRef = useRef<HTMLCanvasElement>(null);
  const sideCleanRef = useRef<HTMLCanvasElement>(null);

  // Auto-enhancement execution
  const handleAutoEnhance = () => {
    setIsAutoEnhancing(true);
    setTimeout(() => {
      setIsAutoEnhancing(false);
      setActivePreset('AI Auto-Optimized');
      onChangeParams({
        ...params,
        brightness: 12,
        contrast: 28,
        gamma: 1.2,
        clahe: true,
        noiseReduction: 45,
        sharpen: true,
        normalize: true,
        deadPixelRemoval: true,
        autoEnhance: true
      });
    }, 900);
  };

  const handleApplyPreset = (name: string) => {
    setActivePreset(name);
    if (name === 'High Contrast Astrometry') {
      onChangeParams({ ...params, brightness: -15, contrast: 65, gamma: 1.8, histEqualization: true, edgeEnhance: true });
    } else if (name === 'Deep Sky Denoise') {
      onChangeParams({ ...params, blurMode: 'NL_Means', blurRadius: 4, noiseReduction: 85, bgRemoval: true, clahe: true });
    } else if (name === 'Edge Contour Extraction') {
      onChangeParams({ ...params, edgeFilter: 'Sobel', contrast: 40, sharpen: true, morphology: 'Opening' });
    } else {
      onResetToNominal();
    }
  };

  // Canvas drawing simulation
  useEffect(() => {
    let animId: number;
    let t = 0;

    const renderStage = (ctx: CanvasRenderingContext2D, width: number, height: number, forceRaw: boolean = false) => {
      const imgData = ctx.createImageData(width, height);
      const data = imgData.data;

      const cols = 8;
      const rows = 6;
      const cellW = width / (cols + 1);
      const cellH = height / (rows + 1);

      // Trigonometric transforms
      const rad = (params.rotation * Math.PI) / 180;
      const cosR = Math.cos(rad);
      const sinR = Math.sin(rad);
      const cx = width / 2;
      const cy = height / 2;

      for (let py = 0; py < height; py++) {
        for (let px = 0; px < width; px++) {
          const idx = (py * width + px) * 4;

          // Split comparison check
          const isRawSide = forceRaw || (compareMode === 'split' && (px / width) * 100 > splitPosition) || (compareMode === 'hold' && isHoldingCompare);

          if (isRawSide) {
            // Unenhanced raw CCD frame simulation
            const spotNoise = Math.sin(px * 12 + py * 19 + t) * 15 + ((px * py) % 25);
            let intensity = spotNoise + 30; // base background pedestal
            for (let c = 1; c <= cols; c++) {
              for (let r = 1; r <= rows; r++) {
                const sx = c * cellW;
                const sy = r * cellH;
                const d2 = (px - sx) ** 2 + (py - sy) ** 2;
                if (d2 < 100) intensity += Math.exp(-d2 / 20) * 160;
              }
            }
            // Dead pixels
            if ((px === 60 && py === 80) || (px === 210 && py === 140) || (px === 340 && py === 90)) {
              intensity = 255;
            }

            data[idx] = Math.min(255, Math.floor(intensity * 0.45));
            data[idx + 1] = Math.min(255, Math.floor(intensity * 0.65));
            data[idx + 2] = Math.min(255, Math.floor(intensity * 0.85));
            data[idx + 3] = 255;
          } else {
            // Enhanced pipeline render
            // Inverse transform for zoom, pan, rotate
            let tx = (px - cx - params.panX) / params.zoom;
            let ty = (py - cy - params.panY) / params.zoom;

            if (params.flipH) tx = -tx;
            if (params.flipV) ty = -ty;

            const rx = tx * cosR - ty * sinR + cx;
            const ry = tx * sinR + ty * cosR + cy;

            if (rx < 0 || rx >= width || ry < 0 || ry >= height) {
              data[idx] = 12; data[idx+1] = 15; data[idx+2] = 24; data[idx+3] = 255;
              continue;
            }

            let baseVal = 0;
            for (let c = 1; c <= cols; c++) {
              for (let r = 1; r <= rows; r++) {
                const sx = c * cellW;
                const sy = r * cellH;
                const d2 = (rx - sx) ** 2 + (ry - sy) ** 2;
                if (d2 < 120) {
                  let spread = 18;
                  if (params.sharpen) spread = 11;
                  if (params.blurMode !== 'None') spread += params.blurRadius * 1.5;
                  baseVal += Math.exp(-d2 / spread) * 210;
                }
              }
            }

            // Background removal
            let bg = params.bgRemoval ? 0 : 22;

            // Noise reduction
            let noise = ((rx * 17 + ry * 31 + t * 5) % 30) * (1 - params.noiseReduction / 100);

            let val = baseVal + bg + noise;

            // Brightness & Contrast
            val += params.brightness;
            val = ((val - 128) * (1 + params.contrast / 100)) + 128;

            // Gamma
            val = Math.pow(Math.max(0, val) / 255, 1 / params.gamma) * 255;

            // CLAHE / Hist Equalization boost
            if (params.clahe || params.histEqualization || params.adaptiveHist) {
              val = Math.sin((val / 255) * (Math.PI / 2)) * 265;
            }

            // Normalization
            if (params.normalize) {
              val = Math.min(255, Math.max(0, val * 1.1));
            }

            // Edge enhancement / Edge detection filter override
            if (params.edgeFilter !== 'None') {
              let edgeStrength = 0;
              for (let c = 1; c <= cols; c++) {
                for (let r = 1; r <= rows; r++) {
                  const sx = c * cellW;
                  const sy = r * cellH;
                  const dist = Math.sqrt((rx - sx) ** 2 + (ry - sy) ** 2);
                  if (Math.abs(dist - 10) < 2.5) edgeStrength = 240;
                }
              }
              if (params.edgeFilter === 'Canny') {
                val = edgeStrength > 100 ? 255 : 0;
              } else {
                val = edgeStrength + (params.edgeEnhance ? val * 0.3 : 0);
              }
            }

            // Morphology
            if (params.morphology === 'Opening') val = val > 140 ? val : val * 0.4;
            if (params.morphology === 'Closing') val = val > 80 ? Math.max(180, val) : val;

            // Color grading: Cyan / Electric Teal scientific palette
            data[idx] = Math.min(255, Math.max(0, Math.floor(val * 0.15)));
            data[idx + 1] = Math.min(255, Math.max(0, Math.floor(val * 0.95)));
            data[idx + 2] = Math.min(255, Math.max(0, Math.floor(val * 1.0)));
            data[idx + 3] = 255;
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);

      // Draw split line if in split mode
      if (!forceRaw && compareMode === 'split') {
        const splitX = (splitPosition / 100) * width;
        ctx.strokeStyle = '#00cbe6';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(splitX, 0);
        ctx.lineTo(splitX, height);
        ctx.stroke();

        // Split badge
        ctx.fillStyle = '#00cbe6';
        ctx.beginPath();
        ctx.arc(splitX, height / 2, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#080b10';
        ctx.font = 'bold 10px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('VS', splitX, height / 2 + 3);
      }
    };

    const loop = () => {
      t += 0.08;
      if (compareMode === 'side') {
        if (sideRawRef.current) renderStage(sideRawRef.current.getContext('2d')!, sideRawRef.current.width, sideRawRef.current.height, true);
        if (sideCleanRef.current) renderStage(sideCleanRef.current.getContext('2d')!, sideCleanRef.current.width, sideCleanRef.current.height, false);
      } else if (canvasRef.current) {
        renderStage(canvasRef.current.getContext('2d')!, canvasRef.current.width, canvasRef.current.height, false);
      }
      animId = requestAnimationFrame(loop);
    };

    loop();
    return () => cancelAnimationFrame(animId);
  }, [params, compareMode, splitPosition, isHoldingCompare]);

  const updateParam = (key: keyof EnhancementParams, val: any) => {
    onChangeParams(prev => ({ ...prev, [key]: val }));
  };

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#16233b] to-[#121524] border border-[#464554]/40 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-widest">
            <Wand2 className="w-4 h-4 animate-bounce" /> Advanced Wavefront Image Studio
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Comprehensive Image Enhancement Toolkit
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Execute professional-grade optical enhancement algorithms: non-local means denoising, contrast-limited adaptive histogram equalization (CLAHE), morphological transformations, edge filtering, and real-time geometric manipulation.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={handleAutoEnhance}
            disabled={isAutoEnhancing}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#00cbe6] via-[#8083ff] to-[#494bd6] hover:brightness-110 text-white font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 shadow-[0_0_25px_rgba(0,203,230,0.35)] transition-all active:scale-95 disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 ${isAutoEnhancing ? 'animate-spin' : ''}`} />
            {isAutoEnhancing ? 'AI Neural Optimizing...' : 'Auto Enhancement'}
          </button>
        </div>
      </div>

      {/* Preset Quick Badges */}
      <div className="flex flex-wrap items-center gap-2 bg-[#10131a] p-3 rounded-2xl border border-[#464554]/30">
        <span className="text-xs font-bold text-[#908fa0] uppercase tracking-wider px-2 flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-[#ffb4ab]" /> Presets:
        </span>
        {['Raw', 'AI Auto-Optimized', 'High Contrast Astrometry', 'Deep Sky Denoise', 'Edge Contour Extraction'].map((pst) => (
          <button
            key={pst}
            onClick={() => handleApplyPreset(pst)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
              activePreset === pst
                ? 'bg-[#1d2026] text-[#00cbe6] border-[#00cbe6] shadow-[0_0_15px_rgba(0,203,230,0.2)]'
                : 'bg-[#161b22]/60 text-[#c7c4d7] border-[#464554]/30 hover:bg-[#272a31]'
            }`}
          >
            {pst}
          </button>
        ))}
      </div>

      {/* Main Grid Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Toolbar Tabs (col-5) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Tabs Navigation */}
          <div className="grid grid-cols-4 gap-1.5 bg-[#10131a] p-1.5 rounded-2xl border border-[#464554]/30">
            {[
              { id: 'tone', label: 'Tone', icon: Sun },
              { id: 'filters', label: 'Filters', icon: Filter },
              { id: 'edges', label: 'Edges', icon: Scissors },
              { id: 'geometry', label: 'Geometry', icon: Move }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-2.5 rounded-xl text-xs font-bold transition-all flex flex-col items-center gap-1 border ${
                    isActive
                      ? 'bg-[#1d2026] text-[#5de6ff] border-[#00cbe6]/50 shadow-md'
                      : 'text-[#908fa0] border-transparent hover:text-white hover:bg-[#161b22]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Panel Body */}
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-6 min-h-[460px]">
            {activeTab === 'tone' && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between border-b border-[#464554]/30 pb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <Sun className="w-4 h-4 text-[#00cbe6]" /> Brightness, Contrast &amp; Gamma
                  </h3>
                  <button onClick={onResetToNominal} className="text-[11px] text-[#ffb4ab] hover:underline flex items-center gap-1">
                    <RotateCcw className="w-3 h-3" /> Reset Tone
                  </button>
                </div>

                {/* Brightness */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-[#c7c4d7]">Brightness Adjustment:</span>
                    <span className="text-[#00cbe6] font-bold">{params.brightness > 0 ? `+${params.brightness}` : params.brightness}</span>
                  </div>
                  <input
                    type="range" min="-100" max="100" step="1"
                    value={params.brightness}
                    onChange={(e) => updateParam('brightness', Number(e.target.value))}
                    className="w-full accent-[#00cbe6] h-1.5 bg-[#272a31] rounded cursor-pointer"
                  />
                </div>

                {/* Contrast */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-[#c7c4d7]">Contrast Boost:</span>
                    <span className="text-[#5de6ff] font-bold">{params.contrast > 0 ? `+${params.contrast}%` : `${params.contrast}%`}</span>
                  </div>
                  <input
                    type="range" min="-100" max="100" step="1"
                    value={params.contrast}
                    onChange={(e) => updateParam('contrast', Number(e.target.value))}
                    className="w-full accent-[#00cbe6] h-1.5 bg-[#272a31] rounded cursor-pointer"
                  />
                </div>

                {/* Gamma Correction */}
                <div className="space-y-2">
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-[#c7c4d7]">Gamma Correction (γ):</span>
                    <span className="text-[#c0c1ff] font-bold">{params.gamma.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.1" max="3.0" step="0.05"
                    value={params.gamma}
                    onChange={(e) => updateParam('gamma', Number(e.target.value))}
                    className="w-full accent-[#8083ff] h-1.5 bg-[#272a31] rounded cursor-pointer"
                  />
                </div>

                {/* Histogram Equalization Toggles */}
                <div className="pt-2 space-y-2.5 border-t border-[#464554]/20">
                  <span className="text-xs font-bold text-[#908fa0] uppercase tracking-wider">Histogram Equalization Algorithms</span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    {[
                      { k: 'histEqualization', l: 'Global Hist Eq' },
                      { k: 'clahe', l: 'CLAHE Boost' },
                      { k: 'adaptiveHist', l: 'Adaptive AHE' }
                    ].map(item => (
                      <button
                        key={item.k}
                        onClick={() => updateParam(item.k as any, !params[item.k as keyof EnhancementParams])}
                        className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all border text-center ${
                          params[item.k as keyof EnhancementParams]
                            ? 'bg-[#00cbe6]/20 text-[#00cbe6] border-[#00cbe6]'
                            : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                        }`}
                      >
                        {item.l}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Normalization & BG Removal */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={() => updateParam('normalize', !params.normalize)}
                    className={`p-3 rounded-xl border text-left flex items-center justify-between ${
                      params.normalize ? 'bg-[#1d2026] border-[#4edea3] text-white' : 'bg-[#10131a] border-[#464554]/30 text-[#908fa0]'
                    }`}
                  >
                    <span className="text-xs font-bold">Image Normalization</span>
                    <CheckCircle2 className={`w-4 h-4 ${params.normalize ? 'text-[#4edea3]' : 'opacity-20'}`} />
                  </button>
                  <button
                    onClick={() => updateParam('bgRemoval', !params.bgRemoval)}
                    className={`p-3 rounded-xl border text-left flex items-center justify-between ${
                      params.bgRemoval ? 'bg-[#1d2026] border-[#ffb4ab] text-white' : 'bg-[#10131a] border-[#464554]/30 text-[#908fa0]'
                    }`}
                  >
                    <span className="text-xs font-bold">Background Removal</span>
                    <CheckCircle2 className={`w-4 h-4 ${params.bgRemoval ? 'text-[#ffb4ab]' : 'opacity-20'}`} />
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'filters' && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between border-b border-[#464554]/30 pb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <Filter className="w-4 h-4 text-[#8083ff]" /> Blur Kernels &amp; Denoising
                  </h3>
                </div>

                {/* Blur Mode Selector */}
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-[#c7c4d7]">Spatial Blur &amp; Filter Mode:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['None', 'Gaussian', 'Median', 'Bilateral', 'NL_Means'] as const).map(mode => (
                      <button
                        key={mode}
                        onClick={() => updateParam('blurMode', mode)}
                        className={`py-2 px-1 rounded-lg text-xs font-bold border transition-all ${
                          params.blurMode === mode
                            ? 'bg-[#494bd6] text-white border-[#8083ff] shadow-[0_0_15px_rgba(73,75,214,0.4)]'
                            : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                        }`}
                      >
                        {mode === 'NL_Means' ? 'Non-Local Means' : mode}
                      </button>
                    ))}
                  </div>
                </div>

                {params.blurMode !== 'None' && (
                  <div className="space-y-2 p-3.5 bg-[#10131a] rounded-xl border border-[#464554]/30">
                    <div className="flex justify-between font-mono text-xs">
                      <span className="text-[#c7c4d7]">Kernel Radius / Spread:</span>
                      <span className="text-[#8083ff] font-bold">{params.blurRadius} px</span>
                    </div>
                    <input
                      type="range" min="1" max="20" step="1"
                      value={params.blurRadius}
                      onChange={(e) => updateParam('blurRadius', Number(e.target.value))}
                      className="w-full accent-[#8083ff] h-1.5 bg-[#272a31] rounded cursor-pointer"
                    />
                  </div>
                )}

                {/* Noise Reduction Slider */}
                <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                  <div className="flex justify-between font-mono text-xs">
                    <span className="text-[#c7c4d7]">Active Noise Reduction Strength:</span>
                    <span className="text-[#4edea3] font-bold">{params.noiseReduction}%</span>
                  </div>
                  <input
                    type="range" min="0" max="100" step="5"
                    value={params.noiseReduction}
                    onChange={(e) => updateParam('noiseReduction', Number(e.target.value))}
                    className="w-full accent-[#4edea3] h-1.5 bg-[#272a31] rounded cursor-pointer"
                  />
                </div>

                {/* Dead Pixel Removal Toggle */}
                <div className="pt-2">
                  <button
                    onClick={() => updateParam('deadPixelRemoval', !params.deadPixelRemoval)}
                    className={`w-full p-4 rounded-xl border flex items-center justify-between transition-all ${
                      params.deadPixelRemoval
                        ? 'bg-[#1d2026] border-[#00cbe6] text-white shadow-lg'
                        : 'bg-[#10131a] border-[#464554]/30 text-[#908fa0]'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-bold text-left">Dead &amp; Hot Pixel Removal</p>
                      <p className="text-[11px] text-[#908fa0] mt-0.5">Interpolates isolated high/low ADU outliers</p>
                    </div>
                    <CheckCircle2 className={`w-5 h-5 ${params.deadPixelRemoval ? 'text-[#00cbe6]' : 'opacity-20'}`} />
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'edges' && (
              <div className="space-y-5 animate-in fade-in duration-200">
                <div className="flex items-center justify-between border-b border-[#464554]/30 pb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <Scissors className="w-4 h-4 text-[#ffb4ab]" /> Sharpening, Edges &amp; Morphology
                  </h3>
                </div>

                {/* Sharpen & Edge Enhance */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => updateParam('sharpen', !params.sharpen)}
                    className={`p-3.5 rounded-xl border text-left flex items-center justify-between ${
                      params.sharpen ? 'bg-[#1d2026] border-[#5de6ff] text-white' : 'bg-[#10131a] border-[#464554]/30 text-[#908fa0]'
                    }`}
                  >
                    <span className="text-xs font-bold">Sharpen Filter</span>
                    <CheckCircle2 className={`w-4 h-4 ${params.sharpen ? 'text-[#5de6ff]' : 'opacity-20'}`} />
                  </button>
                  <button
                    onClick={() => updateParam('edgeEnhance', !params.edgeEnhance)}
                    className={`p-3.5 rounded-xl border text-left flex items-center justify-between ${
                      params.edgeEnhance ? 'bg-[#1d2026] border-[#8083ff] text-white' : 'bg-[#10131a] border-[#464554]/30 text-[#908fa0]'
                    }`}
                  >
                    <span className="text-xs font-bold">Edge Enhancement</span>
                    <CheckCircle2 className={`w-4 h-4 ${params.edgeEnhance ? 'text-[#8083ff]' : 'opacity-20'}`} />
                  </button>
                </div>

                {/* Edge Detection Operators */}
                <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                  <span className="text-xs font-semibold text-[#c7c4d7]">Convolutional Edge Operators:</span>
                  <div className="grid grid-cols-4 gap-2">
                    {(['None', 'Laplacian', 'Sobel', 'Canny'] as const).map(flt => (
                      <button
                        key={flt}
                        onClick={() => updateParam('edgeFilter', flt)}
                        className={`py-2 rounded-lg text-xs font-bold border transition-all ${
                          params.edgeFilter === flt
                            ? 'bg-[#00cbe6] text-[#080b10] border-[#5de6ff] shadow-md font-extrabold'
                            : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                        }`}
                      >
                        {flt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Morphological Operations */}
                <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                  <span className="text-xs font-semibold text-[#c7c4d7]">Mathematical Morphology:</span>
                  <div className="grid grid-cols-3 gap-2">
                    {(['None', 'Opening', 'Closing'] as const).map(m => (
                      <button
                        key={m}
                        onClick={() => updateParam('morphology', m)}
                        className={`py-2 rounded-lg text-xs font-bold border transition-all ${
                          params.morphology === m
                            ? 'bg-[#241f30] text-[#ffb4ab] border-[#ffb4ab]'
                            : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                        }`}
                      >
                        {m === 'Opening' ? 'Opening (Erode→Dilate)' : m === 'Closing' ? 'Closing (Dilate→Erode)' : 'None'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'geometry' && (
              <div className="space-y-5 animate-in fade-in duration-200 font-mono text-xs">
                <div className="flex items-center justify-between border-b border-[#464554]/30 pb-3 font-sans">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
                    <Move className="w-4 h-4 text-[#4edea3]" /> Zoom, Pan, Rotate &amp; Flip
                  </h3>
                </div>

                {/* Zoom Controls */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-[#c7c4d7] font-sans">Zoom Magnification:</span>
                    <span className="text-[#4edea3] font-bold">{params.zoom.toFixed(2)}x</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button onClick={() => updateParam('zoom', Math.max(0.5, params.zoom - 0.25))} className="p-2 bg-[#10131a] rounded border border-[#464554]/40 hover:text-white text-[#908fa0]"><ZoomOut className="w-4 h-4"/></button>
                    <input type="range" min="0.5" max="4.0" step="0.1" value={params.zoom} onChange={(e) => updateParam('zoom', Number(e.target.value))} className="flex-1 accent-[#4edea3] h-1.5 bg-[#272a31] rounded cursor-pointer"/>
                    <button onClick={() => updateParam('zoom', Math.min(4.0, params.zoom + 0.25))} className="p-2 bg-[#10131a] rounded border border-[#464554]/40 hover:text-white text-[#908fa0]"><ZoomIn className="w-4 h-4"/></button>
                  </div>
                </div>

                {/* Rotation */}
                <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                  <div className="flex justify-between">
                    <span className="text-[#c7c4d7] font-sans">Rotation Angle:</span>
                    <span className="text-[#00cbe6] font-bold">{params.rotation}°</span>
                  </div>
                  <input type="range" min="0" max="360" step="1" value={params.rotation} onChange={(e) => updateParam('rotation', Number(e.target.value))} className="w-full accent-[#00cbe6] h-1.5 bg-[#272a31] rounded cursor-pointer"/>
                  <div className="grid grid-cols-4 gap-2 pt-1 font-sans">
                    {[0, 90, 180, 270].map(deg => (
                      <button key={deg} onClick={() => updateParam('rotation', deg)} className="py-1 bg-[#10131a] hover:bg-[#272a31] rounded border border-[#464554]/30 text-[11px] text-[#c7c4d7]">
                        {deg}°
                      </button>
                    ))}
                  </div>
                </div>

                {/* Flip & Pan Rest */}
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-[#464554]/20 font-sans">
                  <button onClick={() => updateParam('flipH', !params.flipH)} className={`p-3 rounded-xl border flex items-center justify-center gap-2 font-bold ${params.flipH ? 'bg-[#1d2026] text-[#5de6ff] border-[#00cbe6]' : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30'}`}>
                    <FlipHorizontal className="w-4 h-4"/> Flip Horizontal
                  </button>
                  <button onClick={() => updateParam('flipV', !params.flipV)} className={`p-3 rounded-xl border flex items-center justify-center gap-2 font-bold ${params.flipV ? 'bg-[#1d2026] text-[#5de6ff] border-[#00cbe6]' : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30'}`}>
                    <FlipVertical className="w-4 h-4"/> Flip Vertical
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Viewport & Comparison Stage (col-7) */}
        <div className="lg:col-span-7 space-y-4 flex flex-col">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-lg flex flex-col flex-1 min-h-[520px]">
            {/* Stage Header */}
            <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#00cbe6]" />
                <span className="text-xs font-bold uppercase tracking-widest text-white">
                  Real-time Enhancement Inspector
                </span>
              </div>

              {/* Compare Mode Selector */}
              <div className="flex items-center gap-1 bg-[#10131a] p-1 rounded-xl border border-[#464554]/30">
                {[
                  { id: 'split', label: 'Split Slider', icon: Split },
                  { id: 'side', label: 'Side-by-Side', icon: ArrowRightLeft },
                  { id: 'hold', label: 'Hold to Compare', icon: Eye }
                ].map(m => (
                  <button
                    key={m.id}
                    onClick={() => setCompareMode(m.id as any)}
                    className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 ${
                      compareMode === m.id
                        ? 'bg-[#00cbe6]/20 text-[#00cbe6] border border-[#00cbe6]/40 shadow-sm'
                        : 'text-[#908fa0] hover:text-white'
                    }`}
                  >
                    <m.icon className="w-3 h-3" /> {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Canvas Viewport Body */}
            <div className="p-6 bg-[#080b10] flex-1 flex flex-col items-center justify-center relative select-none">
              {compareMode === 'side' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-4xl">
                  <div className="space-y-1.5">
                    <div className="relative rounded-xl overflow-hidden border border-[#ffb4ab]/40 bg-black shadow-lg">
                      <canvas ref={sideRawRef} width={380} height={320} className="w-full h-[320px] object-cover" />
                      <div className="absolute top-3 left-3 px-2 py-1 bg-black/80 backdrop-blur rounded border border-[#ffb4ab]/30 font-mono text-[10px] text-[#ffb4ab] font-bold uppercase">
                        Raw Baseline
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <div className="relative rounded-xl overflow-hidden border border-[#00cbe6]/40 bg-black shadow-[0_0_25px_rgba(0,203,230,0.15)]">
                      <canvas ref={sideCleanRef} width={380} height={320} className="w-full h-[320px] object-cover" />
                      <div className="absolute top-3 left-3 px-2 py-1 bg-black/80 backdrop-blur rounded border border-[#00cbe6]/30 font-mono text-[10px] text-[#5de6ff] font-bold uppercase">
                        Enhanced Output
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="w-full max-w-3xl flex flex-col items-center space-y-3">
                  <div
                    onMouseDown={() => compareMode === 'hold' && setIsHoldingCompare(true)}
                    onMouseUp={() => compareMode === 'hold' && setIsHoldingCompare(false)}
                    onMouseLeave={() => compareMode === 'hold' && setIsHoldingCompare(false)}
                    className="relative rounded-2xl overflow-hidden border border-[#464554]/50 bg-black shadow-2xl w-full cursor-crosshair"
                  >
                    <canvas ref={canvasRef} width={680} height={420} className="w-full h-[400px] object-cover" />

                    {/* Overlay Badges */}
                    <div className="absolute top-4 left-4 px-3 py-1.5 bg-black/85 backdrop-blur rounded-lg border border-white/10 font-mono text-xs text-[#00cbe6] font-bold flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-pulse" />
                      {compareMode === 'hold' ? (isHoldingCompare ? 'SHOWING RAW BEFORE' : 'ENHANCED AFTER (HOLD TO COMPARE)') : 'ENHANCED VIEWPORT'}
                    </div>

                    {/* Split Mode Slider input */}
                    {compareMode === 'split' && (
                      <input
                        type="range" min="0" max="100" step="0.5"
                        value={splitPosition}
                        onChange={(e) => setSplitPosition(Number(e.target.value))}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                      />
                    )}
                  </div>

                  {compareMode === 'split' && (
                    <div className="flex items-center justify-between w-full font-mono text-xs text-[#908fa0] px-2">
                      <span>← RAW UNPROCESSED ({splitPosition.toFixed(0)}%)</span>
                      <span className="text-[#00cbe6]">DRAG TO SPLIT COMPARE</span>
                      <span>ENHANCED OUTPUT ({ (100 - splitPosition).toFixed(0) }%) →</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Viewport Footer Telemetry Bar */}
            <div className="p-4 bg-[#10131a] border-t border-[#464554]/30 flex flex-wrap items-center justify-between gap-4 font-mono text-xs text-[#c7c4d7]">
              <div className="flex items-center gap-3">
                <span>HISTOGRAM: <strong>EQUALIZED</strong></span>
                <span className="text-[#464554]">|</span>
                <span>NOISE REDUCTION: <strong className="text-[#4edea3]">{params.noiseReduction}%</strong></span>
              </div>

              <div className="text-[#5de6ff] font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" /> PIPELINE LATENCY: 1.4 ms (CUDA STREAM 0)
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
