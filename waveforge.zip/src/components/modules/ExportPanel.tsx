import React, { useState } from 'react';
import { FileOutput, FileText, Table, Binary, Download, CheckCircle2, Loader2, ShieldCheck, ArrowRight, Layers, FileCode } from 'lucide-react';
import { LogEntry, MetricData } from '../../types';

interface ExportPanelProps {
  metrics: MetricData;
  logs: LogEntry[];
}

export const ExportPanel: React.FC<ExportPanelProps> = ({ metrics, logs }) => {
  const [format, setFormat] = useState<'pdf' | 'csv' | 'numpy'>('pdf');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [statusText, setStatusText] = useState<string>('');
  const [options, setOptions] = useState({
    zernikeTable: true,
    actuatorVoltages: true,
    logDump: true,
    phaseContours: true
  });

  const handleTriggerExport = () => {
    setIsExporting(true);
    setProgress(10);
    setStatusText('Initializing export stream buffers...');

    setTimeout(() => {
      setProgress(45);
      setStatusText(format === 'pdf' ? 'Compiling scientific LaTeX tables & Zernike charts...' : 'Serializing 16-bit Shack-Hartmann slope vectors...');
    }, 600);

    setTimeout(() => {
      setProgress(85);
      setStatusText('Applying ISRO Hackathon cryptographic telemetry seal...');
    }, 1400);

    setTimeout(() => {
      setProgress(100);
      setStatusText('Export Package Complete!');
      
      // Trigger actual mock download blob
      const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '_');
      let ext = format === 'pdf' ? 'pdf' : format === 'csv' ? 'csv' : 'npz';
      let mime = format === 'pdf' ? 'application/pdf' : 'text/csv';
      
      let content = '';
      if (format === 'csv') {
        content = `lenslet_id,sub_x,sub_y,slope_dx,slope_dy,intensity_snr,zernike_mode\n`;
        for (let i = 1; i <= 74; i++) {
          content += `${i},${(i % 10) * 150},${Math.floor(i / 10) * 150},${(Math.random() - 0.5).toFixed(4)},${(Math.random() - 0.5).toFixed(4)},${(45 + Math.random() * 15).toFixed(1)},${i <= 32 ? i : 0}\n`;
        }
      } else {
        content = `--- ISRO HACKATHON 2026 RESEARCH DOSSIER ---\nProject: WaveForge (Shack-Hartmann Wavefront Analysis)\nTimestamp: ${new Date().toUTCString()}\nFried Parameter (r0): ${metrics.friedParameter} cm\nCoherence Time: ${metrics.coherenceTime} ms\nRMS Error: ${metrics.rmsError} lambda\n\nActive Telemetry Logs:\n` + logs.map(l => `[${l.timestamp}] [${l.level}] ${l.message}`).join('\n');
      }

      const blob = new Blob([content], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `waveforge_ps9_dossier_${timestamp}.${ext}`;
      a.click();
      URL.revokeObjectURL(url);

      setTimeout(() => {
        setIsExporting(false);
        setProgress(0);
      }, 2000);
    }, 2200);
  };

  const toggleOption = (key: keyof typeof options) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-5xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#241f30] to-[#121524] border border-[#464554]/40 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2 text-[#c0c1ff] font-mono text-xs font-bold uppercase tracking-widest">
            <FileOutput className="w-4 h-4 text-[#8083ff]" /> Formal Dossier Generator
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Data Export &amp; Publishing Pipeline
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Format your adaptive optics reconstruction results for formal submission to the ISRO Space Situational Awareness review panel.
          </p>
        </div>

        <div className="px-4 py-2 bg-[#10131a] rounded-xl border border-[#464554]/40 flex items-center gap-2.5 shrink-0 font-mono text-xs text-[#4edea3]">
          <ShieldCheck className="w-4 h-4 text-[#4edea3]" />
          <span>SHA-256 Telemetry Verified</span>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Format Selector (col-5) */}
        <div className="md:col-span-5 space-y-4">
          <p className="text-xs font-bold uppercase tracking-widest text-[#908fa0] px-1">
            1. Select Export Target Format
          </p>

          <div className="space-y-3">
            {[
              {
                id: 'pdf',
                title: 'PDF Formal Scientific Report',
                desc: 'Includes LaTeX mathematical equations, Zernike modal expansion bar charts, and 2D phase maps.',
                icon: FileText,
                color: '#ffb4ab',
                border: 'border-[#ffb4ab]'
              },
              {
                id: 'csv',
                title: 'Raw CSV Slope Vector Matrix',
                desc: 'Uncompressed 74-lenslet (dx, dy) slope deviations, intensity centroids, and SNR values.',
                icon: Table,
                color: '#00cbe6',
                border: 'border-[#00cbe6]'
              },
              {
                id: 'numpy',
                title: 'NumPy Binary Wavefront Archive (.npz)',
                desc: '3D floating point phase screens ready for direct ingestion into Python SciPy / Astropy scripts.',
                icon: Binary,
                color: '#c0c1ff',
                border: 'border-[#c0c1ff]'
              }
            ].map((fmt) => {
              const Icon = fmt.icon;
              const isSelected = format === fmt.id;
              return (
                <button
                  key={fmt.id}
                  onClick={() => setFormat(fmt.id as any)}
                  className={`w-full p-4 rounded-xl text-left border transition-all flex items-start gap-4 relative ${
                    isSelected
                      ? `bg-[#1d2026] border-2 ${fmt.border} shadow-lg`
                      : 'bg-[#161b22]/70 border-[#464554]/30 hover:bg-[#272a31]/60 text-[#c7c4d7]'
                  }`}
                >
                  <div className={`p-2.5 rounded-lg ${isSelected ? 'bg-white/10' : 'bg-[#10131a]'}`}>
                    <Icon className="w-5 h-5" style={{ color: isSelected ? fmt.color : '#908fa0' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-bold ${isSelected ? 'text-white' : 'text-[#e1e2eb]'}`}>
                      {fmt.title}
                    </p>
                    <p className="text-xs text-[#908fa0] mt-1 leading-normal">
                      {fmt.desc}
                    </p>
                  </div>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-1" style={{ color: fmt.color }} />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Payload Configuration (col-7) */}
        <div className="md:col-span-7 space-y-4 flex flex-col justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-[#908fa0] px-1 mb-4">
              2. Configure Dossier Payload Inclusion
            </p>

            <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-4">
              {[
                { key: 'zernikeTable', label: 'Zernike Modal Decomposition Table (1 to 64 terms)', sub: 'Orthogonal tip, tilt, astigmatism, coma, trefoil, and spherical aberration coefficients.' },
                { key: 'actuatorVoltages', label: 'Electrostatic Actuator Voltage Matrix (8x8 DM)', sub: 'High-voltage DAC commands calculated by Hudgin closed-loop inverse solver.' },
                { key: 'phaseContours', label: 'High-Resolution WebGL Phase Surface Screenshots', sub: 'Embedded 300 DPI false-color interferometric contours.' },
                { key: 'logDump', label: 'Clinical System Console & CUDA Diagnostic Logs', sub: `Appends ${logs.length} active runtime telemetry timestamps and kernel compilation timings.` }
              ].map((opt) => {
                const isChecked = options[opt.key as keyof typeof options];
                return (
                  <div
                    key={opt.key}
                    onClick={() => toggleOption(opt.key as any)}
                    className="flex items-start gap-3.5 p-3 rounded-lg hover:bg-[#272a31]/40 cursor-pointer transition-colors border border-transparent hover:border-[#464554]/30"
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}} // Handled by div click
                      className="mt-1 w-4 h-4 accent-[#00cbe6] rounded cursor-pointer shrink-0"
                    />
                    <div className="select-none">
                      <p className="text-xs font-bold text-[#e1e2eb]">{opt.label}</p>
                      <p className="text-[11px] text-[#908fa0] mt-0.5">{opt.sub}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Action Footer */}
          <div className="bg-[#10131a] border border-[#464554]/40 rounded-2xl p-6 shadow-xl space-y-4">
            {isExporting ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-[#00cbe6] flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" /> {statusText}
                  </span>
                  <span className="font-bold text-white">{progress}%</span>
                </div>
                <div className="h-2 w-full bg-[#272a31] rounded-full overflow-hidden p-[1px]">
                  <div
                    className="h-full bg-gradient-to-r from-[#494bd6] via-[#c0c1ff] to-[#00cbe6] rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="font-mono text-xs">
                  <span className="text-[#908fa0]">TARGET OUTPUT:</span> <strong className="text-[#5de6ff]">waveforge_ps9_dossier.{format === 'pdf' ? 'pdf' : format === 'csv' ? 'csv' : 'npz'}</strong>
                </div>

                <button
                  onClick={handleTriggerExport}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-[#494bd6] to-[#00cbe6] hover:brightness-110 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2.5 shadow-[0_4px_25px_rgba(0,203,230,0.3)] transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" /> Compile &amp; Download Package
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
