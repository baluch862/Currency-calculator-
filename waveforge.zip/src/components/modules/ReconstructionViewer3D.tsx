import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { 
  Waves, Eye, Sliders, RotateCcw, Box, Grid, Activity, 
  Sparkles, Layers, RefreshCw, Zap, ShieldCheck, CheckCircle2,
  Maximize2, Minimize2, Info, Compass
} from 'lucide-react';
import { ReconstructionParams, MetricData } from '../../types';

interface ReconstructionViewer3DProps {
  metrics: MetricData;
  onResetPipeline: () => void;
}

// Child component handling real-time WebGL vertex deformation & colormapping
const WavefrontMesh: React.FC<{ params: ReconstructionParams }> = ({ params }) => {
  const geomRef = useRef<THREE.PlaneGeometry>(null);

  // Colormap helper mapping normalized Z [0..1] to THREE.Color
  const getColor = (t: number, cmap: ReconstructionParams['colormap']) => {
    const clamp = Math.max(0, Math.min(1, t));
    const col = new THREE.Color();
    if (cmap === 'Cyan_Plasma') {
      if (clamp < 0.5) {
        col.setRGB(
          0.05 + clamp * 0.1,
          0.1 + clamp * 1.4,
          0.3 + clamp * 1.2
        );
      } else {
        col.setRGB(
          0.1 + (clamp - 0.5) * 1.8,
          0.8 - (clamp - 0.5) * 1.2,
          0.9 + (clamp - 0.5) * 0.2
        );
      }
    } else if (cmap === 'Inferno') {
      if (clamp < 0.33) {
        col.setRGB(0.05 + clamp * 1.2, 0.0, 0.15 + clamp * 0.8);
      } else if (clamp < 0.66) {
        col.setRGB(0.45 + (clamp - 0.33) * 1.5, 0.1 + (clamp - 0.33) * 1.2, 0.4 - (clamp - 0.33) * 0.9);
      } else {
        col.setRGB(0.95, 0.5 + (clamp - 0.66) * 1.5, 0.1 + (clamp - 0.66) * 2.5);
      }
    } else if (cmap === 'Viridis') {
      col.setHSL(0.75 - clamp * 0.55, 0.85, 0.2 + clamp * 0.5);
    } else {
      // Emerald_Wave
      col.setHSL(0.42 - clamp * 0.15, 0.9, 0.15 + clamp * 0.65);
    }
    return col;
  };

  useFrame(({ clock }) => {
    if (!geomRef.current) return;
    const pos = geomRef.current.attributes.position;
    let colAttr = geomRef.current.attributes.color as THREE.BufferAttribute | undefined;

    if (!colAttr || colAttr.count !== pos.count) {
      const colorArray = new Float32Array(pos.count * 3);
      colAttr = new THREE.BufferAttribute(colorArray, 3);
      geomRef.current.setAttribute('color', colAttr);
    }

    const t = params.isAnimated ? clock.getElapsedTime() * 1.8 : 1.0;
    const amp = params.amplitude;
    const sph = params.spherical;
    const ast = params.astigmatism;
    const turb = params.turbulenceNoise * 0.008;

    let minZ = 9999;
    let maxZ = -9999;
    const zVals = new Float32Array(pos.count);

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const nx = x / 5; // -1 to 1
      const ny = y / 5;
      const r2 = nx * nx + ny * ny;

      let z = 0;
      // Spherical aberration (4th order)
      z += sph * amp * (6 * r2 * r2 - 6 * r2 + 1) * 0.8;
      // Astigmatism
      z += ast * amp * (nx * nx - ny * ny) * 1.2;
      // Coma tilt oscillations
      z += amp * 0.35 * (3 * r2 - 2) * nx * Math.sin(t * 0.6);

      // Atmospheric turbulence ripple
      if (turb > 0) {
        z += Math.sin(nx * 8 + t) * Math.cos(ny * 8 - t * 0.7) * turb * amp;
        z += Math.sin(nx * 14 - t * 1.3) * turb * 0.5 * amp;
      }

      // Solver characteristic signature
      if (params.solver === 'Southwell_Zonal') {
        z += Math.sin(nx * Math.PI) * Math.cos(ny * Math.PI) * 0.12 * amp;
      } else if (params.solver === 'Hudgin_Zonal') {
        // Quantized zonal steps
        z = Math.round(z * 10) / 10;
      }

      zVals[i] = z;
      pos.setZ(i, z);
      if (z < minZ) minZ = z;
      if (z > maxZ) maxZ = z;
    }

    pos.needsUpdate = true;
    geomRef.current.computeVertexNormals();

    const range = maxZ - minZ || 1;
    for (let i = 0; i < pos.count; i++) {
      const norm = (zVals[i] - minZ) / range;
      const c = getColor(norm, params.colormap);
      colAttr.setXYZ(i, c.r, c.g, c.b);
    }
    colAttr.needsUpdate = true;
  });

  // 8x8 Actuator matrix grid points
  const actuatorPins = useMemo(() => {
    const pins: [number, number][] = [];
    for (let r = -3.5; r <= 3.5; r += 1) {
      for (let c = -3.5; c <= 3.5; c += 1) {
        pins.push([c * 1.3, r * 1.3]);
      }
    }
    return pins;
  }, []);

  return (
    <group>
      {/* Primary Wavefront Phase Surface */}
      <mesh>
        <planeGeometry ref={geomRef} args={[10, 10, 80, 80]} />
        <meshStandardMaterial
          vertexColors={true}
          roughness={0.25}
          metalness={0.15}
          wireframe={params.wireframe}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Deformable Mirror Actuator Matrix Structure */}
      {params.showActuators && (
        <group position={[0, 0, -2.8]}>
          <mesh position={[0, 0, 0]}>
            <boxGeometry args={[10.5, 10.5, 0.25]} />
            <meshStandardMaterial color="#111723" metalness={0.7} roughness={0.3} wireframe={params.wireframe} />
          </mesh>
          {actuatorPins.map(([x, y], idx) => (
            <mesh key={idx} position={[x, y, 1.4]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.07, 0.07, 2.8, 8]} />
              <meshStandardMaterial color="#00cbe6" metalness={0.9} roughness={0.1} />
            </mesh>
          ))}
        </group>
      )}
    </group>
  );
};

export const ReconstructionViewer3D: React.FC<ReconstructionViewer3DProps> = ({
  metrics,
  onResetPipeline
}) => {
  const [params, setParams] = useState<ReconstructionParams>({
    solver: 'Southwell_Zonal',
    colormap: 'Cyan_Plasma',
    wireframe: false,
    isAnimated: true,
    showActuators: true,
    amplitude: 1.2,
    spherical: 0.4,
    astigmatism: -0.3,
    turbulenceNoise: 25
  });

  const controlsRef = useRef<any>(null);

  const handleResetCamera = () => {
    if (controlsRef.current) {
      controlsRef.current.reset();
    }
  };

  const handleResetNominal = () => {
    setParams({
      solver: 'Southwell_Zonal',
      colormap: 'Cyan_Plasma',
      wireframe: false,
      isAnimated: true,
      showActuators: true,
      amplitude: 1.0,
      spherical: 0.0,
      astigmatism: 0.0,
      turbulenceNoise: 15
    });
    handleResetCamera();
    onResetPipeline();
  };

  const solverFormatted = 
    params.solver === 'Southwell_Zonal' ? 'Southwell Zonal Engine' :
    params.solver === 'Hudgin_Zonal' ? 'Hudgin Step Solver' :
    params.solver === 'Fried_LeastSquares' ? 'Fried Least-Squares' : 'Modal Zernike (64-Mode)';

  const rmsEst = (params.amplitude * 0.42 + Math.abs(params.spherical)*0.15).toFixed(2);
  const strehlEst = Math.max(12, Math.min(99.4, 98.2 - Number(rmsEst) * 32 - params.turbulenceNoise * 0.4)).toFixed(1);

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#162a3b] to-[#121524] border border-[#00cbe6]/30 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-[0_0_35px_rgba(0,203,230,0.12)]">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-widest">
            <Waves className="w-4 h-4 animate-pulse" /> 3D Phase Metrology &amp; AO Solvers
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            High-Resolution Wavefront Reconstruction Viewer
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Real-time React Three Fiber WebGL rendering of Shack-Hartmann phase surfaces. Orbit, inspect zonal slope geometry, and conjugate electrostatic deformable mirror actuators.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            onClick={handleResetNominal}
            className="px-4 py-2.5 bg-[#272a31] hover:bg-[#32353c] text-white rounded-xl border border-[#464554] flex items-center gap-2 font-mono text-xs transition-all active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#00cbe6]" /> Reset Geometry
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Active Geometry</span>
            <p className="text-sm font-extrabold text-white">{solverFormatted}</p>
            <p className="text-[11px] text-[#00cbe6] font-mono">64x64 Grid Resolution</p>
          </div>
          <div className="p-3 rounded-xl bg-[#00cbe6]/10 text-[#00cbe6] border border-[#00cbe6]/20"><Waves className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Residual Phase RMS</span>
            <p className="text-sm font-extrabold text-white">{rmsEst} λ Wavefront</p>
            <p className="text-[11px] text-[#ffc857] font-mono">P-V Error: {(Number(rmsEst)*3.8).toFixed(2)} λ</p>
          </div>
          <div className="p-3 rounded-xl bg-[#ffc857]/10 text-[#ffc857] border border-[#ffc857]/20"><Activity className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">AO Compensation</span>
            <p className="text-sm font-extrabold text-white">{strehlEst}% Strehl Ratio</p>
            <p className="text-[11px] text-[#4edea3] font-mono">{params.isAnimated ? 'Closed-Loop Live' : 'Static Phase Locked'}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#4edea3]/10 text-[#4edea3] border border-[#4edea3]/20"><Sparkles className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Deformable Mirror</span>
            <p className="text-sm font-extrabold text-white">64 Electrostatic Pins</p>
            <p className="text-[11px] text-[#8083ff] font-mono">{params.showActuators ? 'Pistons Conjugated' : 'Matrix Hidden'}</p>
          </div>
          <div className="p-3 rounded-xl bg-[#8083ff]/10 text-[#8083ff] border border-[#8083ff]/20"><Grid className="w-5 h-5"/></div>
        </div>
      </div>

      {/* Main 3D Viewport Card */}
      <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
        {/* Toolbar */}
        <div className="p-4 bg-[#21252d] border-b border-[#464554]/30 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono text-[#908fa0] mr-1 uppercase font-bold">Geometry:</span>
            {(['Southwell_Zonal', 'Hudgin_Zonal', 'Fried_LeastSquares', 'Modal_Zernike_64'] as const).map((sol) => (
              <button
                key={sol}
                onClick={() => setParams(prev => ({ ...prev, solver: sol }))}
                className={`px-3 py-1.5 rounded-lg font-mono text-xs transition-all ${
                  params.solver === sol
                    ? 'bg-[#00cbe6] text-[#080b10] font-extrabold shadow-md'
                    : 'bg-[#10131a] text-[#c7c4d7] hover:text-white border border-[#464554]/40'
                }`}
              >
                {sol.split('_')[0]}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Colormap Buttons */}
            <div className="flex items-center gap-1.5 bg-[#10131a] p-1 rounded-xl border border-[#464554]/40">
              {(['Cyan_Plasma', 'Inferno', 'Viridis', 'Emerald_Wave'] as const).map((cm) => (
                <button
                  key={cm}
                  onClick={() => setParams(prev => ({ ...prev, colormap: cm }))}
                  title={cm.replace('_', ' ')}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-mono uppercase transition-all flex items-center gap-1.5 ${
                    params.colormap === cm ? 'bg-[#2b303c] text-white font-bold' : 'text-[#908fa0] hover:text-white'
                  }`}
                >
                  <span className={`w-2.5 h-2.5 rounded-full ${
                    cm === 'Cyan_Plasma' ? 'bg-[#00cbe6]' :
                    cm === 'Inferno' ? 'bg-[#ff6b35]' :
                    cm === 'Viridis' ? 'bg-[#a3e635]' : 'bg-[#10b981]'
                  }`} />
                  <span className="hidden sm:inline">{cm.split('_')[0]}</span>
                </button>
              ))}
            </div>

            <div className="h-4 w-px bg-[#464554]/40 hidden sm:block" />

            {/* Overlays */}
            <button
              onClick={() => setParams(prev => ({ ...prev, wireframe: !prev.wireframe }))}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                params.wireframe
                  ? 'bg-[#8083ff]/20 text-[#c0c1ff] border-[#8083ff]'
                  : 'bg-[#10131a] text-[#908fa0] hover:text-white border-[#464554]/40'
              }`}
            >
              <Box className="w-3.5 h-3.5" /> Wireframe
            </button>

            <button
              onClick={() => setParams(prev => ({ ...prev, showActuators: !prev.showActuators }))}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                params.showActuators
                  ? 'bg-[#00cbe6]/20 text-[#00cbe6] border-[#00cbe6]'
                  : 'bg-[#10131a] text-[#908fa0] hover:text-white border-[#464554]/40'
              }`}
            >
              <Grid className="w-3.5 h-3.5" /> Actuator Pins
            </button>

            <button
              onClick={() => setParams(prev => ({ ...prev, isAnimated: !prev.isAnimated }))}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 border ${
                params.isAnimated
                  ? 'bg-[#4edea3]/20 text-[#4edea3] border-[#4edea3]'
                  : 'bg-[#10131a] text-[#908fa0] hover:text-white border-[#464554]/40'
              }`}
            >
              <Zap className="w-3.5 h-3.5" /> {params.isAnimated ? 'AO Live' : 'Paused'}
            </button>

            <button
              onClick={handleResetCamera}
              title="Reset Orbit View"
              className="p-1.5 rounded-xl bg-[#10131a] hover:bg-[#2b303c] text-[#c7c4d7] hover:text-white border border-[#464554]/40 transition-colors"
            >
              <Compass className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 3D Canvas Stage */}
        <div className="w-full h-[480px] sm:h-[580px] lg:h-[660px] relative bg-gradient-to-b from-[#080b10] via-[#0d121c] to-[#080b10]">
          <Canvas
            camera={{ position: [0, -13, 10], fov: 44 }}
            className="w-full h-full cursor-grab active:cursor-grabbing"
          >
            <ambientLight intensity={0.8} />
            <directionalLight position={[12, 12, 18]} intensity={1.4} />
            <pointLight position={[-12, -12, 8]} intensity={0.8} color="#00cbe6" />
            <pointLight position={[12, -12, 8]} intensity={0.6} color="#8083ff" />

            {/* Wavefront Surface & Actuator Matrix */}
            <WavefrontMesh params={params} />

            {/* Interactive Orbit Controls */}
            <OrbitControls
              ref={controlsRef}
              makeDefault
              enableDamping={true}
              dampingFactor={0.06}
              minDistance={5}
              maxDistance={35}
              maxPolarAngle={Math.PI / 1.15}
            />
          </Canvas>

          {/* Floating Canvas Footer Info overlay */}
          <div className="absolute bottom-4 left-4 right-4 pointer-events-none flex items-center justify-between">
            <div className="px-3.5 py-2 rounded-xl bg-[#12151d]/85 backdrop-blur-md border border-[#464554]/40 font-mono text-[11px] text-[#00cbe6] shadow-lg flex items-center gap-2 pointer-events-auto">
              <span className="w-2 h-2 rounded-full bg-[#00cbe6] animate-ping" />
              <span>STAGE: <strong>REACT THREE FIBER WEBGL 2.0</strong></span>
            </div>

            <div className="hidden md:flex px-4 py-2 rounded-xl bg-[#12151d]/85 backdrop-blur-md border border-[#464554]/40 font-mono text-[11px] text-[#c7c4d7] shadow-lg items-center gap-4">
              <span>🖱️ Left-Click + Drag: <strong>Orbit</strong></span>
              <span>📜 Scroll: <strong>Zoom</strong></span>
              <span>🖱️ Right-Click + Drag: <strong>Pan</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Optical Aberration Tuning Sliders */}
      <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 md:p-8 shadow-lg space-y-6">
        <div className="flex items-center justify-between border-b border-[#464554]/20 pb-4">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Sliders className="w-4 h-4 text-[#00cbe6]" /> Real-Time Wavefront Aberration Tuning
          </div>
          <span className="text-xs font-mono text-[#908fa0]">Simulate Shack-Hartmann Phase Abortions</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Amplitude */}
          <div className="space-y-2.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#c7c4d7] font-bold">Wavefront Amplitude</span>
              <span className="text-[#00cbe6] font-extrabold">{params.amplitude.toFixed(2)} λ</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="3.0"
              step="0.05"
              value={params.amplitude}
              onChange={(e) => setParams(prev => ({ ...prev, amplitude: parseFloat(e.target.value) }))}
              className="w-full h-2 bg-[#080b10] rounded-lg appearance-none cursor-pointer accent-[#00cbe6]"
            />
            <p className="text-[10px] text-[#908fa0]">Scales Peak-to-Valley (P-V) phase error</p>
          </div>

          {/* Spherical */}
          <div className="space-y-2.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#c7c4d7] font-bold">Spherical Aberration</span>
              <span className="text-[#8083ff] font-extrabold">{params.spherical > 0 ? '+' : ''}{params.spherical.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="-1.0"
              max="1.0"
              step="0.05"
              value={params.spherical}
              onChange={(e) => setParams(prev => ({ ...prev, spherical: parseFloat(e.target.value) }))}
              className="w-full h-2 bg-[#080b10] rounded-lg appearance-none cursor-pointer accent-[#8083ff]"
            />
            <p className="text-[10px] text-[#908fa0]">Noll mode $Z_{11}$ 4th-order radial curvature</p>
          </div>

          {/* Astigmatism */}
          <div className="space-y-2.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#c7c4d7] font-bold">Astigmatism ($Z_5, Z_6$)</span>
              <span className="text-[#4edea3] font-extrabold">{params.astigmatism > 0 ? '+' : ''}{params.astigmatism.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="-1.0"
              max="1.0"
              step="0.05"
              value={params.astigmatism}
              onChange={(e) => setParams(prev => ({ ...prev, astigmatism: parseFloat(e.target.value) }))}
              className="w-full h-2 bg-[#080b10] rounded-lg appearance-none cursor-pointer accent-[#4edea3]"
            />
            <p className="text-[10px] text-[#908fa0]">Symmetric quadratic cylinder error</p>
          </div>

          {/* Seeing Noise */}
          <div className="space-y-2.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#c7c4d7] font-bold">Seeing Jitter ($r_0$)</span>
              <span className="text-[#ffc857] font-extrabold">{params.turbulenceNoise}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="1"
              value={params.turbulenceNoise}
              onChange={(e) => setParams(prev => ({ ...prev, turbulenceNoise: parseInt(e.target.value) }))}
              className="w-full h-2 bg-[#080b10] rounded-lg appearance-none cursor-pointer accent-[#ffc857]"
            />
            <p className="text-[10px] text-[#908fa0]">High-frequency Kolmogorov scintillation</p>
          </div>
        </div>
      </div>
    </div>
  );
};
