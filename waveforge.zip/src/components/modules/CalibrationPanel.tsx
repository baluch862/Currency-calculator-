import React, { useEffect, useRef, useState } from 'react';
import { 
  Cpu, Sliders, Eye, RotateCcw, ShieldCheck, CheckCircle2, 
  AlertTriangle, Layers, Zap, Info, Camera, Sparkles, Filter, Split
} from 'lucide-react';
import { CalibrationParams } from '../../types';

interface CalibrationPanelProps {
  params: CalibrationParams;
  onChangeParams: (params: CalibrationParams) => void;
  onResetCalibration: () => void;
}

export const CalibrationPanel: React.FC<CalibrationPanelProps> = ({
  params,
  onChangeParams,
  onResetCalibration
}) => {
  const [viewMode, setViewMode] = useState<'dual' | 'split' | 'diff'>('dual');
  const [splitPos, setSplitPos] = useState<number>(50); // percentage for split screen
  const [isCapturingDark, setIsCapturingDark] = useState<boolean>(false);
  const [isComputingFlat, setIsComputingFlat] = useState<boolean>(false);

  const rawCanvasRef = useRef<HTMLCanvasElement>(null);
  const cleanCanvasRef = useRef<HTMLCanvasElement>(null);
  const diffCanvasRef = useRef<HTMLCanvasElement>(null);

  // Simulated metrics
  const snrBoostDb = (params.enableDarkSubtraction ? 6.8 : 0) + (params.enableFlatField ? 5.2 : 0) + (params.enableBadPixelMap ? 2.4 : 0);
  const hotPixelsReplaced = params.enableBadPixelMap ? Math.floor((params.hotPixelThreshold / 100) * 58) : 0;
  const vignettingSuppressedPct = params.enableFlatField ? 98.6 : 12.4;

  const handleCaptureDark = () => {
    setIsCapturingDark(true);
    setTimeout(() => {
      setIsCapturingDark(false);
      onChangeParams({
        ...params,
        enableDarkSubtraction: true,
        masterDarkAdu: 480
      });
    }, 800);
  };

  const handleComputeFlat = () => {
    setIsComputingFlat(true);
    setTimeout(() => {
      setIsComputingFlat(false);
      onChangeParams({
        ...params,
        enableFlatField: true,
        flatFieldGain: 1.15
      });
    }, 1000);
  };

  // Render simulation canvases
  useEffect(() => {
    let animId: number;
    let t = 0;

    // Fixed hot pixel positions
    const hotPixels = [
      { x: 45, y: 30 }, { x: 120, y: 88 }, { x: 310, y: 45 }, 
      { x: 220, y: 190 }, { x: 380, y: 150 }, { x: 90, y: 230 },
      { x: 410, y: 70 }, { x: 180, y: 120 }, { x: 280, y: 220 }
    ];

    const drawScene = (
      ctx: CanvasRenderingContext2D, 
      width: number, 
      height: number, 
      type: 'raw' | 'clean' | 'diff'
    ) => {
      const imgData = ctx.createImageData(width, height);
      const data = imgData.data;

      const cols = 10;
      const rows = 6;
      const cellW = width / (cols + 1);
      const cellH = height / (rows + 1);

      for (let x = 0; x < width; x++) {
        for (let y = 0; y < height; y++) {
          const idx = (y * width + x) * 4;

          // Normalized coordinates from center (-1 to 1)
          const nx = (x / width - 0.5) * 2;
          const ny = (y / height - 0.5) * 2;
          const distFromCenter = Math.sqrt(nx * nx + ny * ny);

          // Vignetting mask (dim in corners)
          const vignetting = Math.max(0.2, 1 - distFromCenter * 0.55);

          // Base dark pedestal noise (random high ADU floor)
          const darkNoise = Math.sin(x * 43 + y * 71 + t) * 18 + ((x * 13 + y * 29) % 35);

          // Find closest lenslet spot
          let spotIntensity = 0;
          for (let c = 1; c <= cols; c++) {
            for (let r = 1; r <= rows; r++) {
              const spotX = c * cellW + Math.sin(t * 0.5 + c) * 1.5;
              const spotY = r * cellH + Math.cos(t * 0.4 + r) * 1.5;
              const dx = x - spotX;
              const dy = y - spotY;
              const d2 = dx * dx + dy * dy;

              if (d2 < 64) {
                // Gaussian spot
                spotIntensity += Math.exp(-d2 / 12) * 220;
              }
            }
          }

          if (type === 'raw') {
            // Apply vignetting & dark noise
            let val = (spotIntensity * vignetting) + darkNoise + (params.masterDarkAdu * 0.12);

            // Add hot pixels
            for (const hp of hotPixels) {
              if (Math.abs(x - hp.x) < 2 && Math.abs(y - hp.y) < 2) {
                val = 255;
              }
            }

            data[idx] = Math.min(255, Math.floor(val * 0.4));
            data[idx + 1] = Math.min(255, Math.floor(val * 0.7));
            data[idx + 2] = Math.min(255, Math.floor(val));
            data[idx + 3] = 255;

          } else if (type === 'clean') {
            let val = spotIntensity;

            // If flat field disabled, keep vignetting dim corners
            if (!params.enableFlatField) {
              val *= vignetting;
            } else {
              val *= params.flatFieldGain;
            }

            // If dark subtraction disabled, keep dark pedestal background noise
            if (!params.enableDarkSubtraction) {
              val += darkNoise + (params.masterDarkAdu * 0.12);
            }

            // If bad pixels disabled, keep stuck hot pixels
            if (!params.enableBadPixelMap) {
              for (const hp of hotPixels) {
                if (Math.abs(x - hp.x) < 2 && Math.abs(y - hp.y) < 2) {
                  val = 255;
                }
              }
            }

            // Apply slight smoothing if filter selected
            if (params.filterKernel !== 'None') {
              val *= 1.05;
            }

            // Clean palette: High contrast Cyan / Indigo spots on deep black
            data[idx] = Math.min(255, Math.floor(val * 0.2));
            data[idx + 1] = Math.min(255, Math.floor(val * 0.9));
            data[idx + 2] = Math.min(255, Math.floor(val));
            data[idx + 3] = 255;

          } else {
            // Difference Map (Residual Noise Subtracted Out)
            let diff = darkNoise + (params.masterDarkAdu * 0.12);
            if (params.enableFlatField) {
              diff += spotIntensity * (1 - vignetting) * 0.8;
            }
            for (const hp of hotPixels) {
              if (Math.abs(x - hp.x) < 2 && Math.abs(y - hp.y) < 2) {
                diff += 200;
              }
            }

            // False color heat map for removed noise (Rose / Gold)
            data[idx] = Math.min(255, Math.floor(diff * 1.2));
            data[idx + 1] = Math.min(255, Math.floor(diff * 0.3));
            data[idx + 2] = Math.min(255, Math.floor(diff * 0.4));
            data[idx + 3] = 255;
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);
    };

    const loop = () => {
      t += 0.05;
      if (rawCanvasRef.current) {
        const c = rawCanvasRef.current;
        drawScene(c.getContext('2d')!, c.width, c.height, 'raw');
      }
      if (cleanCanvasRef.current) {
        const c = cleanCanvasRef.current;
        drawScene(c.getContext('2d')!, c.width, c.height, 'clean');
      }
      if (diffCanvasRef.current) {
        const c = diffCanvasRef.current;
        drawScene(c.getContext('2d')!, c.width, c.height, 'diff');
      }
      animId = requestAnimationFrame(loop);
    };

    loop();
    return () => cancelAnimationFrame(animId);
  }, [params]);

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#1a2333] to-[#121624] border border-[#464554]/40 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-[#5de6ff] font-mono text-xs font-bold uppercase tracking-widest">
            <Cpu className="w-4 h-4 animate-pulse" /> CUDA Optical Preprocessing Pipeline
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Shack-Hartmann Sensor Preprocessing &amp; Calibration
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Perform real-time master dark-frame subtraction, flat-field illumination uniformity correction, and bad pixel map interpolation on raw uncalibrated CCD wavefront frames.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="px-3.5 py-1.5 bg-[#10131a] rounded-xl border border-[#00cbe6]/40 flex items-center gap-2 font-mono text-xs text-[#00cbe6] shadow-[0_0_15px_rgba(0,203,230,0.15)]">
            <Sparkles className="w-4 h-4" />
            <span>SNR Boost: +{snrBoostDb.toFixed(1)} dB</span>
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Settings & Actions Rail (col-4) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-6">
            <div className="flex items-center justify-between border-b border-[#464554]/30 pb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#5de6ff]" /> Calibration Pipeline Steps
              </h3>
              <button
                onClick={onResetCalibration}
                title="Reset Calibration Parameters"
                className="p-1.5 text-[#908fa0] hover:text-[#ffb4ab] hover:bg-[#272a31] rounded transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-5">
              {/* Step 1: Dark Frame Subtraction */}
              <div className="p-3.5 rounded-xl bg-[#10131a]/80 border border-[#464554]/40 space-y-3 transition-colors hover:border-[#8083ff]/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className={`w-4 h-4 ${params.enableDarkSubtraction ? 'text-[#4edea3]' : 'text-[#464554]'}`} />
                    1. Master Dark Subtraction
                  </span>
                  <input
                    type="checkbox"
                    checked={params.enableDarkSubtraction}
                    onChange={(e) => onChangeParams({ ...params, enableDarkSubtraction: e.target.checked })}
                    className="w-4 h-4 accent-[#4edea3] cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-[#908fa0]">
                  Subtract fixed-pattern CCD thermal noise &amp; bias pedestal offsets.
                </p>

                {params.enableDarkSubtraction && (
                  <div className="pt-2 space-y-1.5 border-t border-[#464554]/20">
                    <div className="flex justify-between text-[11px] font-mono">
                      <span className="text-[#c7c4d7]">Bias Pedestal Level:</span>
                      <span className="text-[#c0c1ff] font-bold">{params.masterDarkAdu} ADU</span>
                    </div>
                    <input
                      type="range"
                      min="100"
                      max="800"
                      step="20"
                      value={params.masterDarkAdu}
                      onChange={(e) => onChangeParams({ ...params, masterDarkAdu: Number(e.target.value) })}
                      className="w-full accent-[#c0c1ff] cursor-pointer h-1 bg-[#272a31] rounded"
                    />
                  </div>
                )}
              </div>

              {/* Step 2: Flat Field Correction */}
              <div className="p-3.5 rounded-xl bg-[#10131a]/80 border border-[#464554]/40 space-y-3 transition-colors hover:border-[#00cbe6]/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className={`w-4 h-4 ${params.enableFlatField ? 'text-[#00cbe6]' : 'text-[#464554]'}`} />
                    2. Flat-Field Illumination Gain
                  </span>
                  <input
                    type="checkbox"
                    checked={params.enableFlatField}
                    onChange={(e) => onChangeParams({ ...params, enableFlatField: e.target.checked })}
                    className="w-4 h-4 accent-[#00cbe6] cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-[#908fa0]">
                  Correct optical vignetting &amp; non-uniform lenslet micro-lens transmission.
                </p>

                {params.enableFlatField && (
                  <div className="pt-2 space-y-1.5 border-t border-[#464554]/20">
                    <div className="flex justify-between text-[11px] font-mono">
                      <span className="text-[#c7c4d7]">Uniformity Gain Multiplier:</span>
                      <span className="text-[#5de6ff] font-bold">{params.flatFieldGain.toFixed(2)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.50"
                      max="2.00"
                      step="0.05"
                      value={params.flatFieldGain}
                      onChange={(e) => onChangeParams({ ...params, flatFieldGain: Number(e.target.value) })}
                      className="w-full accent-[#00cbe6] cursor-pointer h-1 bg-[#272a31] rounded"
                    />
                  </div>
                )}
              </div>

              {/* Step 3: Bad Pixel Map */}
              <div className="p-3.5 rounded-xl bg-[#10131a]/80 border border-[#464554]/40 space-y-3 transition-colors hover:border-[#ffb4ab]/40">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-2">
                    <CheckCircle2 className={`w-4 h-4 ${params.enableBadPixelMap ? 'text-[#ffb4ab]' : 'text-[#464554]'}`} />
                    3. Bad / Hot Pixel Interpolation
                  </span>
                  <input
                    type="checkbox"
                    checked={params.enableBadPixelMap}
                    onChange={(e) => onChangeParams({ ...params, enableBadPixelMap: e.target.checked })}
                    className="w-4 h-4 accent-[#ffb4ab] cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-[#908fa0]">
                  Replace stuck high-ADU cosmic rays via 5x5 median neighbor consensus.
                </p>
              </div>

              {/* Filter Kernel Selector */}
              <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                <span className="text-xs font-semibold text-[#c7c4d7] flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-[#5de6ff]" /> Spatial Denoising Kernel
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(['None', 'Gaussian_3x3', 'Median_5x5', 'Bilateral'] as const).map((knl) => (
                    <button
                      key={knl}
                      onClick={() => onChangeParams({ ...params, filterKernel: knl })}
                      className={`py-2 rounded-lg text-[11px] font-bold transition-all border ${
                        params.filterKernel === knl
                          ? 'bg-[#494bd6] text-white border-[#8083ff] shadow-[0_0_10px_rgba(73,75,214,0.4)]'
                          : 'bg-[#272a31]/60 text-[#908fa0] border-[#464554]/30 hover:text-white'
                      }`}
                    >
                      {knl.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Acquisition Buttons */}
            <div className="pt-4 border-t border-[#464554]/20 space-y-2.5 font-mono text-xs">
              <button
                onClick={handleCaptureDark}
                disabled={isCapturingDark}
                className="w-full py-2.5 rounded-lg bg-[#272a31] hover:bg-[#32353c] border border-[#464554] text-[#c0c1ff] font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
              >
                <Camera className="w-4 h-4" />
                {isCapturingDark ? 'Acquiring 50 Dark Bias Frames...' : 'Capture Master Dark Baseline'}
              </button>

              <button
                onClick={handleComputeFlat}
                disabled={isComputingFlat}
                className="w-full py-2.5 rounded-lg bg-[#272a31] hover:bg-[#32353c] border border-[#464554] text-[#5de6ff] font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                {isComputingFlat ? 'Integrating Integrating Integrating Sphere...' : 'Synthesize Master Flat Field'}
              </button>
            </div>
          </div>

          {/* Realtime Telemetry Summary */}
          <div className="bg-[#10131a] rounded-2xl p-5 border border-[#464554]/30 space-y-3 font-mono text-xs">
            <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">
              Calibration Verification Telemetry
            </p>
            <div className="space-y-2">
              <div className="flex justify-between items-center pb-1.5 border-b border-white/5">
                <span className="text-[#c7c4d7]">Vignetting Suppressed:</span>
                <span className="text-[#4edea3] font-bold">{vignettingSuppressedPct}%</span>
              </div>
              <div className="flex justify-between items-center pb-1.5 border-b border-white/5">
                <span className="text-[#c7c4d7]">Hot Pixels Corrected:</span>
                <span className="text-[#ffb4ab] font-bold">{hotPixelsReplaced} / 58 px</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#c7c4d7]">Read Noise Floor:</span>
                <span className="text-[#00cbe6] font-bold">{params.readNoiseE} e- RMS</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Canvases Comparison Viewport (col-8) */}
        <div className="lg:col-span-8 space-y-6 flex flex-col">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-lg flex flex-col flex-1 min-h-[500px]">
            {/* Viewport Header */}
            <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#00cbe6]" />
                <span className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb]">
                  Real-time WFS Calibration Inspector
                </span>
              </div>

              {/* Mode Switcher */}
              <div className="flex items-center gap-1 bg-[#10131a] p-1 rounded-lg border border-[#464554]/30">
                <button
                  onClick={() => setViewMode('dual')}
                  className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 ${
                    viewMode === 'dual'
                      ? 'bg-[#00cbe6]/20 text-[#00cbe6] border border-[#00cbe6]/40 shadow-sm'
                      : 'text-[#908fa0] hover:text-white'
                  }`}
                >
                  <Split className="w-3 h-3" /> Side-by-Side Dual View
                </button>
                <button
                  onClick={() => setViewMode('diff')}
                  className={`px-3 py-1 rounded text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 ${
                    viewMode === 'diff'
                      ? 'bg-[#ffb4ab]/20 text-[#ffb4ab] border border-[#ffb4ab]/40 shadow-sm'
                      : 'text-[#908fa0] hover:text-white'
                  }`}
                >
                  <AlertTriangle className="w-3 h-3" /> Residual Noise Map
                </button>
              </div>
            </div>

            {/* Canvases Render Stage */}
            <div className="p-6 bg-[#080b10] flex-1 flex flex-col items-center justify-center">
              {viewMode === 'dual' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-4xl">
                  {/* Left: Uncalibrated Raw Canvas */}
                  <div className="space-y-2 flex flex-col items-center">
                    <div className="relative rounded-xl overflow-hidden border border-[#ffb4ab]/40 bg-black shadow-lg w-full max-w-[440px]">
                      <canvas
                        ref={rawCanvasRef}
                        width={440}
                        height={320}
                        className="w-full h-[300px] object-cover"
                      />
                      <div className="absolute top-3 left-3 px-2.5 py-1 bg-black/80 backdrop-blur rounded border border-[#ffb4ab]/30 font-mono text-[10px] text-[#ffb4ab] uppercase font-bold flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#ffb4ab] animate-ping" /> Raw Uncalibrated Frame
                      </div>
                      <div className="absolute bottom-3 left-3 right-3 flex justify-between font-mono text-[9px] text-[#908fa0] bg-black/60 px-2 py-1 rounded">
                        <span>PEDESTAL: 480 ADU</span>
                        <span>VIGNETTING: HIGH</span>
                      </div>
                    </div>
                    <p className="text-xs text-[#908fa0] font-mono text-center">
                      Exhibits CCD bias offset, hot magenta cosmic rays &amp; dim corner falloff.
                    </p>
                  </div>

                  {/* Right: Clean Calibrated Canvas */}
                  <div className="space-y-2 flex flex-col items-center">
                    <div className="relative rounded-xl overflow-hidden border border-[#00cbe6]/40 bg-black shadow-[0_0_30px_rgba(0,203,230,0.12)] w-full max-w-[440px]">
                      <canvas
                        ref={cleanCanvasRef}
                        width={440}
                        height={320}
                        className="w-full h-[300px] object-cover"
                      />
                      <div className="absolute top-3 left-3 px-2.5 py-1 bg-black/80 backdrop-blur rounded border border-[#00cbe6]/30 font-mono text-[10px] text-[#5de6ff] uppercase font-bold flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-pulse" /> Calibrated &amp; Flattened Output
                      </div>
                      <div className="absolute bottom-3 left-3 right-3 flex justify-between font-mono text-[9px] text-[#4edea3] bg-black/60 px-2 py-1 rounded">
                        <span>PEDESTAL: 0 ADU</span>
                        <span>UNIFORMITY: 99.1%</span>
                      </div>
                    </div>
                    <p className="text-xs text-[#5de6ff] font-mono text-center">
                      Ready for sub-pixel centroid slope extraction algorithms.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 w-full max-w-2xl flex flex-col items-center">
                  <div className="relative rounded-xl overflow-hidden border border-[#ffb4ab]/60 bg-black shadow-[0_0_40px_rgba(255,180,171,0.15)] w-full">
                    <canvas
                      ref={diffCanvasRef}
                      width={640}
                      height={360}
                      className="w-full h-[360px] object-cover"
                    />
                    <div className="absolute top-4 left-4 px-3 py-1.5 bg-black/85 backdrop-blur rounded border border-[#ffb4ab]/40 font-mono text-xs text-[#ffb4ab] uppercase font-bold flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4" /> Subtracted Residual Artifact Map (Raw minus Clean)
                    </div>
                  </div>
                  <p className="text-xs text-[#c7c4d7] text-center max-w-lg leading-relaxed">
                    False-color heat map highlighting the exact thermal pedestal offset, hot pixel spikes, and vignetting transmission losses removed by the CUDA kernel.
                  </p>
                </div>
              )}
            </div>

            {/* Bottom Status Legend */}
            <div className="p-4 bg-[#10131a] border-t border-[#464554]/30 flex flex-wrap items-center justify-between gap-4 font-mono text-xs text-[#c7c4d7]">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00cbe6]" /> Nominal Spot SNR: 48.2 dB
                </span>
                <span className="text-[#464554]">|</span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#ffb4ab]" /> Hot Pixel Threshold: {params.hotPixelThreshold}%
                </span>
              </div>

              <div className="text-[#4edea3] font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" /> KERNEL EXEC TIME: 0.38 ms (NVIDIA RTX 4090)
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
