import React, { useEffect, useRef, useState, useMemo } from 'react';
import { 
  Activity, Sliders, RotateCcw, Sparkles, Eye, Layers, Box, Grid, 
  BarChart2, RefreshCw, ShieldCheck, CheckCircle2, Zap, Info, ArrowRight,
  Maximize2, Minimize2
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid 
} from 'recharts';
import { ZernikeParams } from '../../types';

interface ZernikePanelProps {
  params: ZernikeParams;
  onChangeParams: (params: ZernikeParams) => void;
  onResetToNominal: () => void;
}

// Factorial lookup table up to 10
const FACT = [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800];

// Standard Noll indices (1 to 36) definition
export const NOLL_MODES: { j: number; n: number; m: number; name: string; category: string }[] = [
  { j: 1, n: 0, m: 0, name: 'Piston', category: 'Zero Order' },
  { j: 2, n: 1, m: 1, name: 'Tip X', category: '1st Order' },
  { j: 3, n: 1, m: -1, name: 'Tilt Y', category: '1st Order' },
  { j: 4, n: 2, m: 0, name: 'Defocus', category: '2nd Order' },
  { j: 5, n: 2, m: -2, name: 'Oblique Astigmatism', category: '2nd Order' },
  { j: 6, n: 2, m: 2, name: 'Vertical Astigmatism', category: '2nd Order' },
  { j: 7, n: 3, m: -1, name: 'Vertical Coma', category: '3rd Order' },
  { j: 8, n: 3, m: 1, name: 'Horizontal Coma', category: '3rd Order' },
  { j: 9, n: 3, m: -3, name: 'Vertical Trefoil', category: '3rd Order' },
  { j: 10, n: 3, m: 3, name: 'Oblique Trefoil', category: '3rd Order' },
  { j: 11, n: 4, m: 0, name: 'Primary Spherical', category: '4th Order' },
  { j: 12, n: 4, m: 2, name: 'Vert Sec Astigmatism', category: '4th Order' },
  { j: 13, n: 4, m: -2, name: 'Obl Sec Astigmatism', category: '4th Order' },
  { j: 14, n: 4, m: 4, name: 'Vertical Quadrafoil', category: '4th Order' },
  { j: 15, n: 4, m: -4, name: 'Oblique Quadrafoil', category: '4th Order' },
  { j: 16, n: 5, m: 1, name: 'Sec Coma X', category: '5th Order' },
  { j: 17, n: 5, m: -1, name: 'Sec Coma Y', category: '5th Order' },
  { j: 18, n: 5, m: 3, name: 'Sec Trefoil X', category: '5th Order' },
  { j: 19, n: 5, m: -3, name: 'Sec Trefoil Y', category: '5th Order' },
  { j: 20, n: 5, m: 5, name: 'Pentafoil X', category: '5th Order' },
  { j: 21, n: 5, m: -5, name: 'Pentafoil Y', category: '5th Order' },
  { j: 22, n: 6, m: 0, name: 'Sec Spherical', category: '6th Order' },
  { j: 23, n: 6, m: -2, name: 'Tert Astigmatism Y', category: '6th Order' },
  { j: 24, n: 6, m: 2, name: 'Tert Astigmatism X', category: '6th Order' },
  { j: 25, n: 6, m: -4, name: 'Sec Quadrafoil Y', category: '6th Order' },
  { j: 26, n: 6, m: 4, name: 'Sec Quadrafoil X', category: '6th Order' },
  { j: 27, n: 6, m: -6, name: 'Hexafoil Y', category: '6th Order' },
  { j: 28, n: 6, m: 6, name: 'Hexafoil X', category: '6th Order' },
  { j: 29, n: 7, m: -1, name: 'Tert Coma Y', category: '7th Order' },
  { j: 30, n: 7, m: 1, name: 'Tert Coma X', category: '7th Order' },
  { j: 31, n: 7, m: -3, name: 'Tert Trefoil Y', category: '7th Order' },
  { j: 32, n: 7, m: 3, name: 'Tert Trefoil X', category: '7th Order' },
  { j: 33, n: 7, m: -5, name: 'Sec Pentafoil Y', category: '7th Order' },
  { j: 34, n: 7, m: 5, name: 'Sec Pentafoil X', category: '7th Order' },
  { j: 35, n: 7, m: -7, name: 'Heptafoil Y', category: '7th Order' },
  { j: 36, n: 7, m: 7, name: 'Heptafoil X', category: '7th Order' }
];

// Compute single Zernike polynomial value
function evalZernike(n: number, m: number, r: number, theta: number): number {
  if (r > 1.0) return 0;
  const absM = Math.abs(m);
  let R = 0;
  const sMax = (n - absM) / 2;
  for (let s = 0; s <= sMax; s++) {
    const num = Math.pow(-1, s) * FACT[n - s];
    const den = FACT[s] * FACT[(n + absM) / 2 - s] * FACT[(n - absM) / 2 - s];
    R += (num / den) * Math.pow(r, n - 2 * s);
  }
  const norm = Math.sqrt(m === 0 ? n + 1 : 2 * (n + 1));
  if (m === 0) {
    return norm * R;
  } else if (m > 0) {
    return norm * R * Math.cos(m * theta);
  } else {
    return norm * R * Math.sin(absM * theta);
  }
}

export const ZernikePanel: React.FC<ZernikePanelProps> = ({
  params,
  onChangeParams,
  onResetToNominal
}) => {
  // Nominal coefficients in waves (lambda)
  const [coefficients, setCoefficients] = useState<number[]>([
    0.05,   // 1: Piston
    0.32,   // 2: Tip
    -0.28,  // 3: Tilt
    0.48,   // 4: Defocus
    0.24,   // 5: Obl Astig
    -0.19,  // 6: Vert Astig
    0.14,   // 7: Vert Coma
    -0.11,  // 8: Horiz Coma
    0.08,   // 9: Vert Trefoil
    -0.06,  // 10: Obl Trefoil
    0.09,   // 11: Prim Spherical
    0.04,   // 12: Vert Sec Astig
    -0.05,  // 13: Obl Sec Astig
    0.03,   // 14: Vert Quadrafoil
    -0.02,  // 15: Obl Quadrafoil
    0.04,   // 16: Sec Coma X
    -0.03,  // 17: Sec Coma Y
    0.02,   // 18: Sec Trefoil X
    -0.01,  // 19: Sec Trefoil Y
    0.01,   // 20: Pentafoil X
    -0.01,  // 21: Pentafoil Y
    0.03,   // 22: Sec Spherical
    0.01,   // 23: Tert Astig Y
    -0.01,  // 24: Tert Astig X
    0.01,   // 25: Sec Quad Y
    -0.01,  // 26: Sec Quad X
    0.005,  // 27: Hexafoil Y
    -0.005, // 28: Hexafoil X
    0.01,   // 29: Tert Coma Y
    -0.008, // 30: Tert Coma X
    0.005,  // 31: Tert Trefoil Y
    -0.004, // 32: Tert Trefoil X
    0.003,  // 33: Sec Penta Y
    -0.002, // 34: Sec Penta X
    0.001,  // 35: Heptafoil Y
    -0.001  // 36: Heptafoil X
  ]);

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedModeIndex, setSelectedModeIndex] = useState<number | null>(4); // Default select Defocus (j=4)

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Apply filters
  const effectiveCoeffs = useMemo(() => {
    return coefficients.map((val, idx) => {
      const j = idx + 1;
      if (params.removeTipTilt && (j === 2 || j === 3)) return 0;
      if (params.removeDefocus && j === 4) return 0;
      return val * params.wavefrontAmplitude;
    });
  }, [coefficients, params.removeTipTilt, params.removeDefocus, params.wavefrontAmplitude]);

  // Chart dataset
  const chartData = useMemo(() => {
    return NOLL_MODES.map((mode, idx) => ({
      ...mode,
      value: Number(effectiveCoeffs[idx].toFixed(4)),
      absVal: Math.abs(effectiveCoeffs[idx])
    }));
  }, [effectiveCoeffs]);

  // Metrics
  const totalRmsError = useMemo(() => {
    // For orthonormal Zernikes (Noll norm), RMS is sqrt(sum of a_j^2 for j>=2)
    let sumSq = 0;
    for (let i = 1; i < effectiveCoeffs.length; i++) {
      sumSq += effectiveCoeffs[i] * effectiveCoeffs[i];
    }
    return Math.sqrt(sumSq);
  }, [effectiveCoeffs]);

  const peakToValley = useMemo(() => {
    return totalRmsError * 3.42; // empirical peak-to-valley estimator
  }, [totalRmsError]);

  const handleRandomizeTurbulence = () => {
    setCoefficients(prev => prev.map((_, idx) => {
      if (idx === 0) return 0; // keep piston 0
      const orderDecay = 1 / Math.pow(NOLL_MODES[idx].n + 1, 1.4);
      return (Math.random() - 0.5) * 0.9 * orderDecay;
    }));
  };

  const handleZeroHighOrder = () => {
    setCoefficients(prev => prev.map((val, idx) => idx < 10 ? val : 0));
  };

  // Color mapping helper
  const getColorFromVal = (norm: number) => {
    // norm is between 0 (valley) and 1 (peak)
    if (params.colormap === 'Cyan_Plasma') {
      const r = Math.floor(norm * 180);
      const g = Math.floor(norm * 230 + 25);
      const b = 255;
      return `rgb(${r},${g},${b})`;
    } else if (params.colormap === 'Inferno') {
      const r = Math.floor(Math.sin(norm * Math.PI * 0.5) * 255);
      const g = Math.floor(Math.pow(norm, 2) * 220);
      const b = Math.floor((1 - norm) * 140);
      return `rgb(${r},${g},${b})`;
    } else if (params.colormap === 'Viridis') {
      const r = Math.floor(norm * 253);
      const g = Math.floor(Math.sin(norm * Math.PI * 0.7) * 231);
      const b = Math.floor((1 - norm) * 180 + 40);
      return `rgb(${r},${g},${b})`;
    } else {
      // Emerald Wave
      const r = Math.floor(norm * 40);
      const g = Math.floor(norm * 240 + 15);
      const b = Math.floor(norm * 160 + 40);
      return `rgb(${r},${g},${b})`;
    }
  };

  // 3D Rendering Stage
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const gridSize = 42; // radial grid points across diameter
    const R_MAX = 0.88; // pupil radius scale in viewport

    // Generate 3D grid points
    interface Point3D { x: number; y: number; z: number; r: number; theta: number; valid: boolean }
    const points: Point3D[][] = [];

    let minZ = 999;
    let maxZ = -999;

    for (let row = 0; row < gridSize; row++) {
      const gridRow: Point3D[] = [];
      const ny = (row / (gridSize - 1)) * 2 - 1; // -1 to 1

      for (let col = 0; col < gridSize; col++) {
        const nx = (col / (gridSize - 1)) * 2 - 1; // -1 to 1
        const r = Math.sqrt(nx * nx + ny * ny);
        const theta = Math.atan2(ny, nx);

        if (r <= 1.0) {
          // Evaluate wavefront phase Phi
          let phi = 0;
          if (selectedModeIndex !== null) {
            // Render single isolated mode
            const mode = NOLL_MODES[selectedModeIndex - 1];
            phi = effectiveCoeffs[selectedModeIndex - 1] * evalZernike(mode.n, mode.m, r, theta) * 2.5;
          } else {
            // Sum all 36 modes
            for (let j = 0; j < 36; j++) {
              const mode = NOLL_MODES[j];
              const c = effectiveCoeffs[j];
              if (c !== 0) {
                phi += c * evalZernike(mode.n, mode.m, r, theta);
              }
            }
          }

          if (phi < minZ) minZ = phi;
          if (phi > maxZ) maxZ = phi;

          gridRow.push({ x: nx, y: ny, z: phi, r, theta, valid: true });
        } else {
          gridRow.push({ x: nx, y: ny, z: 0, r, theta, valid: false });
        }
      }
      points.push(gridRow);
    }

    const zRange = Math.max(0.0001, maxZ - minZ);

    // Camera perspective angles
    const radX = (params.rotationX * Math.PI) / 180;
    const radZ = (params.rotationZ * Math.PI) / 180;
    const cosX = Math.cos(radX);
    const sinX = Math.sin(radX);
    const cosZ = Math.cos(radZ);
    const sinZ = Math.sin(radZ);

    const scale = (Math.min(width, height) / 2) * R_MAX;
    const cx = width / 2;
    const cy = height / 2 + 20;

    // Project 3D point to 2D
    const project = (p: Point3D) => {
      // Rotate around Z axis
      const rx = p.x * cosZ - p.y * sinZ;
      const ry = p.x * sinZ + p.y * cosZ;
      const rz = p.z * 0.45; // z amplitude elevation

      // Rotate around X axis (tilt)
      const py = ry * cosX - rz * sinX;
      const pz = ry * sinX + rz * cosX;

      return {
        screenX: cx + rx * scale,
        screenY: cy + py * scale,
        depth: pz
      };
    };

    if (params.displayMode === '2D_Interferogram') {
      // Render 2D false color heat map
      const imgData = ctx.createImageData(width, height);
      const data = imgData.data;

      for (let py = 0; py < height; py++) {
        for (let px = 0; px < width; px++) {
          const idx = (py * width + px) * 4;
          const nx = (px - cx) / scale;
          const ny = (py - cy + 20) / scale;
          const r = Math.sqrt(nx * nx + ny * ny);
          const theta = Math.atan2(ny, nx);

          if (r <= 1.0) {
            let phi = 0;
            if (selectedModeIndex !== null) {
              const mode = NOLL_MODES[selectedModeIndex - 1];
              phi = effectiveCoeffs[selectedModeIndex - 1] * evalZernike(mode.n, mode.m, r, theta) * 2.5;
            } else {
              for (let j = 0; j < 36; j++) {
                const mode = NOLL_MODES[j];
                const c = effectiveCoeffs[j];
                if (c !== 0) phi += c * evalZernike(mode.n, mode.m, r, theta);
              }
            }

            const norm = Math.max(0, Math.min(1, (phi - minZ) / zRange));
            
            // Interferometric fringes (wrapping phase)
            const fringe = Math.sin(phi * Math.PI * 4);
            const intensity = norm * 0.75 + (fringe > 0 ? 0.25 : 0);

            if (params.colormap === 'Cyan_Plasma') {
              data[idx] = Math.floor(intensity * 50);
              data[idx + 1] = Math.floor(intensity * 230);
              data[idx + 2] = Math.floor(255);
            } else if (params.colormap === 'Inferno') {
              data[idx] = Math.floor(intensity * 240);
              data[idx + 1] = Math.floor(Math.pow(intensity, 2) * 120);
              data[idx + 2] = Math.floor((1 - intensity) * 80);
            } else {
              data[idx] = Math.floor(intensity * 40);
              data[idx + 1] = Math.floor(intensity * 240);
              data[idx + 2] = Math.floor(intensity * 150);
            }
            data[idx + 3] = 255;
          } else {
            // Dark viewport backdrop
            data[idx] = 8; data[idx + 1] = 11; data[idx + 2] = 16; data[idx + 3] = 255;
          }
        }
      }
      ctx.putImageData(imgData, 0, 0);

      // Draw pupil boundary ring
      ctx.strokeStyle = '#464554';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy - 20, scale, 0, Math.PI * 2);
      ctx.stroke();

    } else {
      // 3D Surface Mesh Render
      interface Quad {
        p1: Point3D; p2: Point3D; p3: Point3D; p4: Point3D;
        avgZ: number; avgDepth: number;
      }
      const quads: Quad[] = [];

      for (let r = 0; r < gridSize - 1; r++) {
        for (let c = 0; c < gridSize - 1; c++) {
          const p1 = points[r][c];
          const p2 = points[r][c + 1];
          const p3 = points[r + 1][c + 1];
          const p4 = points[r + 1][c];

          if (p1.valid && p2.valid && p3.valid && p4.valid) {
            const pr1 = project(p1);
            const pr2 = project(p2);
            const pr3 = project(p3);
            const pr4 = project(p4);

            const avgZ = (p1.z + p2.z + p3.z + p4.z) / 4;
            const avgDepth = (pr1.depth + pr2.depth + pr3.depth + pr4.depth) / 4;

            quads.push({ p1, p2, p3, p4, avgZ, avgDepth });
          }
        }
      }

      // Painter's algorithm (sort back to front)
      quads.sort((a, b) => a.avgDepth - b.avgDepth);

      for (const q of quads) {
        const pr1 = project(q.p1);
        const pr2 = project(q.p2);
        const pr3 = project(q.p3);
        const pr4 = project(q.p4);

        const norm = Math.max(0, Math.min(1, (q.avgZ - minZ) / zRange));
        const color = getColorFromVal(norm);

        ctx.beginPath();
        ctx.moveTo(pr1.screenX, pr1.screenY);
        ctx.lineTo(pr2.screenX, pr2.screenY);
        ctx.lineTo(pr3.screenX, pr3.screenY);
        ctx.lineTo(pr4.screenX, pr4.screenY);
        ctx.closePath();

        if (params.wireframe) {
          ctx.strokeStyle = color;
          ctx.lineWidth = 1;
          ctx.stroke();
        } else {
          ctx.fillStyle = color;
          ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,0.35)';
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

  }, [effectiveCoeffs, params, selectedModeIndex]);

  // Mouse drag handlers for 3D rotation
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStart.x;
    const dy = e.clientY - dragStart.y;

    onChangeParams({
      ...params,
      rotationZ: (params.rotationZ + dx * 0.6 + 360) % 360,
      rotationX: Math.max(10, Math.min(85, params.rotationX + dy * 0.5))
    });
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => setIsDragging(false);

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#1c2136] to-[#121624] border border-[#464554]/40 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-widest">
            <Activity className="w-4 h-4 animate-pulse" /> Wavefront Modal Decomposition
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            36-Term Zernike Aberration Engine
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Decompose Shack-Hartmann wavefront phase maps into standard orthogonal Zernike polynomials over a circular unit pupil. Quantify tip, tilt, astigmatism, coma, trefoil, and spherical aberrations.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <div className="px-4 py-2 bg-[#10131a] rounded-xl border border-[#00cbe6]/40 flex items-center gap-2.5 font-mono text-xs text-[#5de6ff] shadow-[0_0_20px_rgba(0,203,230,0.2)]">
            <Sparkles className="w-4 h-4" />
            <span>RMS Error: {totalRmsError.toFixed(3)} λ</span>
          </div>
        </div>
      </div>

      {/* Main Grid Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Settings & Aberrations Bar (col-4) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-6">
            <div className="flex items-center justify-between border-b border-[#464554]/30 pb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#00cbe6]" /> Modal Pipeline Controls
              </h3>
              <button onClick={onResetToNominal} title="Reset Controls" className="text-[#908fa0] hover:text-white p-1 rounded hover:bg-[#272a31]">
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-2.5 font-mono text-xs">
              <button
                onClick={handleRandomizeTurbulence}
                className="p-3 rounded-xl bg-[#272a31] hover:bg-[#32353c] border border-[#464554] text-[#5de6ff] font-bold flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Randomize r₀</span>
              </button>
              <button
                onClick={handleZeroHighOrder}
                className="p-3 rounded-xl bg-[#272a31] hover:bg-[#32353c] border border-[#464554] text-[#ffb4ab] font-bold flex flex-col items-center justify-center gap-1.5 transition-all active:scale-95"
              >
                <Zap className="w-4 h-4" />
                <span>Zero High-Order</span>
              </button>
            </div>

            {/* Wavefront Amplitude Slider */}
            <div className="space-y-2">
              <div className="flex justify-between font-mono text-xs">
                <span className="text-[#c7c4d7]">Aberration Gain Multiplier:</span>
                <span className="text-[#00cbe6] font-bold">{params.wavefrontAmplitude.toFixed(1)}x</span>
              </div>
              <input
                type="range" min="0.2" max="3.0" step="0.1"
                value={params.wavefrontAmplitude}
                onChange={(e) => onChangeParams({ ...params, wavefrontAmplitude: Number(e.target.value) })}
                className="w-full accent-[#00cbe6] h-1.5 bg-[#272a31] rounded cursor-pointer"
              />
            </div>

            {/* Toggles */}
            <div className="space-y-3 pt-2 border-t border-[#464554]/20">
              <div className="flex items-center justify-between p-3 bg-[#10131a] rounded-xl border border-[#464554]/30">
                <span className="text-xs font-bold text-white">Suppress Tip &amp; Tilt (j=2, 3)</span>
                <input
                  type="checkbox" checked={params.removeTipTilt}
                  onChange={(e) => onChangeParams({ ...params, removeTipTilt: e.target.checked })}
                  className="w-4 h-4 accent-[#00cbe6] cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between p-3 bg-[#10131a] rounded-xl border border-[#464554]/30">
                <span className="text-xs font-bold text-white">Remove Focus (j=4)</span>
                <input
                  type="checkbox" checked={params.removeDefocus}
                  onChange={(e) => onChangeParams({ ...params, removeDefocus: e.target.checked })}
                  className="w-4 h-4 accent-[#ffb4ab] cursor-pointer"
                />
              </div>
            </div>

            {/* Viewport Display Mode & Colormap */}
            <div className="space-y-4 pt-2 border-t border-[#464554]/20">
              <div className="space-y-2">
                <span className="text-xs font-semibold text-[#c7c4d7]">Viewport Display Representation:</span>
                <div className="grid grid-cols-2 gap-2">
                  {(['3D_Surface', '2D_Interferogram'] as const).map((dm) => (
                    <button
                      key={dm}
                      onClick={() => onChangeParams({ ...params, displayMode: dm })}
                      className={`py-2 rounded-lg text-xs font-bold border transition-all ${
                        params.displayMode === dm
                          ? 'bg-[#494bd6] text-white border-[#8083ff] shadow-[0_0_15px_rgba(73,75,214,0.4)]'
                          : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                      }`}
                    >
                      {dm === '3D_Surface' ? '3D Surface Mesh' : '2D Phase Contours'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-semibold text-[#c7c4d7]">Surface Color Palette:</span>
                <div className="grid grid-cols-2 gap-2">
                  {(['Cyan_Plasma', 'Inferno', 'Viridis', 'Emerald_Wave'] as const).map((cm) => (
                    <button
                      key={cm}
                      onClick={() => onChangeParams({ ...params, colormap: cm })}
                      className={`py-1.5 rounded-lg text-[11px] font-bold border transition-all ${
                        params.colormap === cm
                          ? 'bg-[#1d2026] text-[#00cbe6] border-[#00cbe6]'
                          : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30 hover:text-white'
                      }`}
                    >
                      {cm.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {params.displayMode === '3D_Surface' && (
                <button
                  onClick={() => onChangeParams({ ...params, wireframe: !params.wireframe })}
                  className={`w-full py-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                    params.wireframe ? 'bg-[#1d2026] text-[#5de6ff] border-[#00cbe6]' : 'bg-[#10131a] text-[#908fa0] border-[#464554]/30'
                  }`}
                >
                  <Grid className="w-4 h-4" /> {params.wireframe ? 'Wireframe Mode Active' : 'Shaded Polygons Mode'}
                </button>
              )}
            </div>
          </div>

          {/* Telemetry Box */}
          <div className="bg-[#10131a] rounded-2xl p-5 border border-[#464554]/30 space-y-3 font-mono text-xs">
            <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">
              Wavefront Metrology Diagnostics
            </p>
            <div className="space-y-2">
              <div className="flex justify-between items-center pb-1.5 border-b border-white/5">
                <span className="text-[#c7c4d7]">Wavefront RMS Error:</span>
                <span className="text-[#5de6ff] font-bold">{totalRmsError.toFixed(4)} λ</span>
              </div>
              <div className="flex justify-between items-center pb-1.5 border-b border-white/5">
                <span className="text-[#c7c4d7]">Peak-to-Valley (P-V):</span>
                <span className="text-[#ffb4ab] font-bold">{peakToValley.toFixed(3)} λ</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#c7c4d7]">Strehl Ratio Estimate:</span>
                <span className="text-[#4edea3] font-bold">{(Math.exp(-Math.pow(totalRmsError * 2 * Math.PI, 2)) * 100).toFixed(1)}%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Stage: 3D Plot & Bar Chart (col-8) */}
        <div className="lg:col-span-8 space-y-6 flex flex-col">
          {/* Top: 3D Wavefront Reconstruction Viewport */}
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-lg flex flex-col">
            <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#00cbe6]" />
                <span className="text-xs font-bold uppercase tracking-widest text-white">
                  3D Wavefront Surface Plot {selectedModeIndex ? `— Showing Mode #${selectedModeIndex}: ${NOLL_MODES[selectedModeIndex-1].name}` : '— Composite All 36 Modes'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {selectedModeIndex !== null && (
                  <button
                    onClick={() => setSelectedModeIndex(null)}
                    className="px-3 py-1 rounded bg-[#00cbe6]/20 text-[#00cbe6] hover:bg-[#00cbe6]/30 font-mono text-[10px] font-bold uppercase transition-all"
                  >
                    Show Composite Sum (All Modes)
                  </button>
                )}
                <span className="text-[11px] font-mono text-[#908fa0] hidden sm:inline">
                  🖱️ DRAG TO ROTATE 3D MESH
                </span>
              </div>
            </div>

            <div className="p-6 bg-[#080b10] flex flex-col items-center justify-center relative min-h-[420px] cursor-grab active:cursor-grabbing">
              <canvas
                ref={canvasRef}
                width={740}
                height={400}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
                className="w-full h-[380px] max-w-4xl object-contain"
              />

              {/* Viewport Overlay Controls */}
              <div className="absolute bottom-4 left-4 font-mono text-[10px] text-[#908fa0] bg-black/75 px-3 py-2 rounded-xl border border-white/10 space-y-1">
                <div>AZIMUTH: <strong className="text-white">{params.rotationZ.toFixed(0)}°</strong></div>
                <div>ELEVATION: <strong className="text-white">{params.rotationX.toFixed(0)}°</strong></div>
              </div>

              {selectedModeIndex !== null && (
                <div className="absolute top-4 right-4 bg-black/85 backdrop-blur px-3.5 py-2 rounded-xl border border-[#00cbe6]/40 font-mono text-xs text-[#5de6ff] flex items-center gap-2 shadow-lg">
                  <Info className="w-4 h-4 text-[#4edea3]" />
                  <span>Isolated Mode: <strong>{NOLL_MODES[selectedModeIndex-1].name}</strong> ({effectiveCoeffs[selectedModeIndex-1].toFixed(3)} λ)</span>
                </div>
              )}
            </div>
          </div>

          {/* Bottom: 36 Zernike Coefficient Magnitude Bar Chart */}
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-white flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-[#8083ff]" /> Zernike Coefficient Magnitudes (Noll Index 1 to 36)
                </h3>
                <p className="text-[11px] text-[#908fa0] mt-0.5">
                  Click any bar to isolate its 3D polynomial surface representation above.
                </p>
              </div>

              <div className="flex items-center gap-4 font-mono text-xs text-[#c7c4d7]">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00cbe6]" /> Low Order (1-10)
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#8083ff]" /> High Order (11-36)
                </span>
              </div>
            </div>

            <div className="h-[240px] w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#272a31" vertical={false} />
                  <XAxis 
                    dataKey="j" 
                    stroke="#908fa0" 
                    fontSize={10} 
                    tickLine={false}
                    label={{ value: 'Noll Mode Index (j)', position: 'bottom', offset: 0, fill: '#908fa0', fontSize: 11 }}
                  />
                  <YAxis 
                    stroke="#908fa0" 
                    fontSize={10} 
                    tickLine={false}
                    domain={[-0.6, 0.6]}
                  />
                  <Tooltip 
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-[#10131a] p-3 rounded-xl border border-[#464554] shadow-2xl font-mono text-xs space-y-1">
                            <p className="text-[#00cbe6] font-bold">Mode #{d.j}: {d.name}</p>
                            <p className="text-[#c7c4d7]">Category: {d.category}</p>
                            <p className="text-white">Indices: n={d.n}, m={d.m}</p>
                            <p className="text-[#4edea3] font-bold pt-1 border-t border-white/10">Coeff: {d.value} λ</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar 
                    dataKey="value" 
                    radius={[4, 4, 0, 0]}
                    onClick={(data: any) => setSelectedModeIndex(data?.j ?? data?.payload?.j ?? 1)}
                    cursor="pointer"
                  >
                    {chartData.map((entry) => (
                      <Cell 
                        key={`cell-${entry.j}`} 
                        fill={
                          selectedModeIndex === entry.j 
                            ? '#4edea3' 
                            : entry.j <= 10 
                              ? '#00cbe6' 
                              : '#8083ff'
                        }
                        stroke={selectedModeIndex === entry.j ? '#ffffff' : 'transparent'}
                        strokeWidth={selectedModeIndex === entry.j ? 2 : 0}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
