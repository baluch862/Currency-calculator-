import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, Sparkles, Cpu, ShieldCheck, AlertTriangle, CheckCircle2, 
  Send, RefreshCw, Zap, Lightbulb, Wand2, ArrowRight, HelpCircle,
  Activity, Target, Layers, FileCode2, Terminal
} from 'lucide-react';
import { MetricData } from '../../types';

interface AIAssistantPanelProps {
  metrics: MetricData;
  onApplyAutoOptimization: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
  type?: 'explanation' | 'recommendation' | 'warning' | 'optimization';
  confidence?: number;
}

export const AIAssistantPanel: React.FC<AIAssistantPanelProps> = ({
  metrics,
  onApplyAutoOptimization
}) => {
  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState<'copilot' | 'diagnostics' | 'advisor'>('copilot');
  const [appliedRecommendations, setAppliedRecommendations] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial chat history with rich explanations
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: "Greetings, Optical Engineer. I am your Wavefront Metrology AI Copilot powered by deep convolutional vision models. I continuously monitor CCD frames, Fried parameter fluctuations (r₀), and Shack-Hartmann centroid localization grids.",
      timestamp: 'Just now',
      confidence: 99.4
    },
    {
      id: 'msg-2',
      sender: 'ai',
      type: 'warning',
      text: `Anomaly Guard: Detected sub-threshold signal-to-noise ratio in quadrant 3 (Lenslet [5,2]). Fried parameter r₀ has dropped to ${metrics.friedParameter.toFixed(1)} cm. Centroid detection confidence is currently at 94.8%.`,
      timestamp: '1 min ago',
      confidence: 94.8
    }
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendQuery = (customPrompt?: string) => {
    const queryText = customPrompt || inputQuery;
    if (!queryText.trim()) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!customPrompt) setInputQuery('');
    setIsTyping(true);

    // Simulate AI synthesis
    setTimeout(() => {
      let aiResponseText = "";
      let resType: ChatMessage['type'] = 'explanation';
      let conf = 97.2;

      const lower = queryText.toLowerCase();

      if (lower.includes('explain') || lower.includes('step') || lower.includes('processing')) {
        aiResponseText = "Current Processing Step [Stage 3: Sub-Pixel Centroid Extraction]: The pipeline is executing a Weighted Center-of-Gravity (WCoG) algorithm over 8x8 lenslet sub-apertures. Background subtraction threshold is set to 3σ above dark pedestal to eliminate read noise bias.";
        resType = 'explanation';
        conf = 98.9;
      } else if (lower.includes('preprocess') || lower.includes('algorithm')) {
        aiResponseText = "Preprocessing Suggestion: Based on current atmospheric turbulence (r₀ = 14.8 cm), I strongly recommend switching from standard Gaussian filtering to Non-Local Means (NL-Means) spatial denoising with kernel radius 4px. This preserves sharp lenslet spot boundaries while attenuating Poisson photon noise.";
        resType = 'recommendation';
        conf = 96.5;
      } else if (lower.includes('noise') || lower.includes('removal')) {
        aiResponseText = "Noise Removal Recommendation: Apply Contrast-Limited Adaptive Histogram Equalization (CLAHE) paired with a 3x3 Median filter. This eliminates dead pixels and dark current spikes without introducing phase wrapping artifacts.";
        resType = 'recommendation';
        conf = 95.8;
      } else if (lower.includes('quality') || lower.includes('predict')) {
        aiResponseText = `Image Quality Prediction: Estimated Strehl Ratio is 84.6% after closed-loop AO compensation. Uncompensated wavefront RMS error is estimated at 0.48 λ. Overall image stability is classified as EXCELLENT for high-resolution astronomical imaging.`;
        resType = 'explanation';
        conf = 99.1;
      } else if (lower.includes('failed') || lower.includes('centroid') || lower.includes('detect')) {
        aiResponseText = "Failed Centroid Detection Analysis: Lenslet [2,8] and [7,1] experienced momentary focal spot bifurcation due to localized atmospheric scintillation. The fallback nearest-neighbor interpolation successfully reconstructed the missing slope vectors.";
        resType = 'warning';
        conf = 93.4;
      } else if (lower.includes('reconstruct') || lower.includes('method')) {
        aiResponseText = "Wavefront Reconstruction Suggestion: I recommend utilizing Modal Zernike Reconstruction (first 36 Noll polynomials) rather than Zonal Fourier integration. This allows direct suppression of tip/tilt jitter and isolate higher-order spherical aberration.";
        resType = 'recommendation';
        conf = 98.2;
      } else if (lower.includes('error') || lower.includes('highlight')) {
        aiResponseText = "Active Error Highlight: 1 minor sync jitter event (0.2ms delay) detected on CUDA Stream 1 during frame fetch. Zero optical buffer overflows recorded. Hardware health nominal.";
        resType = 'warning';
        conf = 99.8;
      } else {
        aiResponseText = "I have analyzed your request against the live Shack-Hartmann telemetry. The wavefront control loop is maintaining optimal phase conjugation. You can click any quick-query prompt below for deep optical diagnostics.";
        resType = 'optimization';
        conf = 96.0;
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiResponseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: resType,
        confidence: conf
      };

      setIsTyping(false);
      setMessages(prev => [...prev, aiMsg]);
    }, 850);
  };

  const handleApplyAction = () => {
    setAppliedRecommendations(true);
    onApplyAutoOptimization();
    handleSendQuery("Applied AI auto-optimization profile.");
  };

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300 max-w-7xl mx-auto">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#162a3b] to-[#121524] border border-[#00cbe6]/30 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-[0_0_35px_rgba(0,203,230,0.12)]">
        <div className="space-y-2 max-w-3xl">
          <div className="flex items-center gap-2 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-widest">
            <Bot className="w-4 h-4 animate-bounce" /> Wavefront Neural Copilot
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Real-Time Optical AI Advisor
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Continuous AI supervision of optical processing steps, adaptive noise mitigation, centroid failure detection, and automated wavefront quality prediction.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="px-4 py-2.5 bg-[#080b10] rounded-xl border border-[#4edea3]/40 flex items-center gap-2.5 font-mono text-xs text-[#4edea3] shadow-md">
            <span className="w-2 h-2 rounded-full bg-[#4edea3] animate-ping" />
            <span>AI ENGINE: <strong>ONLINE</strong></span>
          </div>
        </div>
      </div>

      {/* Top Diagnostics KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Processing Step</span>
            <p className="text-sm font-extrabold text-white">Centroid Localizer</p>
            <p className="text-[11px] text-[#00cbe6] font-mono">Stage 3 of 5 (Active)</p>
          </div>
          <div className="p-3 rounded-xl bg-[#00cbe6]/10 text-[#00cbe6] border border-[#00cbe6]/20"><Cpu className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Predicted Quality</span>
            <p className="text-sm font-extrabold text-white">84.6% Strehl</p>
            <p className="text-[11px] text-[#4edea3] font-mono">Class: Excellent</p>
          </div>
          <div className="p-3 rounded-xl bg-[#4edea3]/10 text-[#4edea3] border border-[#4edea3]/20"><Sparkles className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">AI Confidence Score</span>
            <p className="text-sm font-extrabold text-white">98.4% Nominal</p>
            <p className="text-[11px] text-[#8083ff] font-mono">ResNet-50 Vision Core</p>
          </div>
          <div className="p-3 rounded-xl bg-[#8083ff]/10 text-[#8083ff] border border-[#8083ff]/20"><ShieldCheck className="w-5 h-5"/></div>
        </div>

        <div className="bg-[#161b22]/90 border border-[#464554]/30 p-5 rounded-2xl shadow-lg flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-[#908fa0] uppercase">Centroid Fail Guard</span>
            <p className="text-sm font-extrabold text-white">0 Fatal Drops</p>
            <p className="text-[11px] text-[#ffb4ab] font-mono">2 Outliers Auto-Fixed</p>
          </div>
          <div className="p-3 rounded-xl bg-[#ffb4ab]/10 text-[#ffb4ab] border border-[#ffb4ab]/20"><Target className="w-5 h-5"/></div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Quick Prompts & Auto Optimization Advisor (col-5) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Quick Capability Triggers */}
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-[#ffc857]" /> Neural Copilot Queries
            </h3>
            <p className="text-xs text-[#908fa0]">
              Select an optical engineering task to trigger instant neural inference and pipeline explanations.
            </p>

            <div className="grid grid-cols-1 gap-2.5 pt-1">
              {[
                { prompt: "Explain current processing step in detail", desc: "Break down Stage 3 centroid extraction math", icon: FileCode2, color: "#00cbe6" },
                { prompt: "Suggest best preprocessing algorithm for r₀", desc: "Optimize spatial kernels for atmospheric seeing", icon: Wand2, color: "#8083ff" },
                { prompt: "Recommend noise removal technique for dark spikes", desc: "CLAHE vs Median filter comparison", icon: ShieldCheck, color: "#4edea3" },
                { prompt: "Predict overall image quality and Strehl ratio", desc: "Estimate residual wavefront phase variance", icon: Sparkles, color: "#ffc857" },
                { prompt: "Detect any failed centroid detection events", desc: "Audit 64 lenslet focal spot intensities", icon: AlertTriangle, color: "#ffb4ab" },
                { prompt: "Suggest best wavefront reconstruction method", desc: "Modal Zernikes vs Zonal integration", icon: Layers, color: "#5de6ff" },
              ].map((item, i) => (
                <button
                  key={i}
                  onClick={() => handleSendQuery(item.prompt)}
                  className="p-3.5 rounded-xl bg-[#10131a] hover:bg-[#1f232d] border border-[#464554]/30 hover:border-[#00cbe6]/50 transition-all text-left flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-[#1d2026] text-white shrink-0 group-hover:scale-110 transition-transform">
                      <item.icon className="w-4 h-4" style={{ color: item.color }} />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-white group-hover:text-[#00cbe6] transition-colors">{item.prompt}</p>
                      <p className="text-[11px] text-[#908fa0] mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#464554] group-hover:text-white group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>
          </div>

          {/* Auto Optimization Card */}
          <div className="bg-gradient-to-br from-[#1c2235] to-[#121623] border border-[#8083ff]/40 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-full bg-[#8083ff]/20 text-[#c0c1ff] font-mono text-[10px] font-extrabold uppercase tracking-wider">
                AI Auto-Optimizer
              </span>
              <span className="text-[11px] font-mono text-[#4edea3] font-bold">99.1% Gain</span>
            </div>

            <h4 className="text-base font-extrabold text-white">
              Recommended Pipeline Profile
            </h4>
            <p className="text-xs text-[#c7c4d7] leading-relaxed">
              Based on live telemetry, the AI advisor suggests enabling <strong>NL-Means Denoising</strong>, updating centroid threshold to <strong>3.2σ</strong>, and boosting <strong>CLAHE contrast</strong>.
            </p>

            <button
              onClick={handleApplyAction}
              disabled={appliedRecommendations}
              className={`w-full py-3.5 rounded-xl font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg ${
                appliedRecommendations
                  ? 'bg-[#1d2026] text-[#4edea3] border border-[#4edea3]/40 cursor-default'
                  : 'bg-gradient-to-r from-[#00cbe6] via-[#8083ff] to-[#494bd6] hover:brightness-110 text-white active:scale-95'
              }`}
            >
              {appliedRecommendations ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-[#4edea3]" /> Optimized Profile Applied
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" /> Apply Auto-Optimization Suggestions
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Live Neural Copilot Chat Stream (col-7) */}
        <div className="lg:col-span-7 flex flex-col">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-lg flex flex-col flex-1 min-h-[580px] h-full">
            {/* Chat Window Header */}
            <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-[#00cbe6]/10 text-[#00cbe6] border border-[#00cbe6]/30">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold text-white uppercase tracking-wider">Neural Copilot Conversation Stream</h4>
                  <p className="text-[10px] font-mono text-[#908fa0]">Optical Vision LLM Grounded in CCD Stream</p>
                </div>
              </div>

              <button
                onClick={() => setMessages([{ id: 'reset', sender: 'ai', text: "Chat history cleared. Listening for new optical engineering prompts.", timestamp: 'Just now', confidence: 99.9 }])}
                className="text-xs text-[#908fa0] hover:text-white flex items-center gap-1 px-2.5 py-1 rounded bg-[#10131a] border border-[#464554]/30"
              >
                <RefreshCw className="w-3 h-3" /> Clear
              </button>
            </div>

            {/* Messages Scroll Area */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4 max-h-[440px] bg-[#0d1017]">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-xl ${
                    msg.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1 px-1">
                    <span className="text-[10px] font-bold uppercase text-[#908fa0]">
                      {msg.sender === 'user' ? 'Optical Engineer' : 'AI Copilot Core'}
                    </span>
                    <span className="text-[9px] font-mono text-[#464554]">• {msg.timestamp}</span>
                    {msg.confidence && (
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#00cbe6]/10 text-[#00cbe6] border border-[#00cbe6]/20 font-bold">
                        {msg.confidence}% Conf
                      </span>
                    )}
                  </div>

                  <div
                    className={`p-4 rounded-2xl text-xs leading-relaxed shadow-md ${
                      msg.sender === 'user'
                        ? 'bg-gradient-to-r from-[#00cbe6] to-[#494bd6] text-white rounded-br-none font-medium'
                        : msg.type === 'warning'
                          ? 'bg-[#2b171c] border border-[#ffb4ab]/40 text-[#ffe5e0] rounded-bl-none'
                          : msg.type === 'recommendation'
                            ? 'bg-[#162a26] border border-[#4edea3]/40 text-[#e0fff2] rounded-bl-none'
                            : 'bg-[#1d2026] border border-[#464554]/40 text-[#c7c4d7] rounded-bl-none'
                    }`}
                  >
                    {msg.type === 'warning' && (
                      <div className="flex items-center gap-1.5 text-[#ffb4ab] font-bold mb-1.5 pb-1 border-b border-[#ffb4ab]/20">
                        <AlertTriangle className="w-3.5 h-3.5" /> Centroid &amp; Wavefront Guard Alert
                      </div>
                    )}
                    {msg.type === 'recommendation' && (
                      <div className="flex items-center gap-1.5 text-[#4edea3] font-bold mb-1.5 pb-1 border-b border-[#4edea3]/20">
                        <CheckCircle2 className="w-3.5 h-3.5" /> AI Pipeline Recommendation
                      </div>
                    )}
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center gap-2 text-xs font-mono text-[#00cbe6] p-3 rounded-2xl bg-[#1d2026]/60 w-36 border border-[#00cbe6]/20 animate-pulse">
                  <Bot className="w-4 h-4 animate-spin" />
                  <span>Synthesizing...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Input Bar */}
            <div className="p-4 bg-[#161b22] border-t border-[#464554]/30">
              <form
                onSubmit={(e) => { e.preventDefault(); handleSendQuery(); }}
                className="flex items-center gap-2 bg-[#080b10] p-1.5 rounded-xl border border-[#464554]/50 focus-within:border-[#00cbe6] transition-colors shadow-inner"
              >
                <input
                  type="text"
                  value={inputQuery}
                  onChange={(e) => setInputQuery(e.target.value)}
                  placeholder="Ask AI Copilot (e.g. 'Predict Strehl ratio', 'Suggest preprocessing')..."
                  className="flex-1 bg-transparent text-xs text-white placeholder-[#908fa0] px-3 py-2 outline-none font-sans"
                />
                <button
                  type="submit"
                  disabled={!inputQuery.trim() || isTyping}
                  className="p-2.5 rounded-lg bg-[#00cbe6] hover:bg-[#5de6ff] text-[#080b10] font-bold transition-all disabled:opacity-30 active:scale-95"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
