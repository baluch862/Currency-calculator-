import React, { useEffect, useRef, useState } from 'react';
import { Wind, Activity, Eye, Sliders, Play, Pause, RotateCcw, AlertTriangle, Layers, Zap, Info } from 'lucide-react';
import { TurbulenceParams } from '../../types';

interface TurbulencePanelProps {
  params: TurbulenceParams;
  onChangeParams: (params: TurbulenceParams) => void;
  onResetToNominal: () => void;
}

export const TurbulencePanel: React.FC<TurbulencePanelProps> = ({
  params,
  onChangeParams,
  onResetToNominal
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [history, setHistory] = useState<number[]>(() => Array(40).fill(0.08));

  // Derived optical formulas (assuming wavelength λ = 500 nm)
  const wavelengthCm = 50e-7; // 500 nm in cm
  const friedCm = params.friedParameterCm;
  const friedM = friedCm / 100;
  const windM = params.windSpeedMs;

  // Greenwood frequency f_G = 0.427 * (v / r0)
  const greenwoodHz = friedM > 0 ? (0.427 * windM) / friedM : 0;

  // Atmospheric coherence time tau_0 = 0.314 * (r0 / v) in seconds -> ms
  const coherenceTimeMs = windM > 0 ? ((0.314 * friedM) / windM) * 1000 : 0;

  // Isoplanatic angle theta_0 approx 0.314 * r0 / h (radians) -> arcsec
  const altitudeM = Math.max(100, params.layerAltitudeKm * 1000);
  const isoplanaticArcsec = friedM > 0 ? ((0.314 * friedM) / altitudeM) * 206265 : 0;

  // Rytov variance approx
  const rytovVariance = 0.5 * Math.pow(params.seeingArcsec, 1.2) * (params.layerAltitudeKm || 0.5);

  // Handle Seeing slider change & auto-link Fried parameter
  const handleSeeingChange = (seeing: number) => {
    // r0 (cm) ≈ 0.98 * λ (cm) / (seeing in radians)
    // seeing in radians = seeing_arcsec / 206265
    const seeingRad = Math.max(0.05, seeing) / 206265;
    const calcFriedCm = Number(((0.98 * wavelengthCm) / seeingRad).toFixed(1));
    
    onChangeParams({
      ...params,
      seeingArcsec: seeing,
      friedParameterCm: Math.min(45, Math.max(2, calcFriedCm))
    });
  };

  // Handle Fried slider change & auto-link Seeing
  const handleFriedChange = (r0Cm: number) => {
    const r0M = r0Cm / 100;
    const seeingRad = (0.98 * 500e-9) / r0M;
    const calcSeeingArcsec = Number((seeingRad * 206265).toFixed(2));

    onChangeParams({
      ...params,
      friedParameterCm: r0Cm,
      seeingArcsec: Math.min(4.0, Math.max(0.2, calcSeeingArcsec))
    });
  };

  // Presets
  const applyPreset = (preset: 'mauna_kea' | 'hanle' | 'sea_level') => {
    if (preset === 'mauna_kea') {
      onChangeParams({
        seeingArcsec: 0.55,
        friedParameterCm: 18.4,
        windSpeedMs: 8.5,
        outerScaleM: 30.0,
        layerAltitudeKm: 4.2,
        model: 'von_Karman',
        isAnimated: true
      });
    } else if (preset === 'hanle') {
      onChangeParams({
        seeingArcsec: 0.75,
        friedParameterCm: 13.5,
        windSpeedMs: 14.0,
        outerScaleM: 25.0,
        layerAltitudeKm: 4.5,
        model: 'von_Karman',
        isAnimated: true
      });
    } else {
      onChangeParams({
        seeingArcsec: 2.20,
        friedParameterCm: 4.6,
        windSpeedMs: 28.0,
        outerScaleM: 15.0,
        layerAltitudeKm: 0.5,
        model: 'Kolmogorov',
        isAnimated: true
      });
    }
  };

  // Render animated Phase Screen canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let animId: number;
    let offsetX = 0;
    let time = 0;

    const render = () => {
      if (params.isAnimated) {
        time += 0.04;
        offsetX += params.windSpeedMs * 0.15;
      }
      const w = canvas.width;
      const h = canvas.height;

      const imgData = ctx.createImageData(w, h);
      const data = imgData.data;

      // Turbulence intensity scaling inversely proportional to r0
      const turbStrength = Math.min(3.5, 20 / Math.max(2, params.friedParameterCm));
      const freq = 0.02 * (30 / Math.max(5, params.outerScaleM));

      for (let x = 0; x < w; x++) {
        for (let y = 0; y < h; y++) {
          const sx = (x + offsetX) * freq;
          const sy = y * freq;

          // Multi-octave speckle noise simulation
          const n1 = Math.sin(sx * 2 + time) * Math.cos(sy * 2 - time * 0.5);
          const n2 = Math.sin(sx * 4 - sy * 3 + time * 1.5) * 0.5;
          const n3 = Math.cos(sx * 8 + sy * 6 - time * 2) * 0.25;
          
          const val = (n1 + n2 + n3) * turbStrength;
          const norm = (val + 2.5) / 5.0; // clamp ~ 0 to 1

          const idx = (y * w + x) * 4;

          // Color map: Deep space black -> Indigo -> Cyan -> White peaks
          if (norm < 0.35) {
            data[idx] = Math.floor(12 + norm * 80);
            data[idx + 1] = Math.floor(18 + norm * 90);
            data[idx + 2] = Math.floor(35 + norm * 180);
          } else if (norm < 0.7) {
            const sub = (norm - 0.35) / 0.35;
            data[idx] = Math.floor(40 + sub * 20);
            data[idx + 1] = Math.floor(49 + sub * 154);
            data[idx + 2] = Math.floor(161 + sub * 69);
          } else {
            const sub = (norm - 0.7) / 0.3;
            data[idx] = Math.floor(60 + sub * 195);
            data[idx + 1] = Math.floor(203 + sub * 52);
            data[idx + 2] = Math.floor(230 + sub * 25);
          }
          data[idx + 3] = 255;
        }
      }

      ctx.putImageData(imgData, 0, 0);

      // Draw wavefront slope vector arrows overlaid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.lineWidth = 1;
      const step = 48;
      for (let gx = step / 2; gx < w; gx += step) {
        for (let gy = step / 2; gy < h; gy += step) {
          const angle = Math.sin((gx + offsetX) * 0.05 + time) * Math.PI;
          const len = 8 * turbStrength;
          ctx.beginPath();
          ctx.moveTo(gx, gy);
          ctx.lineTo(gx + Math.cos(angle) * len, gy + Math.sin(angle) * len);
          ctx.stroke();
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [params]);

  // Update history chart data
  useEffect(() => {
    if (!params.isAnimated) return;
    const interval = setInterval(() => {
      const baseRms = 0.02 * params.seeingArcsec;
      const jitter = (Math.random() - 0.5) * 0.015 * params.seeingArcsec;
      setHistory((prev) => [...prev.slice(1), Math.max(0.01, baseRms + jitter)]);
    }, 150);
    return () => clearInterval(interval);
  }, [params]);

  return (
    <div className="space-y-6 select-none animate-in fade-in duration-300">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#1d2026] via-[#1f2430] to-[#121824] border border-[#464554]/40 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2 text-[#00cbe6] font-mono text-xs font-bold uppercase tracking-widest">
            <Wind className="w-4 h-4 animate-pulse" /> Atmospheric Aberration Simulator
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Turbulence Profile &amp; Fried r₀ Engine
          </h1>
          <p className="text-sm text-[#c7c4d7] leading-relaxed">
            Model real-time optical phase screens and atmospheric coherence decay across ISRO ground tracking stations. Adjust astronomical seeing and jet stream shear to stress-test Shack-Hartmann closed-loop actuators.
          </p>
        </div>

        {/* Quick Presets Rail */}
        <div className="flex flex-wrap md:flex-col gap-2 shrink-0 bg-[#10131a]/80 p-2.5 rounded-xl border border-[#464554]/30">
          <span className="text-[10px] font-bold uppercase text-[#908fa0] px-2">Observatory Presets</span>
          <button
            onClick={() => applyPreset('mauna_kea')}
            className="px-3 py-1.5 rounded-lg bg-[#272a31] hover:bg-[#494bd6] text-[#e1e2eb] hover:text-white text-xs font-semibold text-left transition-colors flex items-center justify-between gap-3"
          >
            <span>Mauna Kea (Hawaii)</span>
            <span className="text-[10px] font-mono text-[#4edea3]">0.55&quot;</span>
          </button>
          <button
            onClick={() => applyPreset('hanle')}
            className="px-3 py-1.5 rounded-lg bg-[#272a31] hover:bg-[#00cbe6] hover:text-black text-[#e1e2eb] text-xs font-semibold text-left transition-colors flex items-center justify-between gap-3"
          >
            <span>IAO Hanle (Ladakh)</span>
            <span className="text-[10px] font-mono text-[#5de6ff]">0.75&quot;</span>
          </button>
          <button
            onClick={() => applyPreset('sea_level')}
            className="px-3 py-1.5 rounded-lg bg-[#272a31] hover:bg-[#ffb4ab] hover:text-[#690005] text-[#e1e2eb] text-xs font-semibold text-left transition-colors flex items-center justify-between gap-3"
          >
            <span>Sea Level Tracking</span>
            <span className="text-[10px] font-mono text-[#ffb4ab]">2.20&quot;</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Controls Panel (col-5) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl p-6 shadow-lg space-y-6">
            <div className="flex items-center justify-between border-b border-[#464554]/30 pb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb] flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#c0c1ff]" /> Physical Parameters
              </h3>
              <button
                onClick={onResetToNominal}
                title="Reset to nominal standard atmosphere"
                className="p-1.5 text-[#908fa0] hover:text-[#5de6ff] hover:bg-[#272a31] rounded transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Sliders Stack */}
            <div className="space-y-5">
              {/* Seeing Parameter */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#c7c4d7]">Astronomical Seeing (ε FWHM)</span>
                  <span className="font-mono font-bold text-[#ffb4ab] bg-[#ffb4ab]/10 px-2 py-0.5 rounded border border-[#ffb4ab]/30">
                    {params.seeingArcsec.toFixed(2)} arcsec
                  </span>
                </div>
                <input
                  type="range"
                  min="0.30"
                  max="3.00"
                  step="0.05"
                  value={params.seeingArcsec}
                  onChange={(e) => handleSeeingChange(Number(e.target.value))}
                  className="w-full accent-[#ffb4ab] cursor-pointer h-1.5 bg-[#272a31] rounded-lg"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#908fa0]">
                  <span>0.3&quot; (Space-like)</span>
                  <span>1.0&quot; (Average)</span>
                  <span>3.0&quot; (Severe)</span>
                </div>
              </div>

              {/* Fried Parameter r0 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#c7c4d7]">Fried Parameter (r₀ @ 500nm)</span>
                  <span className="font-mono font-bold text-[#c0c1ff] bg-[#c0c1ff]/10 px-2 py-0.5 rounded border border-[#c0c1ff]/30">
                    {params.friedParameterCm.toFixed(1)} cm
                  </span>
                </div>
                <input
                  type="range"
                  min="2.0"
                  max="40.0"
                  step="0.5"
                  value={params.friedParameterCm}
                  onChange={(e) => handleFriedChange(Number(e.target.value))}
                  className="w-full accent-[#c0c1ff] cursor-pointer h-1.5 bg-[#272a31] rounded-lg"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#908fa0]">
                  <span>2 cm (High Jitter)</span>
                  <span>15 cm (Nominal AO)</span>
                  <span>40 cm (Coherent)</span>
                </div>
              </div>

              {/* Wind Speed */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#c7c4d7]">Effective Wind Shear Velocity (v)</span>
                  <span className="font-mono font-bold text-[#00cbe6] bg-[#00cbe6]/10 px-2 py-0.5 rounded border border-[#00cbe6]/30">
                    {params.windSpeedMs.toFixed(1)} m/s
                  </span>
                </div>
                <input
                  type="range"
                  min="2.0"
                  max="45.0"
                  step="0.5"
                  value={params.windSpeedMs}
                  onChange={(e) => onChangeParams({ ...params, windSpeedMs: Number(e.target.value) })}
                  className="w-full accent-[#00cbe6] cursor-pointer h-1.5 bg-[#272a31] rounded-lg"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#908fa0]">
                  <span>2 m/s (Calm)</span>
                  <span>20 m/s (Moderate)</span>
                  <span>45 m/s (Jet Stream)</span>
                </div>
              </div>

              {/* Outer Scale L0 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-[#c7c4d7]">Outer Scale (L₀)</span>
                  <span className="font-mono font-bold text-[#4edea3] bg-[#4edea3]/10 px-2 py-0.5 rounded border border-[#4edea3]/30">
                    {params.outerScaleM.toFixed(0)} m
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  step="5"
                  value={params.outerScaleM}
                  onChange={(e) => onChangeParams({ ...params, outerScaleM: Number(e.target.value) })}
                  className="w-full accent-[#4edea3] cursor-pointer h-1.5 bg-[#272a31] rounded-lg"
                />
              </div>

              {/* Turbulence Model Selector */}
              <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                <span className="text-xs font-semibold text-[#c7c4d7]">Phase Power Spectrum Model</span>
                <div className="grid grid-cols-3 gap-2">
                  {(['von_Karman', 'Kolmogorov', 'Greenwood'] as const).map((mdl) => (
                    <button
                      key={mdl}
                      onClick={() => onChangeParams({ ...params, model: mdl })}
                      className={`py-2 rounded-lg text-[11px] font-bold transition-all border ${
                        params.model === mdl
                          ? 'bg-[#494bd6] text-white border-[#8083ff] shadow-[0_0_12px_rgba(73,75,214,0.5)]'
                          : 'bg-[#272a31]/60 text-[#908fa0] border-[#464554]/30 hover:text-white hover:bg-[#32353c]'
                      }`}
                    >
                      {mdl.replace('_', ' ')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Altitude Layer Switch */}
              <div className="space-y-2 pt-2 border-t border-[#464554]/20">
                <span className="text-xs font-semibold text-[#c7c4d7]">Dominant Cₙ² Altitude Layer</span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Ground (0.5km)', val: 0.5 },
                    { label: 'Boundary (4.2km)', val: 4.2 },
                    { label: 'Tropopause (12km)', val: 12.0 }
                  ].map((alt) => (
                    <button
                      key={alt.val}
                      onClick={() => onChangeParams({ ...params, layerAltitudeKm: alt.val })}
                      className={`py-1.5 rounded-lg text-[11px] font-medium transition-all border truncate px-2 ${
                        params.layerAltitudeKm === alt.val
                          ? 'bg-[#00cbe6]/20 text-[#5de6ff] border-[#00cbe6]'
                          : 'bg-[#272a31]/40 text-[#908fa0] border-[#464554]/30 hover:text-white'
                      }`}
                    >
                      {alt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Simulation Loop State Card */}
          <div className="bg-[#10131a] rounded-2xl p-4 border border-[#464554]/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${params.isAnimated ? 'bg-[#4edea3] animate-ping' : 'bg-[#ffb4ab]'}`} />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-white">
                  Speckle Generator
                </p>
                <p className="text-[10px] text-[#908fa0]">
                  {params.isAnimated ? 'Synthesizing phase screens @ 60 FPS' : 'Phase frozen for inspection'}
                </p>
              </div>
            </div>

            <button
              onClick={() => onChangeParams({ ...params, isAnimated: !params.isAnimated })}
              className={`px-4 py-2 rounded-lg font-bold text-xs uppercase transition-all flex items-center gap-1.5 ${
                params.isAnimated
                  ? 'bg-[#32353c] text-[#ffb4ab] hover:bg-[#464554]'
                  : 'bg-[#00cbe6] text-black hover:brightness-110'
              }`}
            >
              {params.isAnimated ? (
                <><Pause className="w-3.5 h-3.5" /> Pause</>
              ) : (
                <><Play className="w-3.5 h-3.5 fill-current" /> Resume</>
              )}
            </button>
          </div>
        </div>

        {/* Right Canvases & Telemetry Bento (col-7) */}
        <div className="lg:col-span-7 space-y-6 flex flex-col">
          {/* Phase Screen Canvas */}
          <div className="bg-[#161b22]/90 border border-[#464554]/30 rounded-2xl overflow-hidden shadow-lg flex flex-col">
            <div className="p-4 bg-[#272a31] border-b border-[#464554]/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-[#00cbe6]" />
                <span className="text-xs font-bold uppercase tracking-widest text-[#e1e2eb]">
                  Simulated Pupil Plane Phase Screen (Φ)
                </span>
              </div>
              <span className="text-[10px] font-mono text-[#c0c1ff] bg-[#494bd6]/30 px-2 py-0.5 rounded border border-[#8083ff]/40">
                {params.model} Spectrum
              </span>
            </div>

            <div className="relative bg-[#080b10] p-6 flex flex-col items-center justify-center min-h-[320px]">
              <canvas
                ref={canvasRef}
                width={560}
                height={300}
                className="w-full max-w-[560px] h-[300px] object-cover rounded-xl border border-[#464554]/50 shadow-[0_0_50px_rgba(0,203,230,0.12)]"
              />

              {/* Overlay telemetry legend inside canvas frame */}
              <div className="absolute top-9 left-9 bg-black/75 backdrop-blur-md p-3 rounded-lg border border-white/10 font-mono text-[11px] space-y-1 pointer-events-none">
                <p className="text-[#908fa0]">GRID: <strong className="text-white">512x512 FFT</strong></p>
                <p className="text-[#908fa0]">PITCH: <strong className="text-[#00cbe6]">150 μm/sub</strong></p>
                <p className="text-[#908fa0]">RMS DISTORTION: <strong className="text-[#ffb4ab]">{(0.12 * params.seeingArcsec).toFixed(3)} λ</strong></p>
              </div>
            </div>
          </div>

          {/* Derived Telemetry Cards 4-grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-[#161b22]/90 p-4 rounded-xl border border-[#464554]/30 border-t-4 border-t-[#00cbe6]">
              <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">Greenwood Freq (f_G)</p>
              <p className="text-2xl font-mono font-extrabold text-[#5de6ff] mt-1">
                {greenwoodHz.toFixed(1)} <span className="text-xs font-normal text-[#c7c4d7]">Hz</span>
              </p>
              <p className="text-[9px] text-[#908fa0] mt-1">Min AO correction rate</p>
            </div>

            <div className="bg-[#161b22]/90 p-4 rounded-xl border border-[#464554]/30 border-t-4 border-t-[#c0c1ff]">
              <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">Coherence Time (τ₀)</p>
              <p className="text-2xl font-mono font-extrabold text-[#c0c1ff] mt-1">
                {coherenceTimeMs.toFixed(2)} <span className="text-xs font-normal text-[#c7c4d7]">ms</span>
              </p>
              <p className="text-[9px] text-[#908fa0] mt-1">Speckle lifetime limit</p>
            </div>

            <div className="bg-[#161b22]/90 p-4 rounded-xl border border-[#464554]/30 border-t-4 border-t-[#4edea3]">
              <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">Isoplanatic Angle (θ₀)</p>
              <p className="text-2xl font-mono font-extrabold text-[#4edea3] mt-1">
                {isoplanaticArcsec.toFixed(2)} <span className="text-xs font-normal text-[#c7c4d7]">&quot;</span>
              </p>
              <p className="text-[9px] text-[#908fa0] mt-1">Guide star FOV radius</p>
            </div>

            <div className="bg-[#161b22]/90 p-4 rounded-xl border border-[#464554]/30 border-t-4 border-t-[#ffb4ab]">
              <p className="text-[10px] font-bold text-[#908fa0] uppercase tracking-wider">Rytov Variance (σ_R²)</p>
              <p className="text-2xl font-mono font-extrabold text-[#ffb4ab] mt-1">
                {rytovVariance.toFixed(3)}
              </p>
              <p className="text-[9px] text-[#908fa0] mt-1">Scintillation index</p>
            </div>
          </div>

          {/* Live Wavefront Variance Time-Series Graph */}
          <div className="bg-[#161b22]/90 p-5 rounded-2xl border border-[#464554]/30 space-y-3 flex-1 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#4edea3]" />
                <span className="text-xs font-bold uppercase tracking-wider text-[#e1e2eb]">
                  Real-time Residual Wavefront Variance (λ RMS)
                </span>
              </div>
              <span className="text-[10px] font-mono text-[#908fa0]">Time Window: 6.0s</span>
            </div>

            {/* Simulated Line Chart SVG */}
            <div className="h-28 w-full bg-[#10131a] rounded-xl border border-[#464554]/30 p-3 flex items-end gap-1 overflow-hidden relative">
              {history.map((val, i) => {
                const heightPct = Math.min(95, Math.max(10, val * 320));
                const isPeak = val > 0.18;
                return (
                  <div
                    key={i}
                    className="flex-1 rounded-t-sm transition-all duration-150 relative group"
                    style={{
                      height: `${heightPct}%`,
                      backgroundColor: isPeak ? '#ffb4ab' : i === history.length - 1 ? '#00cbe6' : '#494bd6'
                    }}
                  >
                    <div className="opacity-0 group-hover:opacity-100 absolute -top-7 left-1/2 -translate-x-1/2 bg-black text-white font-mono text-[9px] px-1.5 py-0.5 rounded pointer-events-none z-10 shadow">
                      {val.toFixed(3)}λ
                    </div>
                  </div>
                );
              })}
              <div className="absolute top-2 right-3 font-mono text-xs font-bold text-[#00cbe6]">
                LIVE: {history[history.length - 1]?.toFixed(3)} λ
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-[#908fa0] pt-1">
              <span className="flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-[#5de6ff]" /> Target AO correction floor: &lt; 0.050 λ RMS
              </span>
              <span className="text-[#4edea3] font-mono font-bold">ACTUATOR SLEW: NOMINAL</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
