export type ModuleId = 
  | 'dashboard'
  | 'dataset'
  | 'processing'
  | 'enhancement'
  | 'spot_detection'
  | 'centroid'
  | 'sh_analysis'
  | 'reconstruction'
  | 'zernike'
  | 'turbulence'
  | 'actuators'
  | 'visualization'
  | 'ai_assistant'
  | 'export'
  | 'settings'
  | 'about';

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'READY' | 'INFO' | 'PROC' | 'WARN' | 'ERROR';
  message: string;
}

export interface MetricData {
  friedParameter: number; // cm
  coherenceTime: number; // ms
  centroidCount: number;
  fps: number;
  rmsError: number; // lambda
}

export interface FrameMetadata {
  resolution: string;
  bitDepth: string;
  exposure: string;
}

export interface TurbulenceParams {
  seeingArcsec: number;    // ε (arcsec) e.g., 0.8
  friedParameterCm: number; // r₀ (cm) e.g., 15.2
  windSpeedMs: number;     // v (m/s) e.g., 12.5
  outerScaleM: number;     // L₀ (m) e.g., 25.0
  layerAltitudeKm: number; // h (km) e.g., 10.0
  model: 'Kolmogorov' | 'von_Karman' | 'Greenwood';
  isAnimated: boolean;
}

export interface CalibrationParams {
  enableDarkSubtraction: boolean;
  masterDarkAdu: number;
  enableFlatField: boolean;
  flatFieldGain: number;
  enableBadPixelMap: boolean;
  hotPixelThreshold: number;
  filterKernel: 'None' | 'Gaussian_3x3' | 'Median_5x5' | 'Bilateral';
  ccdGain: number;
  readNoiseE: number;
}

export interface EnhancementParams {
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  gamma: number; // 0.1 to 3.0
  histEqualization: boolean;
  clahe: boolean;
  adaptiveHist: boolean;
  blurMode: 'None' | 'Gaussian' | 'Median' | 'Bilateral' | 'NL_Means';
  blurRadius: number;
  sharpen: boolean;
  edgeEnhance: boolean;
  edgeFilter: 'None' | 'Laplacian' | 'Sobel' | 'Canny';
  normalize: boolean;
  bgRemoval: boolean;
  noiseReduction: number; // 0 to 100
  deadPixelRemoval: boolean;
  morphology: 'None' | 'Opening' | 'Closing';
  zoom: number; // 0.5 to 4.0
  panX: number;
  panY: number;
  rotation: number;
  flipH: boolean;
  flipV: boolean;
  autoEnhance: boolean;
}

export interface ZernikeParams {
  maxTerms: number; // e.g. 36
  removeTipTilt: boolean;
  removeDefocus: boolean;
  wavefrontAmplitude: number; // scaling factor
  colormap: 'Cyan_Plasma' | 'Inferno' | 'Viridis' | 'Emerald_Wave';
  displayMode: '3D_Surface' | '2D_Interferogram' | 'Modal_Matrix';
  wireframe: boolean;
  rotationX: number; // 3D tilt
  rotationZ: number; // 3D azimuth
}

export interface ReconstructionParams {
  solver: 'Southwell_Zonal' | 'Hudgin_Zonal' | 'Fried_LeastSquares' | 'Modal_Zernike_64';
  colormap: 'Cyan_Plasma' | 'Inferno' | 'Viridis' | 'Emerald_Wave';
  wireframe: boolean;
  isAnimated: boolean;
  showActuators: boolean;
  amplitude: number; // 0.1 to 3.0 lambda
  spherical: number; // -1.0 to 1.0
  astigmatism: number; // -1.0 to 1.0
  turbulenceNoise: number; // 0 to 100
}



