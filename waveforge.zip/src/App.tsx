import React, { useEffect, useState } from 'react';
import { FrameMetadata, LogEntry, MetricData, ModuleId, TurbulenceParams, CalibrationParams, EnhancementParams, ZernikeParams } from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { Dashboard } from './components/Dashboard';
import { ModuleView } from './components/ModuleView';
import { TurbulencePanel } from './components/modules/TurbulencePanel';
import { ExportPanel } from './components/modules/ExportPanel';
import { CalibrationPanel } from './components/modules/CalibrationPanel';
import { EnhancementPanel } from './components/modules/EnhancementPanel';
import { ZernikePanel } from './components/modules/ZernikePanel';
import { AIAssistantPanel } from './components/modules/AIAssistantPanel';
import { ReconstructionViewer3D } from './components/modules/ReconstructionViewer3D';
import { ShackHartmannAnalysisModule } from './components/modules/ShackHartmannAnalysisModule';

export function App() {
  const [activeModule, setActiveModule] = useState<ModuleId>('dashboard');
  const [activeWorkspace, setActiveWorkspace] = useState<'workspace' | 'analysis' | 'hardware'>('workspace');
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [selectedFile, setSelectedFile] = useState<string>('frame_0001_calib.fits');
  const [progress, setProgress] = useState<number>(75);
  const [currentTimeUtc, setCurrentTimeUtc] = useState<string>('UTC 00:00:00');

  const [turbParams, setTurbParams] = useState<TurbulenceParams>({
    seeingArcsec: 0.85,
    friedParameterCm: 14.8,
    windSpeedMs: 12.5,
    outerScaleM: 25.0,
    layerAltitudeKm: 4.2,
    model: 'von_Karman',
    isAnimated: true
  });

  const [calibParams, setCalibParams] = useState<CalibrationParams>({
    enableDarkSubtraction: true,
    masterDarkAdu: 420,
    enableFlatField: true,
    flatFieldGain: 1.15,
    enableBadPixelMap: true,
    hotPixelThreshold: 92,
    filterKernel: 'Gaussian_3x3',
    ccdGain: 1.4,
    readNoiseE: 3.2
  });

  const [enhanceParams, setEnhanceParams] = useState<EnhancementParams>({
    brightness: 0,
    contrast: 0,
    gamma: 1.0,
    histEqualization: false,
    clahe: false,
    adaptiveHist: false,
    blurMode: 'None',
    blurRadius: 3,
    sharpen: false,
    edgeEnhance: false,
    edgeFilter: 'None',
    normalize: false,
    bgRemoval: false,
    noiseReduction: 0,
    deadPixelRemoval: false,
    morphology: 'None',
    zoom: 1.0,
    panX: 0,
    panY: 0,
    rotation: 0,
    flipH: false,
    flipV: false,
    autoEnhance: false
  });

  const [zernikeParams, setZernikeParams] = useState<ZernikeParams>({
    maxTerms: 36,
    removeTipTilt: false,
    removeDefocus: false,
    wavefrontAmplitude: 1.0,
    colormap: 'Cyan_Plasma',
    displayMode: '3D_Surface',
    wireframe: false,
    rotationX: 52,
    rotationZ: 35
  });

  const [metadata] = useState<FrameMetadata>({
    resolution: '2048 x 2048 px',
    bitDepth: '16-bit Unsigned',
    exposure: '1.24 ms'
  });

  const [metrics, setMetrics] = useState<MetricData>({
    friedParameter: 12.4,
    coherenceTime: 3.8,
    centroidCount: 1024,
    fps: 120.4,
    rmsError: 0.084
  });

  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', timestamp: '01:22:14', level: 'READY', message: 'WaveForge Scientific Core initialized.' },
    { id: '2', timestamp: '01:22:15', level: 'INFO', message: 'SH-WFS-74 lenslet array locked (pitch: 150μm).' },
    { id: '3', timestamp: '01:22:18', level: 'PROC', message: 'CUDA kernel CUDA_WFS_CENTROID_V3 compiled.' },
    { id: '4', timestamp: '01:22:24', level: 'INFO', message: 'Loaded calibration baseline FITS frame.' },
  ]);

  // Live UTC Clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const h = String(now.getUTCHours()).padStart(2, '0');
      const m = String(now.getUTCMinutes()).padStart(2, '0');
      const s = String(now.getUTCSeconds()).padStart(2, '0');
      setCurrentTimeUtc(`UTC ${h}:${m}:${s}`);
    };
    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  // Simulation loop for dynamic metrics & progress
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setMetrics((prev) => ({
        ...prev,
        friedParameter: Number((turbParams.friedParameterCm + (Math.random() - 0.5) * 0.2).toFixed(2)),
        coherenceTime: Number(((0.314 * (turbParams.friedParameterCm / 100) / Math.max(1, turbParams.windSpeedMs)) * 1000 + (Math.random() - 0.5) * 0.1).toFixed(2)),
        fps: Number((120.4 + (Math.random() - 0.5) * 2).toFixed(1)),
        rmsError: Number((0.02 * turbParams.seeingArcsec + (Math.random() - 0.5) * 0.005).toFixed(3))
      }));

      setProgress((prev) => (prev >= 99 ? 12 : prev + 0.5));

      // Occasional random log entry
      if (Math.random() > 0.96) {
        const now = new Date();
        const ts = now.toTimeString().slice(0, 8);
        const newLog: LogEntry = {
          id: String(Date.now()),
          timestamp: ts,
          level: Math.random() > 0.7 ? 'PROC' : 'INFO',
          message: `Calculated Zernike phase coefficients frame #${Math.floor(Math.random() * 9000 + 1000)}.`
        };
        setLogs((prevLogs) => [...prevLogs.slice(-20), newLog]);
      }
    }, 120);

    return () => clearInterval(interval);
  }, [isSimulating]);

  const handleToggleSim = () => {
    setIsSimulating(!isSimulating);
    const now = new Date();
    setLogs((prev) => [
      ...prev,
      {
        id: String(Date.now()),
        timestamp: now.toTimeString().slice(0, 8),
        level: isSimulating ? 'WARN' : 'READY',
        message: isSimulating ? 'Simulation paused by user.' : 'Resumed real-time acquisition loops.'
      }
    ]);
  };

  const handleReset = () => {
    setProgress(0);
    setTurbParams({
      seeingArcsec: 0.85,
      friedParameterCm: 14.8,
      windSpeedMs: 12.5,
      outerScaleM: 25.0,
      layerAltitudeKm: 4.2,
      model: 'von_Karman',
      isAnimated: true
    });
    setCalibParams({
      enableDarkSubtraction: true,
      masterDarkAdu: 420,
      enableFlatField: true,
      flatFieldGain: 1.15,
      enableBadPixelMap: true,
      hotPixelThreshold: 92,
      filterKernel: 'Gaussian_3x3',
      ccdGain: 1.4,
      readNoiseE: 3.2
    });
    setEnhanceParams({
      brightness: 0,
      contrast: 0,
      gamma: 1.0,
      histEqualization: false,
      clahe: false,
      adaptiveHist: false,
      blurMode: 'None',
      blurRadius: 3,
      sharpen: false,
      edgeEnhance: false,
      edgeFilter: 'None',
      normalize: false,
      bgRemoval: false,
      noiseReduction: 0,
      deadPixelRemoval: false,
      morphology: 'None',
      zoom: 1.0,
      panX: 0,
      panY: 0,
      rotation: 0,
      flipH: false,
      flipV: false,
      autoEnhance: false
    });
    setZernikeParams({
      maxTerms: 36,
      removeTipTilt: false,
      removeDefocus: false,
      wavefrontAmplitude: 1.0,
      colormap: 'Cyan_Plasma',
      displayMode: '3D_Surface',
      wireframe: false,
      rotationX: 52,
      rotationZ: 35
    });
    setMetrics({
      friedParameter: 14.8,
      coherenceTime: 3.7,
      centroidCount: 1024,
      fps: 120.4,
      rmsError: 0.017
    });
    setLogs((prev) => [
      ...prev,
      {
        id: String(Date.now()),
        timestamp: new Date().toTimeString().slice(0, 8),
        level: 'READY',
        message: 'Pipeline canvases and phase models reset to nominal.'
      }
    ]);
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  const handleUploadFiles = (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const names = Array.from(fileList).map((f) => f.name).join(', ');
    setSelectedFile(fileList[0].name);
    setLogs((prev) => [
      ...prev,
      {
        id: String(Date.now()),
        timestamp: new Date().toTimeString().slice(0, 8),
        level: 'INFO',
        message: `Ingested ${fileList.length} new SH-WFS frames: ${names}`
      }
    ]);
  };

  return (
    <div className="min-h-screen bg-[#0b0e14] text-[#e1e2eb] font-sans antialiased overflow-x-hidden selection:bg-[#494bd6] selection:text-white">
      {/* Fixed Top Bar */}
      <Header
        activeWorkspace={activeWorkspace}
        setActiveWorkspace={setActiveWorkspace}
        onOpenSettings={() => setActiveModule('settings')}
        isSimulating={isSimulating}
      />

      {/* Fixed Left Sidebar */}
      <Sidebar
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        isSimulating={isSimulating}
        onToggleSimulation={handleToggleSim}
        onResetPipeline={handleReset}
      />

      {/* Main Content Viewport */}
      <main className="pl-[280px] pt-16 pb-8 min-h-screen">
        <div className="p-6 md:p-8 max-w-[1600px] mx-auto">
          {activeModule === 'dashboard' ? (
            <Dashboard
              metadata={metadata}
              selectedFile={selectedFile}
              onSelectFile={setSelectedFile}
              onUploadFiles={handleUploadFiles}
              isSimulating={isSimulating}
              metrics={metrics}
              logs={logs}
              onClearLogs={handleClearLogs}
            />
          ) : activeModule === 'turbulence' ? (
            <TurbulencePanel
              params={turbParams}
              onChangeParams={setTurbParams}
              onResetToNominal={handleReset}
            />
          ) : activeModule === 'processing' ? (
            <CalibrationPanel
              params={calibParams}
              onChangeParams={setCalibParams}
              onResetCalibration={handleReset}
            />
          ) : activeModule === 'enhancement' ? (
            <EnhancementPanel
              params={enhanceParams}
              onChangeParams={setEnhanceParams}
              onResetToNominal={handleReset}
            />
          ) : activeModule === 'zernike' ? (
            <ZernikePanel
              params={zernikeParams}
              onChangeParams={setZernikeParams}
              onResetToNominal={handleReset}
            />
          ) : activeModule === 'ai_assistant' ? (
            <AIAssistantPanel
              metrics={metrics}
              onApplyAutoOptimization={() => {
                setEnhanceParams(prev => ({ ...prev, clahe: true, noiseReduction: 60, normalize: true }));
              }}
            />
          ) : activeModule === 'sh_analysis' || activeModule === 'spot_detection' || activeModule === 'centroid' ? (
            <ShackHartmannAnalysisModule metrics={metrics} />
          ) : activeModule === 'visualization' || activeModule === 'reconstruction' ? (
            <ReconstructionViewer3D
              metrics={metrics}
              onResetPipeline={handleReset}
            />
          ) : activeModule === 'export' ? (
            <ExportPanel
              metrics={metrics}
              logs={logs}
            />
          ) : (
            <ModuleView
              moduleId={activeModule}
              onTriggerSimulation={handleToggleSim}
              onOpenSettings={() => setActiveModule('settings')}
            />
          )}
        </div>
      </main>

      {/* Fixed Bottom Status Bar */}
      <Footer
        progress={progress}
        fps={metrics.fps}
        currentTimeUtc={currentTimeUtc}
      />
    </div>
  );
}

export default App;
