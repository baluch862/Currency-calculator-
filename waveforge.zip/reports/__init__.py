"""Reports Module Initialization"""
