"""
WaveForge - Shack-Hartmann Wavefront Sensor Analysis & Adaptive Optics
ISRO Bharatiya Antariksh Hackathon 2026 - Problem Statement 9

Application Core Module
Handles QApplication lifecycle, global dark theme styling, exception handling, and logging setup.
"""

import sys
import logging
from pathlib import Path
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont, QPalette, QColor, QIcon
from PySide6.QtCore import Qt

from utils.logger import setup_logging


class WaveForgeApp(QApplication):
    """
    Main Application class for WaveForge.
    Encapsulates Qt Application state, signals, and styling.
    """
    def __init__(self, argv):
        super().__init__(argv)
        self.setApplicationName("WaveForge")
        self.setApplicationVersion("2026.1.0-ALPHA")
        self.setOrganizationName("ISRO Hackathon Team")
        self.setOrganizationDomain("isro.gov.in")

        # Initialize logging subsystem
        self.logger = setup_logging()
        self.logger.info("Initializing WaveForge Scientific Application Core...")

        # Setup exception hook
        sys.excepthook = self.handle_exception

        # Apply Premium Industrial Dark Theme
        self.apply_industrial_dark_theme()
        self.setup_typography()

    def setup_typography(self):
        """Sets up high-legibility Inter and monospaced fonts."""
        font = QFont("Inter", 10)
        font.setStyleHint(QFont.SansSerif)
        self.setFont(font)

    def apply_industrial_dark_theme(self):
        """Applies the Stitch-designed Premium Industrial Dark palette and QSS."""
        palette = QPalette()
        
        # Base colors matching design system (#10131a, #0b0e14, #1d2026)
        base_dark = QColor("#0b0e14")
        surface_container = QColor("#161b22")
        surface_high = QColor("#272a31")
        text_primary = QColor("#e1e2eb")
        text_variant = QColor("#c7c4d7")
        accent_indigo = QColor("#c0c1ff")
        accent_cyan = QColor("#00cbe6")

        palette.setColor(QPalette.Window, base_dark)
        palette.setColor(QPalette.WindowText, text_primary)
        palette.setColor(QPalette.Base, surface_container)
        palette.setColor(QPalette.AlternateBase, surface_high)
        palette.setColor(QPalette.ToolTipBase, surface_high)
        palette.setColor(QPalette.ToolTipText, text_primary)
        palette.setColor(QPalette.Text, text_primary)
        palette.setColor(QPalette.Button, surface_container)
        palette.setColor(QPalette.ButtonText, text_primary)
        palette.setColor(QPalette.BrightText, QColor("#ffffff"))
        palette.setColor(QPalette.Link, accent_cyan)
        palette.setColor(QPalette.Highlight, QColor("#2f2ebe"))
        palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))

        self.setPalette(palette)

        # QSS Stylesheet for exact Stitch Glassmorphic styling
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0b0e14;
            }
            QWidget {
                color: #e1e2eb;
                font-family: 'Inter', sans-serif;
            }
            QFrame#GlassCard {
                background-color: rgba(22, 27, 34, 0.75);
                border: 1px solid rgba(70, 69, 84, 0.25);
                border-radius: 12px;
            }
            QPushButton {
                background-color: #272a31;
                border: 1px solid #464554;
                border-radius: 6px;
                padding: 8px 16px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #32353c;
                border-color: #00cbe6;
                color: #5de6ff;
            }
            QPushButton#PrimaryButton {
                background-color: #494bd6;
                border: 1px solid #c0c1ff;
                color: #ffffff;
            }
            QPushButton#PrimaryButton:hover {
                background-color: #5b5de6;
                box-shadow: 0 0 12px rgba(192, 193, 255, 0.5);
            }
            QScrollBar:vertical {
                border: none;
                background: #0b0e14;
                width: 6px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #32353c;
                min-height: 20px;
                border-radius: 3px;
            }
            QScrollBar::handle:vertical:hover {
                background: #464554;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)

    def handle_exception(self, exc_type, exc_value, exc_traceback):
        """Global uncaught exception handler."""
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return

        self.logger.critical("Uncaught exception in WaveForge runtime", exc_info=(exc_type, exc_value, exc_traceback))
